@file:OptIn(ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import androidx.compose.foundation.clickable
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.phonebook.app.data.SystemContacts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import com.phonebook.app.data.Search
import com.phonebook.app.data.Phone
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.border
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.Server
import com.phonebook.app.net.SharedBook
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private const val MAX_RESULTS = 30000

@Composable
fun ContactsScreen(
    shared: Boolean,
    onCall: (String) -> Unit,
    onSms: (String) -> Unit,
    onEdit: (Contact) -> Unit,
    onSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val table = if (shared) LocalDb.SHARED else LocalDb.PERSONAL

    // מצב נפרד לכל ספר
    var query by rememberSaveable(shared) { mutableStateOf("") }
    var region by rememberSaveable(shared) { mutableIntStateOf(0) }
    var city by rememberSaveable(shared) { mutableStateOf<String?>(null) }
    var selected by remember(shared) { mutableStateOf<Contact?>(null) }
    var toDelete by remember(shared) { mutableStateOf<Contact?>(null) }
    var cityPicker by remember { mutableStateOf(false) }
    var syncing by remember { mutableStateOf(false) }

    val dbv by LocalDb.changes.collectAsState()
    val session by Prefs.session.collectAsState()
    val result by produceState<List<Contact>?>(null, shared, query, region, city, dbv) {
        value = withContext(Dispatchers.IO) { LocalDb.search(table, query, region, city, MAX_RESULTS) }
    }
    val total by produceState(0, shared, dbv) { value = withContext(Dispatchers.IO) { LocalDb.count(table) } }
    val flags by Prefs.flags.collectAsState()
    val favorites by produceState(emptyList<Contact>(), dbv, flags) {
        value = withContext(Dispatchers.IO) { Prefs.favoriteTails().mapNotNull { LocalDb.findAny("0$it") ?: LocalDb.findAny(it) }.sortedBy { it.name } }
    }
    val cities by produceState(emptyList<Pair<String, Int>>(), shared, dbv) {
        value = withContext(Dispatchers.IO) { LocalDb.cities(table) }
    }

    fun sync() {
        if (syncing || !Server.loggedIn()) return
        scope.launch {
            syncing = true
            runCatching { SharedBook.sync() }.onFailure { toast(ctx, it.message ?: "הסנכרון נכשל") }
            syncing = false
        }
    }
    if (shared) LaunchedEffect(session) { if (session != null) sync() }

    Column(Modifier.fillMaxSize()) {
        // ---- כותרת כחולה: חיפוש וסינון ----
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.secondaryContainer)
                .padding(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            TextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("חיפוש לפי שם, עיר, חם, שטיבל או מספר", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "נקה") }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                listOf("הכל", "ארץ", "חו\"ל").forEachIndexed { i, label ->
                    HeaderChip(label, region == i) { region = i }
                }
                HeaderChip(city ?: "כל הערים", city != null, Modifier.weight(1f)) { cityPicker = true }
            }
        }

        if (shared && session == null) {
            InfoCard(
                "הספר הכללי משותף לכל המשתמשים. כדי לראות אותו ולהוסיף אליו – התחבר בהגדרות.",
                Modifier.padding(start = 16.dp, end = 16.dp, top = 10.dp).clickable { onSettings() }
            )
        }

        val list = result
        Row(
            Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val shown = list?.size ?: 0
            Text(
                "%,d מתוך %,d אנשי קשר".format(shown, total),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            if (shared && session != null) {
                if (syncing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else IconButton(onClick = { sync() }) { Icon(Icons.Filled.Refresh, "סנכרון", tint = MaterialTheme.colorScheme.primary) }
            } else Spacer(Modifier.height(40.dp))
        }

        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> EmptyState(
                when {
                    query.isNotBlank() || city != null || region != 0 -> "לא נמצאו תוצאות"
                    shared -> "הספר הכללי ריק"
                    else -> "עדיין אין אנשי קשר. לחץ + כדי להוסיף, או \"טעינת קובץ\" למעלה."
                }
            )
            else -> Box(Modifier.fillMaxSize()) {
                val listState = rememberLazyListState()
                val listScope = rememberCoroutineScope()
                val showFavs = query.isBlank() && city == null && region == 0
                LazyColumn(
                    state = listState,
                    contentPadding = PaddingValues(start = 12.dp, end = 30.dp, top = 2.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (showFavs && favorites.isNotEmpty()) item(key = "favs") {
                        FavoritesRow(favorites) { selected = it }
                    }
                    items(list, key = { it.id }) { c -> ContactRow(c, onCall) { selected = c } }
                }
                // אינדקס אותיות בצד – קפיצה מהירה
                val offset = if (showFavs && favorites.isNotEmpty()) 1 else 0
                val letters = remember(list) {
                    val m = LinkedHashMap<Char, Int>()
                    list.forEachIndexed { i, c ->
                        val ch = Search.norm(c.name).firstOrNull { it.isLetter() }?.uppercaseChar()
                        if (ch != null && ch !in m) m[ch] = i
                    }
                    m.toList()
                }
                if (letters.size > 3) LetterIndex(letters, Modifier.align(Alignment.CenterEnd)) { idx ->
                    listScope.launch { listState.scrollToItem(idx + offset) }
                }
            }
        }
    }

    if (cityPicker) CityPickerDialog(cities, city, onPick = { city = it; cityPicker = false }, onDismiss = { cityPicker = false })

    selected?.let { c ->
        val canEdit = !shared || SharedBook.canEdit(c)
        ContactSheet(
            c, shared, canEdit,
            onDismiss = { selected = null },
            onCall = onCall,
            onSms = { selected = null; onSms(it) },
            onAddToPersonal = if (shared) {
                {
                    if (LocalDb.findByPhone(LocalDb.PERSONAL, c.phone) != null) toast(ctx, "כבר נמצא בספר האישי")
                    else {
                        LocalDb.upsert(LocalDb.PERSONAL, c.copy(id = UUID.randomUUID().toString(), owner = ""))
                        toast(ctx, "נוסף לספר האישי")
                    }
                }
            } else null,
            onEdit = { selected = null; onEdit(c) },
            onDelete = { selected = null; toDelete = c },
        )
    }

    toDelete?.let { c ->
        DeleteDialog(c, onDismiss = { toDelete = null }) {
            toDelete = null
            if (!shared) {
                LocalDb.delete(LocalDb.PERSONAL, c.id)
            } else scope.launch {
                runCatching { SharedBook.delete(c.id) }
                    .onSuccess { toast(ctx, "נמחק") }
                    .onFailure { toast(ctx, it.message ?: "המחיקה נכשלה") }
            }
        }
    }
}

/** שורת מועדפים בראש הספר */
@Composable
private fun FavoritesRow(favs: List<Contact>, onOpen: (Contact) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("⭐ מועדפים", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            favs.forEach { c ->
                Column(
                    Modifier.width(72.dp).clip(RoundedCornerShape(14.dp)).clickable { onOpen(c) }.padding(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Avatar(c.name, 52.dp)
                    Text(c.name.split(" ").take(2).joinToString(" "), maxLines = 2, fontSize = 12.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center, lineHeight = 14.sp)
                }
            }
        }
    }
}

/** אינדקס אותיות בצד הרשימה – לחיצה או גרירה קופצת לאות */
@Composable
private fun LetterIndex(letters: List<Pair<Char, Int>>, modifier: Modifier, onJump: (Int) -> Unit) {
    var heightPx by remember { mutableIntStateOf(1) }
    fun jump(y: Float) {
        val i = (y / heightPx * letters.size).toInt().coerceIn(0, letters.lastIndex)
        onJump(letters[i].second)
    }
    Column(
        modifier
            .padding(end = 2.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = 0.85f))
            .onSizeChanged { heightPx = it.height.coerceAtLeast(1) }
            .pointerInput(letters) {
                detectTapGestures { jump(it.y) }
            }
            .pointerInput(letters) {
                detectVerticalDragGestures { change, _ -> jump(change.position.y) }
            }
            .padding(vertical = 4.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        letters.forEach { (ch, _) ->
            Text(ch.toString(), fontSize = 11.sp, lineHeight = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}

/** כפתור סינון עגול על הכותרת הכחולה */
@Composable
private fun HeaderChip(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val on = MaterialTheme.colorScheme.onSecondaryContainer
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .clip(shape)
            .then(if (selected) Modifier.background(on) else Modifier.border(1.dp, on.copy(alpha = 0.45f), shape))
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = if (selected) MaterialTheme.colorScheme.secondaryContainer else on,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

/** בחירת עיר – עם מספר אנשי הקשר בכל עיר */
@Composable
private fun CityPickerDialog(cities: List<Pair<String, Int>>, current: String?, onPick: (String?) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("סגור") } },
        title = { Text("בחירת עיר") },
        text = {
            LazyColumn(Modifier.heightIn(max = 460.dp)) {
                item { CityRow("כל הערים", null, current == null) { onPick(null) } }
                items(cities, key = { it.first }) { (name, n) -> CityRow(name, n, current == name) { onPick(name) } }
            }
        },
        shape = RoundedCornerShape(24.dp),
    )
}

@Composable
private fun CityRow(name: String, count: Int?, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(if (count != null) "$name ($count)" else name, style = MaterialTheme.typography.bodyLarge)
    }
}

/** מספר נייד או קווי – לאייקון שליד המספר */
private fun isMobile(number: String): Boolean {
    val d = Phone.digits(number)
    return d.startsWith("05") || d.startsWith("9725") || d.startsWith("009725")
}

@Composable
private fun PhonePill(number: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
    ) {
        Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(ltr(number), fontWeight = FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.width(6.dp))
            Text(if (isMobile(number)) "📱" else "☎️", fontSize = 14.sp)
        }
    }
}

@Composable
private fun ContactRow(c: Contact, onCall: (String) -> Unit, onClick: () -> Unit) {
    AppCard(Modifier.clickable(onClick = onClick)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(c.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, lineHeight = 22.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (Phone.isAbroad(c.phone)) Text("חו\"ל", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                val sub = listOf(c.city, c.address)
                    .filter { it.isNotBlank() }.joinToString(" · ")
                if (sub.isNotBlank()) Text(
                    sub, style = MaterialTheme.typography.bodySmall, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(c.phone, c.phone2).filter { it.isNotBlank() }.forEach { n -> PhonePill(n) { onCall(n) } }
            }
        }
    }
}

/** כרטיס איש קשר שעולה מלמטה */
@Composable
private fun ContactSheet(
    c: Contact, shared: Boolean, canEdit: Boolean,
    onDismiss: () -> Unit, onCall: (String) -> Unit, onSms: (String) -> Unit,
    onAddToPersonal: (() -> Unit)?, onEdit: () -> Unit, onDelete: () -> Unit,
) {
    val ctx = LocalContext.current
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MaterialTheme.colorScheme.surfaceContainerLowest) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val flags by Prefs.flags.collectAsState()
            val fav = remember(flags, c.phone) { Prefs.isFavorite(c.phone) }
            Row(verticalAlignment = Alignment.Top) {
                Text(c.name, fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { Prefs.setFavorite(c.phone, !fav) }) {
                    Icon(if (fav) Icons.Filled.Star else Icons.Filled.StarBorder, if (fav) "הסר ממועדפים" else "הוסף למועדפים",
                        tint = if (fav) Color(0xFFF5B301) else MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            InfoLine("📍", listOf(c.address, c.city).filter { it.isNotBlank() }.joinToString(", "))
            c.details.forEach { (k, v) -> InfoLine("▫️", "$k: $v") }
            if (!shared) InfoLine("✉️", c.email)
            Spacer(Modifier.height(6.dp))

            PhoneBox("טלפון", c.phone, onCall, onSms) { Actions.whatsapp(ctx, c.phone) }
            if (c.phone2.isNotBlank()) PhoneBox("טלפון 2", c.phone2, onCall, onSms) { Actions.whatsapp(ctx, c.phone2) }

            // ---- אנשי הקשר של הטלפון: שמירה + צלצול מיוחד ----
            var pendingAction by remember { mutableStateOf<String?>(null) }
            val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
                if (res.resultCode == android.app.Activity.RESULT_OK) {
                    @Suppress("DEPRECATION")
                    val uri = res.data?.getParcelableExtra<android.net.Uri>(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                    toast(ctx, if (SystemContacts.setRingtone(ctx, c, uri)) "הצלצול נשמר" else "לא ניתן לשמור את הצלצול")
                }
            }
            fun openPicker() {
                val current = SystemContacts.getRingtone(ctx, c.phone)
                ringtonePicker.launch(android.content.Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                    putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_RINGTONE)
                    putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TITLE, "צלצול עבור ${c.name}")
                    putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                    putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, current)
                })
            }
            fun saveToPhone() {
                toast(ctx, if (SystemContacts.ensureSaved(ctx, c) != null) "נשמר באנשי הקשר של הטלפון" else "השמירה נכשלה")
            }
            val contactsPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
                if (r.values.all { it }) when (pendingAction) {
                    "ring" -> openPicker()
                    "save" -> saveToPhone()
                } else toast(ctx, "צריך לאשר גישה לאנשי הקשר")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (SystemContacts.hasPermission(ctx)) openPicker() else { pendingAction = "ring"; contactsPerm.launch(SystemContacts.PERMISSIONS) }
                }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) { Text("🔔 צלצול מיוחד", maxLines = 1) }
                OutlinedButton(onClick = {
                    if (SystemContacts.hasPermission(ctx)) saveToPhone() else { pendingAction = "save"; contactsPerm.launch(SystemContacts.PERMISSIONS) }
                }, shape = RoundedCornerShape(14.dp), modifier = Modifier.weight(1f)) { Text("📱 שמור בטלפון", maxLines = 1) }
            }

            // ---- דיווח על פרט שגוי בספר הכללי ----
            if (shared && !canEdit) {
                var reporting by remember { mutableStateOf(false) }
                val reportScope = rememberCoroutineScope()
                TextButton(onClick = { reporting = true }) { Text("🚩 דווח על פרט שגוי") }
                if (reporting) {
                    var reason by remember { mutableStateOf("") }
                    AlertDialog(
                        onDismissRequest = { reporting = false },
                        title = { Text("מה לא נכון ברשומה?") },
                        text = { OutlinedTextField(reason, { reason = it }, placeholder = { Text("למשל: המספר לא נכון, עבר דירה…") }, minLines = 2) },
                        confirmButton = {
                            TextButton(onClick = {
                                reporting = false
                                reportScope.launch {
                                    runCatching { SharedBook.report(c.id, reason) }
                                        .onSuccess { toast(ctx, "תודה! הדיווח נשלח למנהל") }
                                        .onFailure { toast(ctx, it.message ?: "השליחה נכשלה") }
                                }
                            }) { Text("שלח") }
                        },
                        dismissButton = { TextButton(onClick = { reporting = false }) { Text("ביטול") } },
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
            if (onAddToPersonal != null) {
                Button(
                    onClick = onAddToPersonal,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Brand, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("👤 הוסף לספר האישי", fontWeight = FontWeight.Bold) }
            } else {
                Button(
                    onClick = onEdit,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Brand, contentColor = Color.White),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text("✏️ עריכת איש הקשר", fontWeight = FontWeight.Bold) }
            }
            if (canEdit) {
                if (shared) OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) { Text("✏️ עריכת הרשומה") }
                OutlinedButton(
                    onClick = onDelete,
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, CallRed),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CallRed),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) { Text(if (Prefs.hasDeletePassword) "🗑️ מחיקת איש קשר (דורש סיסמת מחיקה)" else "🗑️ מחיקת איש קשר") }
            } else if (shared) {
                Text(
                    "רק מי שהוסיף את הרשומה יכול לערוך או למחוק אותה",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun InfoLine(icon: String, text: String) {
    if (text.isBlank()) return
    Row(verticalAlignment = Alignment.Top) {
        Text(icon, fontSize = 15.sp)
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PhoneBox(label: String, number: String, onCall: (String) -> Unit, onSms: (String) -> Unit, onWhatsapp: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(ltr(number), fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { onCall(number) },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CallGreen, contentColor = Color.White),
                    modifier = Modifier.weight(1f).height(50.dp)
                ) { Text("📞 התקשר", fontWeight = FontWeight.Bold) }
                Button(
                    onClick = onWhatsapp,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsGreen, contentColor = Color.White),
                    modifier = Modifier.weight(1f).height(50.dp)
                ) { Text("💬 וואטסאפ", fontWeight = FontWeight.Bold) }
            }
            TextButton(onClick = { onSms(number) }, modifier = Modifier.fillMaxWidth()) { Text("✉️ שליחת SMS") }
        }
    }
}

@Composable
private fun DeleteDialog(c: Contact, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    val needPw = Prefs.hasDeletePassword
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("למחוק את ${c.name}?") },
        text = {
            if (needPw) OutlinedTextField(
                pw, { pw = it; wrong = false },
                label = { Text("סיסמת מחיקה") },
                isError = wrong,
                supportingText = { if (wrong) Text("סיסמה שגויה") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            ) else Text("לא ניתן לבטל את הפעולה.")
        },
        confirmButton = {
            TextButton(onClick = { if (Prefs.checkDeletePassword(pw)) onConfirm() else wrong = true }) {
                Text("מחק", color = CallRed)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ביטול") } },
    )
}

// ---------------- הוספה / עריכה ----------------

@Composable
fun ContactEditor(initial: Contact?, initialShared: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isNew = initial == null || initial.name.isBlank()
    var shared by rememberSaveable { mutableStateOf(initialShared) }
    var name by rememberSaveable { mutableStateOf(initial?.name ?: "") }
    var phone by rememberSaveable { mutableStateOf(initial?.phone ?: "") }
    var phone2 by rememberSaveable { mutableStateOf(initial?.phone2 ?: "") }
    var city by rememberSaveable { mutableStateOf(initial?.city ?: "") }
    var address by rememberSaveable { mutableStateOf(initial?.address ?: "") }
    // פרטים נוספים: רשימה חופשית של "שם שדה – ערך"
    val details = remember { mutableStateListOf<Pair<String, String>>().apply { addAll(initial?.details ?: emptyList()) } }
    var addingField by remember { mutableStateOf(false) }
    var email by rememberSaveable { mutableStateOf(initial?.email ?: "") }
    var saving by remember { mutableStateOf(false) }

    fun save() {
        if (name.isBlank() || phone.isBlank()) {
            toast(ctx, "חובה למלא שם וטלפון"); return
        }
        val c = Contact(
            id = initial?.id ?: UUID.randomUUID().toString(), name = name, phone = phone, phone2 = phone2,
            city = city, address = address, email = email,
            owner = initial?.owner ?: "",
        ).withDetails(details.toList())
        if (!shared) {
            LocalDb.upsert(LocalDb.PERSONAL, c)
            onClose()
            return
        }
        if (!Server.loggedIn()) {
            toast(ctx, "כדי להוסיף לספר הכללי צריך להתחבר בהגדרות"); return
        }
        scope.launch {
            saving = true
            runCatching { if (isNew) SharedBook.add(c) else SharedBook.update(c) }
                .onSuccess { onClose() }
                .onFailure { toast(ctx, it.message ?: "השמירה נכשלה") }
            saving = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar(if (isNew) "איש קשר חדש" else "עריכת איש קשר", onClose) {
            if (saving) CircularProgressIndicator(Modifier.size(22.dp).padding(end = 4.dp), strokeWidth = 2.dp)
            TextButton(onClick = { save() }, enabled = !saving, colors = ButtonDefaults.textButtonColors(contentColor = Color.White)) { Text("שמור", fontWeight = FontWeight.Bold) }
        }
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (isNew) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !shared, onClick = { shared = false }, label = { Text("ספר אישי") })
                    FilterChip(selected = shared, onClick = { shared = true }, label = { Text("ספר כללי") })
                }
                Text(
                    if (shared) "יופיע בחיפוש של כל המשתמשים. האימייל לא מתפרסם."
                    else "נשמר רק בטלפון שלך, ולא יופיע אצל אף אחד אחר.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            EditField("שם *", name) { name = it }
            EditField("טלפון *", phone, KeyboardType.Phone) { phone = it }
            EditField("טלפון 2", phone2, KeyboardType.Phone) { phone2 = it }
            EditField("עיר", city) { city = it }
            EditField("כתובת", address) { address = it }
            EditField(if (shared) "אימייל (לא מתפרסם)" else "אימייל", email, KeyboardType.Email) { email = it }

            if (details.isNotEmpty()) Text("פרטים נוספים", style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
            details.forEachIndexed { i, (label, value) ->
                OutlinedTextField(
                    value = value,
                    onValueChange = { v -> details[i] = label to v },
                    label = { Text(label) },
                    singleLine = label != "הערה",
                    trailingIcon = {
                        IconButton(onClick = { details.removeAt(i) }) { Icon(Icons.Filled.Close, "הסר את השדה") }
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            OutlinedButton(onClick = { addingField = true }, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("הוסף שדה")
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (addingField) AddFieldDialog(
        used = details.map { it.first },
        onDismiss = { addingField = false },
    ) { label ->
        addingField = false
        details.add(label to "")
    }
}

/** בחירת שדה חדש: מההצעות או שם חופשי */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddFieldDialog(used: List<String>, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var custom by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("איזה שדה להוסיף?") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    com.phonebook.app.data.Fields.SUGGESTIONS.filter { it !in used }.forEach { s ->
                        AssistChip(onClick = { onPick(s) }, label = { Text(s) })
                    }
                }
                OutlinedTextField(
                    value = custom, onValueChange = { custom = it },
                    label = { Text("או כתוב שם שדה משלך") },
                    singleLine = true, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(enabled = custom.isNotBlank(), onClick = { onPick(custom.trim()) }) { Text("הוסף") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ביטול") } },
    )
}

@Composable
private fun EditField(label: String, value: String, type: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = type),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    )
}
