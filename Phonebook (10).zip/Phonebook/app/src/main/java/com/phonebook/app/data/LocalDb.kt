package com.phonebook.app.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * מסד נתונים מקומי במכשיר.
 *  personal – הספר האישי. נשמר רק כאן ולעולם לא נשלח לשרת.
 *  shared   – עותק מקומי של הספר הכללי (לחיפוש מהיר וזיהוי מתקשר גם בלי אינטרנט).
 *  trash    – סל מחזור: אנשי קשר אישיים שנמחקו נשמרים כאן 30 יום.
 */
object LocalDb {
    const val PERSONAL = "personal"
    const val SHARED = "shared"
    private const val TRASH = "trash"
    private const val TRASH_DAYS = 30L

    private const val COLS = "id, name, phone, phone2, city, address, father, chem, shtibel, email, owner, " +
        "digits, tail1, tail2, abroad, batch, norm, extra"

    /** מספר שעולה בכל שינוי – המסכים מאזינים לו כדי להתרענן */
    val changes = MutableStateFlow(0)

    private lateinit var helper: SQLiteOpenHelper

    private fun createTable(db: SQLiteDatabase, t: String, extra: String = "") {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS $t (id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT, phone2 TEXT, " +
                "city TEXT, address TEXT, father TEXT, chem TEXT, shtibel TEXT, email TEXT, owner TEXT, " +
                "digits TEXT, tail1 TEXT, tail2 TEXT, abroad INTEGER, batch TEXT, norm TEXT, extra TEXT$extra)"
        )
    }

    fun init(ctx: Context) {
        helper = object : SQLiteOpenHelper(ctx, "phonebook.db", null, 4) {
            override fun onCreate(db: SQLiteDatabase) {
                for (t in listOf(PERSONAL, SHARED)) {
                    createTable(db, t)
                    db.execSQL("CREATE INDEX ${t}_tail1 ON $t(tail1)")
                    db.execSQL("CREATE INDEX ${t}_tail2 ON $t(tail2)")
                    db.execSQL("CREATE INDEX ${t}_name ON $t(name)")
                    db.execSQL("CREATE INDEX ${t}_city ON $t(city)")
                }
                createTable(db, TRASH, ", deleted_at INTEGER")
            }

            override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
                if (oldVersion < 2) for (t in listOf(PERSONAL, SHARED)) db.execSQL("ALTER TABLE $t ADD COLUMN batch TEXT")
                if (oldVersion < 3) {
                    for (t in listOf(PERSONAL, SHARED)) {
                        db.execSQL("ALTER TABLE $t ADD COLUMN norm TEXT")
                        // חישוב עמודת החיפוש המנורמלת לכל הרשומות הקיימות
                        val rows = mutableListOf<Pair<String, String>>()
                        db.rawQuery("SELECT id, name, city, chem, shtibel, father, address FROM $t", null).use { c ->
                            while (c.moveToNext()) {
                                val text = (1..6).joinToString(" ") { c.getString(it) ?: "" }
                                rows += c.getString(0) to Search.norm(text)
                            }
                        }
                        rows.forEach { (id, n) -> db.execSQL("UPDATE $t SET norm=? WHERE id=?", arrayOf(n, id)) }
                    }
                    createTable(db, TRASH, ", deleted_at INTEGER")
                }
                if (oldVersion < 4) {
                    // שדות נוספים. (טבלת הסל שנוצרה כרגע בשדרוג מ-2 כבר כוללת את העמודה)
                    for (t in listOf(PERSONAL, SHARED, TRASH)) try {
                        db.execSQL("ALTER TABLE $t ADD COLUMN extra TEXT")
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    private fun bump() {
        changes.value = changes.value + 1
    }

    private fun values(c: Contact) = ContentValues().apply {
        put("id", c.id); put("name", c.name.trim()); put("phone", c.phone.trim()); put("phone2", c.phone2.trim())
        put("city", c.city.trim()); put("address", c.address.trim()); put("father", c.father.trim())
        put("chem", c.chem.trim()); put("shtibel", c.shtibel.trim()); put("email", c.email.trim()); put("owner", c.owner)
        put("extra", c.extra)
        put("digits", Phone.digits(c.phone) + " " + Phone.digits(c.phone2))
        put("tail1", Phone.tail(c.phone)); put("tail2", Phone.tail(c.phone2))
        put("abroad", if (Phone.isAbroad(c.phone)) 1 else 0)
        put("norm", Search.norm((listOf(c.name, c.city, c.chem, c.shtibel, c.father, c.address) + c.extras.map { it.second }).joinToString(" ")))
    }

    private fun Cursor.str(col: String) = getString(getColumnIndexOrThrow(col)) ?: ""

    private fun Cursor.contact() = Contact(
        id = str("id"), name = str("name"), phone = str("phone"), phone2 = str("phone2"),
        city = str("city"), address = str("address"), father = str("father"), chem = str("chem"),
        shtibel = str("shtibel"), email = str("email"), owner = str("owner"), extra = str("extra"),
    )

    fun upsert(table: String, c: Contact) {
        helper.writableDatabase.insertWithOnConflict(table, null, values(c), SQLiteDatabase.CONFLICT_REPLACE)
        bump()
    }

    fun upsertAll(table: String, list: List<Contact>, deleteIds: List<String> = emptyList(), batch: String? = null) {
        if (list.isEmpty() && deleteIds.isEmpty()) return
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            list.forEach {
                val v = values(it)
                if (batch != null) v.put("batch", batch)
                db.insertWithOnConflict(table, null, v, SQLiteDatabase.CONFLICT_REPLACE)
            }
            deleteIds.forEach { db.delete(table, "id=?", arrayOf(it)) }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        bump()
    }

    /** מחיקה. בספר האישי – העברה לסל המחזור */
    fun delete(table: String, id: String) {
        if (table == PERSONAL) moveToTrash("id=?", arrayOf(id))
        else helper.writableDatabase.delete(table, "id=?", arrayOf(id))
        bump()
    }

    private fun moveToTrash(where: String, args: Array<String>?): Int {
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            db.execSQL(
                "INSERT OR REPLACE INTO $TRASH ($COLS, deleted_at) SELECT $COLS, ${System.currentTimeMillis()} FROM $PERSONAL WHERE $where",
                args ?: emptyArray()
            )
            val n = db.delete(PERSONAL, where, args)
            db.setTransactionSuccessful()
            return n
        } finally {
            db.endTransaction()
        }
    }

    /** מחיקת כל מה שנטען בטעינת קובץ מסוימת (לסל המחזור) */
    fun deleteBatch(table: String, batch: String): Int {
        val n = if (table == PERSONAL) moveToTrash("batch=?", arrayOf(batch))
        else helper.writableDatabase.delete(table, "batch=?", arrayOf(batch))
        bump()
        return n
    }

    /** מוחק לצמיתות מהספר האישי רשומות פגומות (למשל מקובץ שנקרא לא נכון) */
    fun cleanupBroken(): Int {
        val bad = all(PERSONAL).filter { !ImportExport.isValidPhone(it.phone) || !ImportExport.isValidName(it.name) }
        if (bad.isEmpty()) return 0
        upsertAll(PERSONAL, emptyList(), bad.map { it.id })
        return bad.size
    }

    /** ניקוי טבלה. בספר האישי – הכל עובר לסל המחזור */
    fun clear(table: String) {
        if (table == PERSONAL) moveToTrash("1=1", null)
        else helper.writableDatabase.delete(table, null, null)
        bump()
    }

    // ---------------- סל מחזור ----------------

    fun trash(): List<Pair<Contact, Long>> {
        val out = mutableListOf<Pair<Contact, Long>>()
        helper.readableDatabase.rawQuery("SELECT * FROM $TRASH ORDER BY deleted_at DESC LIMIT 2000", null).use { c ->
            while (c.moveToNext()) out += c.contact() to c.getLong(c.getColumnIndexOrThrow("deleted_at"))
        }
        return out
    }

    fun trashCount(): Int = DatabaseUtils.queryNumEntries(helper.readableDatabase, TRASH).toInt()

    fun restore(ids: List<String>) {
        val db = helper.writableDatabase
        db.beginTransaction()
        try {
            ids.forEach { id ->
                db.execSQL("INSERT OR REPLACE INTO $PERSONAL ($COLS) SELECT $COLS FROM $TRASH WHERE id=?", arrayOf(id))
                db.delete(TRASH, "id=?", arrayOf(id))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        bump()
    }

    fun deleteForever(ids: List<String>?) {
        if (ids == null) helper.writableDatabase.delete(TRASH, null, null)
        else ids.forEach { helper.writableDatabase.delete(TRASH, "id=?", arrayOf(it)) }
        bump()
    }

    /** מוחק מהסל רשומות ישנות מ-30 יום */
    fun purgeTrash() {
        val cutoff = System.currentTimeMillis() - TRASH_DAYS * 24 * 3600 * 1000
        helper.writableDatabase.delete(TRASH, "deleted_at<?", arrayOf(cutoff.toString()))
    }

    // ---------------- חיפוש ----------------

    fun count(table: String): Int = DatabaseUtils.queryNumEntries(helper.readableDatabase, table).toInt()

    /**
     * חיפוש: כל מילה צריכה להופיע באחד השדות (שם, עיר, חם, שטיבל, שם האב, כתובת) או במספר.
     * החיפוש לא רגיש לאותיות סופיות, ניקוד וגרשיים.
     * region: 0 = הכל, 1 = ארץ, 2 = חו"ל
     */
    fun search(table: String, query: String, region: Int, city: String?, limit: Int): List<Contact> {
        val where = StringBuilder("1=1")
        val args = mutableListOf<String>()
        query.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.forEach { w ->
            val clean = w.replace("-", "").replace("+", "")
            val d = Phone.digits(clean)
            if (d.isNotEmpty() && d.length == clean.length) {
                where.append(" AND digits LIKE ?")
                args += "%$d%"
            } else {
                val n = Search.norm(w)
                if (n.isNotEmpty()) {
                    where.append(" AND norm LIKE ?")
                    args += "%$n%"
                }
            }
        }
        when (region) {
            1 -> where.append(" AND abroad=0")
            2 -> where.append(" AND abroad=1")
        }
        if (!city.isNullOrBlank()) {
            where.append(" AND city=?")
            args += city
        }
        val out = mutableListOf<Contact>()
        helper.readableDatabase.rawQuery(
            "SELECT * FROM $table WHERE $where ORDER BY name LIMIT $limit", args.toTypedArray()
        ).use { c -> while (c.moveToNext()) out += c.contact() }
        return out
    }

    /** ערים וכמה אנשי קשר בכל אחת, מהגדולה לקטנה */
    fun cities(table: String): List<Pair<String, Int>> {
        val out = mutableListOf<Pair<String, Int>>()
        helper.readableDatabase.rawQuery(
            "SELECT city, COUNT(*) n FROM $table WHERE city<>'' GROUP BY city ORDER BY n DESC LIMIT 500", null
        ).use { c -> while (c.moveToNext()) out += c.getString(0) to c.getInt(1) }
        return out
    }

    fun all(table: String): List<Contact> {
        val out = mutableListOf<Contact>()
        helper.readableDatabase.rawQuery("SELECT * FROM $table ORDER BY name", null)
            .use { c -> while (c.moveToNext()) out += c.contact() }
        return out
    }

    fun findByPhone(table: String, number: String): Contact? {
        val t = Phone.tail(number)
        if (t.isEmpty()) return null
        helper.readableDatabase.rawQuery(
            "SELECT * FROM $table WHERE tail1=? OR tail2=? LIMIT 1", arrayOf(t, t)
        ).use { c -> return if (c.moveToFirst()) c.contact() else null }
    }

    /** איש קשר לפי מספר – קודם בספר האישי ואז בכללי */
    fun findAny(number: String): Contact? = findByPhone(PERSONAL, number) ?: findByPhone(SHARED, number)
}
