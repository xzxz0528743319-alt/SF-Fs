package com.phonebook.app.data

import android.Manifest
import android.content.ContentProviderOperation
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/**
 * חיבור לאנשי הקשר של הטלפון:
 *  - שמירת איש קשר בטלפון (כך הוא יופיע גם בוואטסאפ)
 *  - צלצול מיוחד לאיש קשר (הצלצול נקבע באנשי הקשר של הטלפון, והמערכת מנגנת אותו)
 */
object SystemContacts {
    val PERMISSIONS = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)

    fun hasPermission(ctx: Context) = PERMISSIONS.all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    /** מזהה איש הקשר בטלפון לפי מספר, או null */
    fun findContactId(ctx: Context, number: String): Long? = try {
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getLong(0) else null }
    } catch (_: Exception) {
        null
    }

    /** שומר בטלפון אם עוד לא קיים. מחזיר את מזהה איש הקשר */
    fun ensureSaved(ctx: Context, c: Contact): Long? {
        findContactId(ctx, c.phone)?.let { return it }
        val ops = arrayListOf(
            ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, c.name)
                .build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, c.phone)
                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                .build(),
        )
        if (c.phone2.isNotBlank()) ops += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
            .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, c.phone2)
            .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_HOME)
            .build()
        return try {
            ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            findContactId(ctx, c.phone)
        } catch (_: Exception) {
            null
        }
    }

    /** קובע צלצול מיוחד (null = צלצול רגיל) */
    fun setRingtone(ctx: Context, c: Contact, ringtone: Uri?): Boolean {
        val id = ensureSaved(ctx, c) ?: return false
        return try {
            ctx.contentResolver.update(
                ContactsContract.Contacts.CONTENT_URI,
                ContentValues().apply { put(ContactsContract.Contacts.CUSTOM_RINGTONE, ringtone?.toString()) },
                "${ContactsContract.Contacts._ID}=?", arrayOf(id.toString())
            ) > 0
        } catch (_: Exception) {
            false
        }
    }

    fun getRingtone(ctx: Context, number: String): Uri? {
        val id = findContactId(ctx, number) ?: return null
        return try {
            ctx.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.CUSTOM_RINGTONE),
                "${ContactsContract.Contacts._ID}=?", arrayOf(id.toString()), null
            )?.use { c -> if (c.moveToFirst()) c.getString(0)?.let { Uri.parse(it) } else null }
        } catch (_: Exception) {
            null
        }
    }
}
