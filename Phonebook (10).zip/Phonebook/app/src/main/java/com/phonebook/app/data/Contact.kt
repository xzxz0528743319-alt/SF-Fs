package com.phonebook.app.data

/**
 * איש קשר. אותו מבנה משמש לספר האישי ולספר הכללי.
 * owner = מזהה המשתמש שהוסיף את הרשומה לספר הכללי (ריק בספר האישי).
 */
data class Contact(
    val id: String,
    val name: String,
    val phone: String,
    val phone2: String = "",
    val city: String = "",
    val address: String = "",
    val father: String = "",
    val chem: String = "",
    val shtibel: String = "",
    val email: String = "",
    val owner: String = "",
    /** שדות נוספים שהמשתמש הוסיף בעצמו (JSON) */
    val extra: String = "",
) {
    val extras: List<Pair<String, String>> get() = Fields.parse(extra)

    /** כל הפרטים הנוספים לתצוגה – כולל שם האב / חם / בית כנסת אם מולאו */
    val details: List<Pair<String, String>>
        get() = buildList {
            if (father.isNotBlank()) add(Fields.FATHER to father)
            if (chem.isNotBlank()) add(Fields.CHEM to chem)
            if (shtibel.isNotBlank()) add(Fields.SHTIBEL to shtibel)
            addAll(extras)
        }

    /** מחזיר עותק עם רשימת פרטים נוספים חדשה (שם האב / חם / בית כנסת נשמרים בעמודות שלהם) */
    fun withDetails(list: List<Pair<String, String>>): Contact {
        var f = ""; var c = ""; var s = ""
        val rest = mutableListOf<Pair<String, String>>()
        list.map { it.first.trim() to it.second.trim() }.filter { it.first.isNotBlank() && it.second.isNotBlank() }.forEach { (k, v) ->
            when {
                k in Fields.FATHER_ALIASES && f.isEmpty() -> f = v
                k in Fields.CHEM_ALIASES && c.isEmpty() -> c = v
                k in Fields.SHTIBEL_ALIASES && s.isEmpty() -> s = v
                else -> rest += k to v
            }
        }
        return copy(father = f, chem = c, shtibel = s, extra = Fields.json(rest))
    }

    val subtitle: String
        get() = listOf(city, shtibel).filter { it.isNotBlank() }.joinToString(" · ")
}

object Phone {
    fun digits(s: String): String = s.filter { it.isDigit() }

    /** 9 הספרות האחרונות – מזהה מספר בלי קשר לקידומת 0 / 972+ */
    fun tail(s: String): String {
        val d = digits(s)
        return if (d.length >= 7) d.takeLast(9) else ""
    }

    fun isAbroad(s: String): Boolean {
        val t = s.trim().replace(" ", "").replace("-", "")
        return (t.startsWith("+") && !t.startsWith("+972")) ||
            (t.startsWith("00") && !t.startsWith("00972"))
    }

    /** פורמט בינלאומי ללא + (לוואטסאפ) */
    fun international(s: String): String {
        val t = s.trim()
        var d = digits(t)
        if (t.startsWith("+")) return d
        if (d.startsWith("00")) return d.drop(2)
        if (d.startsWith("0")) d = "972" + d.drop(1)
        return d
    }
}

/** שדות נוספים לאיש קשר */
object Fields {
    const val FATHER = "שם האב"
    const val CHEM = "חם"
    const val SHTIBEL = "בית כנסת"
    val FATHER_ALIASES = setOf("שם האב", "שם אב", "אב")
    val CHEM_ALIASES = setOf("חם", "חותן", "שם החותן", "שם החם")
    val SHTIBEL_ALIASES = setOf("בית כנסת", "שטיבל", "בית כנסת / שטיבל")

    /** הצעות לשדות שמופיעות בלחיצה על "הוסף שדה" */
    val SUGGESTIONS = listOf(
        "הערה", "מקום עבודה", "תפקיד", "יום הולדת", "טלפון נוסף", "פקס", "אתר אינטרנט",
        "כינוי", "שם בן/בת הזוג", "שם האב", "חם", "בית כנסת", "קהילה", "מוסד לימודים", "שכונה", "מיקוד",
    )

    fun parse(s: String): List<Pair<String, String>> {
        if (s.isBlank()) return emptyList()
        return try {
            val a = org.json.JSONArray(s)
            (0 until a.length()).mapNotNull { i ->
                val o = a.optJSONObject(i) ?: return@mapNotNull null
                val k = o.optString("k"); val v = o.optString("v")
                if (k.isBlank() || v.isBlank()) null else k to v
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun json(list: List<Pair<String, String>>): String {
        if (list.isEmpty()) return ""
        val a = org.json.JSONArray()
        list.forEach { (k, v) -> a.put(org.json.JSONObject().put("k", k).put("v", v)) }
        return a.toString()
    }

    /** "שם: ערך; שם: ערך" – לקובץ CSV */
    fun toText(list: List<Pair<String, String>>) = list.joinToString("; ") { "${it.first}: ${it.second}" }

    fun fromText(s: String): List<Pair<String, String>> = s.split(';').mapNotNull { part ->
        val i = part.indexOf(':')
        if (i <= 0) null else part.substring(0, i).trim() to part.substring(i + 1).trim()
    }.filter { it.first.isNotBlank() && it.second.isNotBlank() }
}
