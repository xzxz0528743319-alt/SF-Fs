package com.phonebook.app.pc

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.phonebook.app.MainActivity
import com.phonebook.app.R
import com.phonebook.app.data.Prefs
import com.phonebook.app.ui.tr
import kotlin.math.abs

/**
 * כפתור צף לנהיגה: עיגול קטן שמופיע מעל כל האפליקציות (למשל Waze או Google Maps).
 * לחיצה – פותחת את העוזרת ומתחילה להקשיב מיד ("תתקשר ל…").
 * גרירה – מזיזה את הכפתור. לחיצה ארוכה – מסתירה אותו.
 */
class DrivingBubbleService : Service() {
    private var view: View? = null
    private val wm by lazy { getSystemService(WindowManager::class.java) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        if (intent?.action == ACTION_STOP || !Settings.canDrawOverlays(this)) {
            Prefs.bubble = false
            stopSelf(); return START_NOT_STICKY
        }
        if (view == null) addBubble()
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, tr("כפתור נהיגה"), NotificationManager.IMPORTANCE_MIN))
        val stopPi = PendingIntent.getService(
            this, 31, Intent(this, DrivingBubbleService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_phone)
            .setContentTitle(tr("🚗 כפתור נהיגה פעיל"))
            .setContentText(tr("לחיצה על העיגול הצף פותחת את העוזרת בדיבור"))
            .setOngoing(true)
            .addAction(0, tr("הסתר"), stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(ID, n)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        val d = resources.displayMetrics.density
        val size = (64 * d).toInt()
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#5B6CFF"), Color.parseColor("#8B5CF6"))
        ).apply {
            shape = GradientDrawable.OVAL
            setStroke((2 * d).toInt(), Color.argb(200, 255, 255, 255))
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        val box = FrameLayout(this).apply {
            background = bg
            elevation = 10 * d
            contentDescription = tr("עוזרת – דבר")
            addView(icon, FrameLayout.LayoutParams(size, size))
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs.bubbleX
            y = Prefs.bubbleY
        }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var downAt = 0L; var moved = false
        box.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; downAt = System.currentTimeMillis(); moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (abs(dx) > 12 * d || abs(dy) > 12 * d) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt(); lp.y = startY + dy.toInt()
                        runCatching { wm.updateViewLayout(box, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) { Prefs.bubbleX = lp.x; Prefs.bubbleY = lp.y }
                    else if (System.currentTimeMillis() - downAt > 700) stop(this)        // לחיצה ארוכה = הסתרה
                    else openAssistant()
                }
            }
            true
        }
        runCatching { wm.addView(box, lp) }.onSuccess { view = box }
    }

    private fun openAssistant() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra(MainActivity.EXTRA_ASSISTANT_VOICE, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    override fun onDestroy() {
        view?.let { runCatching { wm.removeView(it) } }
        view = null
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "driving_bubble"
        private const val ID = 4402
        private const val ACTION_STOP = "com.phonebook.app.BUBBLE_STOP"

        fun canShow(ctx: Context) = Settings.canDrawOverlays(ctx)

        /** מסך ההרשאה "הצגה מעל אפליקציות אחרות" */
        fun permissionIntent(ctx: Context) =
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName))

        fun start(ctx: Context) {
            Prefs.bubble = true
            ContextCompat.startForegroundService(ctx, Intent(ctx, DrivingBubbleService::class.java))
        }

        fun stop(ctx: Context) {
            Prefs.bubble = false
            ctx.stopService(Intent(ctx, DrivingBubbleService::class.java))
        }
    }
}
