package com.phonebook.app.data

import android.Manifest
import android.content.ContentProviderOperation
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

/**
 * חיבור לאנשי הקשר של הטלפון:
 *  - שמירת איש קשר בטלפון (כך הוא יופיע גם בוואטסאפ)
 *  - צלצול מיוחד לאיש קשר (הצלצול נקבע באנשי הקשר של הטלפון, והמערכת מנגנת אותו)
 */
object SystemContacts {
    val PERMISSIONS = arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)

    fun hasPermission(ctx: Context) = PERMISSIONS.all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }

    /** מזהה איש הקשר בטלפון לפי מספר, או null */
    fun findContactId(ctx: Context, number: String): Long? = try {
        val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
        ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getLong(0) else null }
    } catch (_: Exception) {
        null
    }

    /** שומר בטלפון אם עוד לא קיים. מחזיר את מזהה איש הקשר */
    fun ensureSaved(ctx: Context, c: Contact): Long? {
        findContactId(ctx, c.phone)?.let { return it }
        val ops = arrayListOf(
            ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                .build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, c.name)
                .build(),
            ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, c.phone)
                .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                .build(),
        )
        if (c.phone2.isNotBlank()) ops += ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
            .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, c.phone2)
            .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_HOME)
            .build()
        return try {
            ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            findContactId(ctx, c.phone)
        } catch (_: Exception) {
            null
        }
    }

    // ---------------- סנכרון עם אנשי הקשר של הטלפון ----------------

    /** כל המספרים שכבר שמורים בטלפון (9 ספרות אחרונות) */
    fun phoneTails(ctx: Context): HashSet<String> {
        val out = HashSet<String>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null
        )?.use { c -> while (c.moveToNext()) Phone.tail(c.getString(0) ?: "").takeIf { it.isNotEmpty() }?.let { out += it } }
        return out
    }

    /** קורא את כל אנשי הקשר מהטלפון (שם, עד 2 מספרים, אימייל, עיר וכתובת) */
    fun readAll(ctx: Context): List<Contact> {
        class Acc(var name: String = "", val phones: MutableList<String> = mutableListOf(), var email: String = "", var city: String = "", var street: String = "")
        val map = LinkedHashMap<Long, Acc>()
        ctx.contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(
                ContactsContract.Data.CONTACT_ID, ContactsContract.Data.MIMETYPE, ContactsContract.Data.DISPLAY_NAME,
                ContactsContract.Data.DATA1, ContactsContract.CommonDataKinds.StructuredPostal.CITY,
                ContactsContract.CommonDataKinds.StructuredPostal.STREET,
            ),
            "${ContactsContract.Data.MIMETYPE} IN (?,?,?)",
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
                ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE,
            ), null
        )?.use { c ->
            while (c.moveToNext()) {
                val a = map.getOrPut(c.getLong(0)) { Acc() }
                if (a.name.isBlank()) a.name = c.getString(2) ?: ""
                val v = c.getString(3) ?: ""
                when (c.getString(1)) {
                    ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE ->
                        if (v.isNotBlank() && a.phones.none { Phone.tail(it) == Phone.tail(v) && Phone.tail(v).isNotEmpty() }) a.phones += v.trim()
                    ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE -> if (a.email.isBlank()) a.email = v.trim()
                    else -> {
                        if (a.city.isBlank()) a.city = c.getString(4)?.trim() ?: ""
                        if (a.street.isBlank()) a.street = c.getString(5)?.trim() ?: ""
                    }
                }
            }
        }
        return map.values.filter { it.phones.isNotEmpty() }.map {
            Contact(
                id = java.util.UUID.randomUUID().toString(), name = it.name.ifBlank { it.phones[0] },
                phone = it.phones[0], phone2 = it.phones.getOrElse(1) { "" },
                city = it.city, address = it.street, email = it.email,
            )
        }
    }

    /** שומר בטלפון רשימת אנשי קשר (בלי לבדוק כפילויות – הבדיקה נעשית לפני) */
    fun saveMany(ctx: Context, list: List<Contact>, onProgress: (Int) -> Unit) {
        var done = 0
        list.chunked(100).forEach { chunk ->
            val ops = ArrayList<ContentProviderOperation>()
            chunk.forEach { c ->
                val back = ops.size
                ops += ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                    .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                    .withYieldAllowed(true)
                    .build()
                fun data(mime: String, vararg kv: Pair<String, Any?>) {
                    val b = ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, back)
                        .withValue(ContactsContract.Data.MIMETYPE, mime)
                    kv.forEach { (k, v) -> b.withValue(k, v) }
                    ops += b.build()
                }
                data(ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE,
                    ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME to c.name)
                if (c.phone.isNotBlank()) data(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE,
                    ContactsContract.CommonDataKinds.Phone.NUMBER to c.phone,
                    ContactsContract.CommonDataKinds.Phone.TYPE to ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                if (c.phone2.isNotBlank()) data(ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE,
                    ContactsContract.CommonDataKinds.Phone.NUMBER to c.phone2,
                    ContactsContract.CommonDataKinds.Phone.TYPE to ContactsContract.CommonDataKinds.Phone.TYPE_HOME)
                if (c.email.isNotBlank()) data(ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
                    ContactsContract.CommonDataKinds.Email.ADDRESS to c.email)
                if (c.city.isNotBlank() || c.address.isNotBlank()) data(ContactsContract.CommonDataKinds.StructuredPostal.CONTENT_ITEM_TYPE,
                    ContactsContract.CommonDataKinds.StructuredPostal.STREET to c.address,
                    ContactsContract.CommonDataKinds.StructuredPostal.CITY to c.city)
                if (c.details.isNotEmpty()) data(ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE,
                    ContactsContract.CommonDataKinds.Note.NOTE to c.details.joinToString("\n") { (k, v) -> "$k: $v" })
            }
            ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            done += chunk.size
            onProgress(done)
        }
    }

    /** קובע צלצול מיוחד (null = צלצול רגיל) */
    fun setRingtone(ctx: Context, c: Contact, ringtone: Uri?): Boolean {
        val id = ensureSaved(ctx, c) ?: return false
        return try {
            ctx.contentResolver.update(
                ContactsContract.Contacts.CONTENT_URI,
                ContentValues().apply { put(ContactsContract.Contacts.CUSTOM_RINGTONE, ringtone?.toString()) },
                "${ContactsContract.Contacts._ID}=?", arrayOf(id.toString())
            ) > 0
        } catch (_: Exception) {
            false
        }
    }

    fun getRingtone(ctx: Context, number: String): Uri? {
        val id = findContactId(ctx, number) ?: return null
        return try {
            ctx.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.CUSTOM_RINGTONE),
                "${ContactsContract.Contacts._ID}=?", arrayOf(id.toString()), null
            )?.use { c -> if (c.moveToFirst()) c.getString(0)?.let { Uri.parse(it) } else null }
        } catch (_: Exception) {
            null
        }
    }

    data class SyncResult(val imported: Int, val exported: Int)

    /**
     * סנכרון בין הספר האישי לאנשי הקשר של הטלפון.
     * toApp – מוסיף לספר האישי את מי שיש בטלפון ואין באפליקציה.
     * toPhone – שומר בטלפון את מי שיש בספר האישי ואין בטלפון.
     * כפילויות מזוהות לפי מספר הטלפון.
     */
    fun sync(ctx: Context, toApp: Boolean, toPhone: Boolean, progress: (String) -> Unit): SyncResult {
        var imported = 0
        var exported = 0
        if (toApp) {
            progress("קורא את אנשי הקשר של הטלפון...")
            val have = HashSet<String>()
            LocalDb.all(LocalDb.PERSONAL).forEach { c ->
                Phone.tail(c.phone).takeIf { it.isNotEmpty() }?.let { have += it }
                Phone.tail(c.phone2).takeIf { it.isNotEmpty() }?.let { have += it }
            }
            val fresh = readAll(ctx).filter { c ->
                val t = Phone.tail(c.phone)
                t.isEmpty() || have.add(t)
            }
            if (fresh.isNotEmpty()) {
                val batch = java.util.UUID.randomUUID().toString()
                LocalDb.upsertAll(LocalDb.PERSONAL, fresh, batch = batch)
                Prefs.lastBatch = batch
                Prefs.lastBatchCount = fresh.size
            }
            imported = fresh.size
        }
        if (toPhone) {
            progress("בודק מי חסר בטלפון...")
            val inPhone = phoneTails(ctx)
            val missing = LocalDb.all(LocalDb.PERSONAL).filter { c ->
                val t = Phone.tail(c.phone)
                t.isNotEmpty() && inPhone.add(t)
            }
            if (missing.isNotEmpty()) saveMany(ctx, missing) { d -> progress("שומר בטלפון: $d מתוך ${missing.size}") }
            exported = missing.size
        }
        return SyncResult(imported, exported)
    }
}
