@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.Assistant
import com.phonebook.app.net.Server
import kotlinx.coroutines.launch

private val SUGGESTIONS get() = listOf(
    tr("מצא את משפחת כהן מבני ברק"),
    tr("תתקשר ללוי מירושלים"),
    tr("נסח הודעת מזל טוב לחתונה ושלח בוואטסאפ"),
    tr("נסח הודעה קצרה שאני מאחר"),
)

@Composable
fun AssistantScreen(onSettings: () -> Unit, onSms: (String, String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val history = remember { mutableStateListOf<Assistant.Msg>() }
    var input by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    var reportIndex by remember { mutableStateOf<Int?>(null) }
    var autoCall by remember { mutableStateOf<Assistant.Action?>(null) }
    var countdown by remember { mutableIntStateOf(3) }

    fun send(q: String) {
        val text = q.trim()
        if (text.isEmpty() || busy) return
        history += Assistant.Msg(true, text)
        input = ""
        scope.launch {
            busy = true
            val reply = runCatching { Assistant.ask(history.toList()) }.getOrElse { Assistant.Msg(false, tr("שגיאה: {0}", it.message)) }
            history += reply
            busy = false
            val calls = reply.actions.filter { it.kind == "call" }
            if (Prefs.aiAutoCall && calls.size == 1 && reply.actions.size == 1) autoCall = calls[0]
        }
    }
    var personal by remember { mutableStateOf(Prefs.aiPersonal) }
    var autoDial by remember { mutableStateOf(Prefs.aiAutoCall) }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!said.isNullOrBlank()) send(said)
    }
    fun listen() {
        try {
            speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL")
                putExtra(RecognizerIntent.EXTRA_PROMPT, tr("דבר עם העוזרת"))
            })
        } catch (_: Exception) {
            toast(ctx, tr("זיהוי דיבור לא זמין בטלפון"))
        }
    }
    fun doAction(a: Assistant.Action) {
        when (a.kind) {
            "call" -> Actions.call(ctx, a.number)
            "sms" -> onSms(a.number, a.text)
            else -> {
                val num = com.phonebook.app.data.Phone.international(a.number)
                val url = "https://wa.me/$num" + if (a.text.isNotBlank()) "?text=" + Uri.encode(a.text) else ""
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { toast(ctx, tr("וואטסאפ לא מותקן")) }
            }
        }
    }

    // חיוג אוטומטי: 3 שניות שבהן אפשר לבטל
    LaunchedEffect(autoCall) {
        val a = autoCall ?: return@LaunchedEffect
        for (i in 3 downTo 1) { countdown = i; kotlinx.coroutines.delay(1000) }
        if (autoCall == a) { autoCall = null; doAction(a) }
    }

    LaunchedEffect(history.size, busy) {
        val last = listState.layoutInfo.totalItemsCount - 1
        if (last > 0) listState.animateScrollToItem(last)
    }

    reportIndex?.let { i ->
        AlertDialog(
            onDismissRequest = { reportIndex = null },
            title = { Text(tr("לדווח על התשובה?")) },
            text = { Text(tr("התשובה תוסתר ותישלח לבדיקה, כדי לשפר את העוזרת.")) },
            confirmButton = {
                TextButton(onClick = {
                    reportIndex = null
                    val answer = history.getOrNull(i) ?: return@TextButton
                    val question = history.take(i).lastOrNull { it.user }?.text ?: ""
                    history[i] = Assistant.Msg(false, tr("התשובה דווחה והוסתרה."))
                    scope.launch {
                        runCatching { Server.reportAi(question, answer.text) }
                            .onSuccess { toast(ctx, tr("תודה, הדיווח נשלח")) }
                            .onFailure { toast(ctx, tr("התשובה הוסתרה. כדי לשלוח את הדיווח צריך להתחבר בהגדרות.")) }
                    }
                }) { Text(tr("דווח")) }
            },
            dismissButton = { TextButton(onClick = { reportIndex = null }) { Text(tr("ביטול")) } },
        )
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                AppCard {
                    Column(Modifier.padding(16.dp)) {
                        Text(tr("שלום! אני מחפשת אנשי קשר, מנסחת הודעות ומכינה לך כפתור לחיוג, SMS או וואטסאפ. אפשר גם לדבר איתי 🎤"))
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(personal, { personal = it; Prefs.aiPersonal = it })
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (personal) tr("מחפשת גם בספר האישי שלך") else tr("מחפשת רק בספר הכללי (הספר האישי לא נשלח)"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(autoDial, { autoDial = it; Prefs.aiAutoCall = it })
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (autoDial) tr("מחייגת לבד כשמבקשים להתקשר (אפשר לבטל תוך 3 שניות)") else tr("מציגה כפתור חיוג – אתה לוחץ"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (history.isNotEmpty()) TextButton(onClick = { history.clear() }) { Text(tr("🗑️ שיחה חדשה")) }
                    }
                }
            }
            if (Prefs.aiKey.isBlank() && !Server.loggedIn()) item {
                InfoCard(tr("כדי להשתמש בעוזרת צריך להתחבר לספר הכללי בהגדרות. לחץ כאן."), Modifier.clickable { onSettings() })
            }
            itemsIndexed(history) { index, m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.Start else Arrangement.End) {
                    Column(horizontalAlignment = if (m.user) Alignment.Start else Alignment.End) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (m.user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLowest,
                            shadowElevation = if (m.user) 0.dp else 1.dp,
                            modifier = Modifier.widthIn(max = 320.dp)
                        ) {
                            SelectionContainer {
                                Text(
                                    m.text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    color = if (m.user) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        if (!m.user) m.actions.forEach { a ->
                            Button(onClick = { doAction(a) }, modifier = Modifier.padding(top = 6.dp)) { Text(a.label) }
                        }
                        if (!m.user) Row {
                            TextButton(onClick = {
                                clipboard.setText(AnnotatedString(m.text)); toast(ctx, tr("הועתק"))
                            }) {
                                Icon(Icons.Filled.ContentCopy, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(tr("העתק"))
                            }
                            TextButton(onClick = { reportIndex = index }) {
                                Icon(Icons.Filled.Flag, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(tr("דווח"))
                            }
                        }
                    }
                }
            }
            autoCall?.let { a ->
                item {
                    AppCard {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("📞 מחייג ל{0} בעוד {1}…", a.name, countdown), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { autoCall = null; doAction(a) }) { Text(tr("עכשיו")) }
                            TextButton(onClick = { autoCall = null }) { Text(tr("ביטול"), color = CallRed) }
                        }
                    }
                }
            }
            if (busy) item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                }
            }
        }
        if (history.isEmpty()) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SUGGESTIONS.forEach { s -> SuggestionChip(onClick = { send(s) }, label = { Text(s) }) }
            }
        }
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text(tr("מה לנסח או את מי לחפש?")) },
                maxLines = 4,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            if (input.isBlank()) FilledTonalIconButton(onClick = { listen() }, enabled = !busy, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.Mic, tr("דבר"))
            } else FilledIconButton(onClick = { send(input) }, enabled = !busy, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.Send, tr("שלח"))
            }
        }
    }
}
