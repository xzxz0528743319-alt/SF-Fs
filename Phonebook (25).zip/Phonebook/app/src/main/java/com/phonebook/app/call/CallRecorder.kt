package com.phonebook.app.call

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * הקלטת שיחה דרך המיקרופון.
 * אנדרואיד לא מאפשר לאפליקציות להקליט ישירות את הצד השני של השיחה,
 * לכן הצד השני נשמע טוב בהקלטה רק כשהרמקול פועל.
 * ההקלטות נשמרות בתיקייה Recordings/ספר טלפונים.
 */
object CallRecorder {
    val recording = MutableStateFlow(false)
    val startedAt = MutableStateFlow(0L)
    /** true = ההקלטה קולטת את שני הצדדים ישירות מהשיחה (בלי צורך ברמקול) */
    val bothSides = MutableStateFlow(false)

    private var rec: MediaRecorder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private var appCtx: Context? = null

    val folder: String
        get() = (if (Build.VERSION.SDK_INT >= 31) Environment.DIRECTORY_RECORDINGS else Environment.DIRECTORY_MUSIC) + "/ספר טלפונים"

    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** מחזיר null אם ההקלטה התחילה, או הודעת שגיאה */
    @Synchronized
    fun start(ctx: Context, number: String): String? {
        if (rec != null) return null
        if (!hasPermission(ctx)) return "צריך לאשר הרשאת מיקרופון"
        val app = ctx.applicationContext
        appCtx = app
        RecordingService.start(app)
        return try {
            val time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss"))
            val safe = number.filter { it.isDigit() || it == '+' }.ifBlank { "חסוי" }
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, "שיחה $safe $time.m4a")
                put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
                put(MediaStore.Audio.Media.RELATIVE_PATH, folder)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val u = app.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                ?: return "לא ניתן ליצור קובץ הקלטה"
            uri = u
            val fd = app.contentResolver.openFileDescriptor(u, "w") ?: return "לא ניתן ליצור קובץ הקלטה"
            pfd = fd
            // קודם מנסים להקליט את שני הצדדים ישירות מהשיחה (חלק מהמכשירים מאפשרים לאפליקציית הטלפון),
            // ואם המכשיר חוסם – מקליטים מהמיקרופון.
            var started: MediaRecorder? = null
            for (src in listOf(MediaRecorder.AudioSource.VOICE_CALL, MediaRecorder.AudioSource.MIC)) {
                @Suppress("DEPRECATION")
                val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(app) else MediaRecorder()
                try {
                    r.setAudioSource(src)
                    r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                    r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    r.setAudioEncodingBitRate(96_000)
                    r.setAudioSamplingRate(if (src == MediaRecorder.AudioSource.VOICE_CALL) 16_000 else 44_100)
                    r.setOutputFile(fd.fileDescriptor)
                    r.prepare()
                    r.start()
                    started = r
                    bothSides.value = src == MediaRecorder.AudioSource.VOICE_CALL
                    break
                } catch (_: Exception) {
                    runCatching { r.reset(); r.release() }
                }
            }
            val r = started ?: throw IllegalStateException("המכשיר לא מאפשר הקלטה")
            rec = r
            startedAt.value = System.currentTimeMillis()
            recording.value = true
            null
        } catch (e: Exception) {
            cleanup(delete = true)
            "ההקלטה נכשלה: ${e.message ?: "המכשיר לא מאפשר"}"
        }
    }

    /** עוצר ושומר. מחזיר true אם נשמרה הקלטה */
    @Synchronized
    fun stop(): Boolean {
        val r = rec ?: return false
        var ok = true
        try {
            r.stop()
        } catch (_: Exception) {
            ok = false // הקלטה קצרה מדי
        }
        cleanup(delete = !ok)
        return ok
    }

    private fun cleanup(delete: Boolean) {
        try { rec?.release() } catch (_: Exception) {}
        rec = null
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
        val u = uri
        val app = appCtx
        if (u != null && app != null) {
            try {
                if (delete) app.contentResolver.delete(u, null, null)
                else app.contentResolver.update(u, ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }, null, null)
            } catch (_: Exception) {}
        }
        uri = null
        app?.let { RecordingService.stop(it) }
        recording.value = false
    }
}
