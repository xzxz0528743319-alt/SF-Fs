package com.phonebook.app.net

import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * עוזרת AI (סוכן): מחפשת אנשי קשר בעצמה, מנסחת הודעות ומכינה כפתורי פעולה
 * (חיוג / SMS / וואטסאפ). שום פעולה לא מתבצעת לבד – המשתמש לוחץ על הכפתור.
 * הספר האישי נשלח רק אם המשתמש הפעיל זאת בהגדרות.
 */
object Assistant {
    data class Action(val kind: String, val name: String, val number: String, val text: String = "") {
        val label: String
            get() = when (kind) {
                "call" -> "📞 חייג ל$name"
                "sms" -> "💬 שלח SMS ל$name"
                else -> "🟢 וואטסאפ ל$name"
            }
    }

    data class Msg(val user: Boolean, val text: String, val actions: List<Action> = emptyList())

    private fun tool(name: String, desc: String, props: JSONObject, required: List<String>) = JSONObject()
        .put("name", name).put("description", desc)
        .put("input_schema", JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(required)))

    private fun str(desc: String) = JSONObject().put("type", "string").put("description", desc)

    private val tools = JSONArray()
        .put(
            tool(
                "search_contacts",
                "חיפוש אנשי קשר באלפון. כל מילה בשאילתה צריכה להופיע בשם, עיר, כתובת, שם האב, חם, בית כנסת, שדה נוסף או במספר. " +
                    "חפש במילים קצרות (למשל שם משפחה בלבד, או שם משפחה + עיר). אם אין תוצאות – נסה שוב בניסוח אחר (בלי עיר, כתיב אחר).",
                JSONObject()
                    .put("query", str("מילות החיפוש"))
                    .put("city", str("עיר מדויקת לסינון (לא חובה)")),
                listOf("query")
            )
        )
        .put(
            tool(
                "propose_action",
                "מציג למשתמש כפתור לביצוע פעולה (המשתמש לוחץ בעצמו). השתמש כשהמשתמש מבקש להתקשר, לשלוח הודעה או וואטסאפ למישהו. " +
                    "את המספר קח רק מתוצאות search_contacts או ממה שהמשתמש כתב.",
                JSONObject()
                    .put("kind", JSONObject().put("type", "string").put("enum", JSONArray(listOf("call", "sms", "whatsapp"))))
                    .put("name", str("שם איש הקשר"))
                    .put("number", str("מספר הטלפון"))
                    .put("text", str("נוסח ההודעה (ל-sms / whatsapp)")),
                listOf("kind", "name", "number")
            )
        )

    private fun line(c: Contact, book: String) =
        "- [$book] ${c.name} | טל׳ ${c.phone}${if (c.phone2.isNotBlank()) ", " + c.phone2 else ""}" +
            (if (c.city.isNotBlank()) " | עיר: ${c.city}" else "") +
            (if (c.address.isNotBlank()) " | כתובת: ${c.address}" else "") +
            c.details.joinToString("") { (k, v) -> " | $k: $v" }

    private fun search(input: JSONObject): String {
        val q = input.optString("query")
        val city = input.optString("city").ifBlank { null }
        val out = mutableListOf<String>()
        LocalDb.search(LocalDb.SHARED, q, 0, city, 15).forEach { out += line(it, "כללי") }
        if (Prefs.aiPersonal) LocalDb.search(LocalDb.PERSONAL, q, 0, city, 15).forEach { out += line(it, "אישי") }
        val total = out.size
        return if (total == 0) "לא נמצאו תוצאות עבור \"$q\"${city?.let { " בעיר $it" } ?: ""}."
        else out.take(25).joinToString("\n") + if (total > 25) "\n(יש עוד תוצאות – כדאי לצמצם)" else ""
    }

    /** קריאה לעוזרת בשרת. אם Google עמוס – מנסים שוב אוטומטית (עד 4 פעמים) */
    private fun callServer(body: String): String {
        var last: Exception? = null
        repeat(4) { i ->
            try {
                return Server.function("assistant", body)
            } catch (e: ApiError) {
                val m = e.message ?: ""
                val busy = m.contains("high demand", true) || m.contains("עמוס") || m.contains("overloaded", true) ||
                    m.contains("503") || m.contains("429") || m.contains("try again", true) || m.contains("UNAVAILABLE", true)
                if (!busy) throw e
                last = e
                Thread.sleep(1500L * (i + 1))
            } catch (e: java.io.IOException) {
                // אין חיבור לשרת – מנסים שוב, ואם לא עובד מסבירים בפשטות
                last = e
                if (i == 3) throw ApiError("אין חיבור לשרת. בדוק שיש אינטרנט בטלפון ונסה שוב.")
                Thread.sleep(1500L * (i + 1))
            }
        }
        throw ApiError("העוזרת עמוסה כרגע – נסה שוב בעוד דקה")
    }

    /** שאלה פשוטה בלי כלים (למשל לתרגום האפליקציה). מחזיר את הטקסט של התשובה */
    suspend fun complete(prompt: String, maxTokens: Int = 8000): String = withContext(Dispatchers.IO) {
        val body = JSONObject()
            .put("model", Prefs.aiModel)
            .put("max_tokens", maxTokens)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val key = Prefs.aiKey
        val res = if (key.isBlank()) {
            if (!Server.loggedIn()) throw ApiError("כדי לתרגם צריך להתחבר לספר הכללי בהגדרות")
            JSONObject(callServer(body.toString()))
        } else {
            val req = Request.Builder()
                .url("https://api.anthropic.com/v1/messages")
                .header("x-api-key", key)
                .header("anthropic-version", "2023-06-01")
                .post(body.toString().toRequestBody(Net.JSON))
                .build()
            JSONObject(Net.execute(req))
        }
        val content = res.optJSONArray("content") ?: JSONArray()
        (0 until content.length()).map { content.getJSONObject(it) }
            .filter { it.optString("type") == "text" }.joinToString("") { it.optString("text") }
    }

    suspend fun ask(history: List<Msg>): Msg = withContext(Dispatchers.IO) {
        val key = Prefs.aiKey
        // בלי מפתח אישי – העוזרת עובדת דרך השרת של הספר הכללי
        val viaServer = key.isBlank()
        if (viaServer && !Server.loggedIn())
            throw ApiError("כדי להשתמש בעוזרת צריך להתחבר לספר הכללי בהגדרות")

        val books = if (Prefs.aiPersonal) "בספר הכללי ובספר האישי" else "בספר הכללי (הספר האישי לא זמין לך)"
        val system = """
            את עוזרת חכמה בתוך אפליקציית ספר טלפונים בעברית. את יכולה:
            1. לחפש אנשי קשר $books עם הכלי search_contacts – חפשי בעצמך, אל תבקשי מהמשתמש לחפש.
            2. לנסח הודעות (SMS / וואטסאפ) בעברית טבעית, קצרה ומכבדת.
            3. להכין כפתור חיוג / SMS / וואטסאפ עם הכלי propose_action, כשהמשתמש רוצה להתקשר או לשלוח למישהו.
            כללים: אל תמציאי מספרים או פרטים – רק ממה שהכלים החזירו. אם יש כמה התאמות – הציגי אותן בקצרה ושאלי למי הכוונה.
            ענִי תמיד בעברית, בקצרה ובפשטות. כשמבקשים רק נוסח הודעה – תני את הנוסח בלבד, בלי הקדמות.
        """.trimIndent()

        val msgs = JSONArray()
        history.takeLast(20).dropWhile { !it.user }.forEach {
            msgs.put(JSONObject().put("role", if (it.user) "user" else "assistant").put("content", it.text.ifBlank { "..." }))
        }

        val actions = mutableListOf<Action>()
        val text = StringBuilder()
        repeat(6) {
            val body = JSONObject()
                .put("model", Prefs.aiModel)
                .put("max_tokens", 1024)
                .put("system", system)
                .put("tools", tools)
                .put("messages", msgs)
            val res = if (viaServer) JSONObject(callServer(body.toString())) else {
                val req = Request.Builder()
                    .url("https://api.anthropic.com/v1/messages")
                    .header("x-api-key", key)
                    .header("anthropic-version", "2023-06-01")
                    .post(body.toString().toRequestBody(Net.JSON))
                    .build()
                JSONObject(Net.execute(req))
            }
            val content = res.getJSONArray("content")
            val results = JSONArray()
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                when (b.optString("type")) {
                    "text" -> text.append(b.optString("text"))
                    "tool_use" -> {
                        val input = b.optJSONObject("input") ?: JSONObject()
                        val out = when (b.optString("name")) {
                            "search_contacts" -> search(input)
                            "propose_action" -> {
                                val a = Action(
                                    input.optString("kind", "call"), input.optString("name"),
                                    input.optString("number"), input.optString("text")
                                )
                                if (a.number.isNotBlank()) {
                                    actions += a; "הכפתור הוצג למשתמש."
                                } else "חסר מספר טלפון."
                            }
                            else -> "כלי לא מוכר"
                        }
                        results.put(JSONObject().put("type", "tool_result").put("tool_use_id", b.optString("id")).put("content", out))
                    }
                }
            }
            if (res.optString("stop_reason") != "tool_use" || results.length() == 0) {
                return@withContext Msg(false, text.toString().trim(), actions)
            }
            if (viaServer) {
                // דרך השרת (Gemini): מחזירים את תוצאות הכלים כטקסט רגיל – כך אין צורך ב"חתימות" של Gemini
                val calls = StringBuilder()
                val outs = StringBuilder()
                for (i in 0 until content.length()) {
                    val b = content.getJSONObject(i)
                    if (b.optString("type") == "tool_use") calls.append("[${b.optString("name")} ${b.optJSONObject("input") ?: JSONObject()}]\n")
                }
                for (i in 0 until results.length()) outs.append(results.getJSONObject(i).optString("content")).append("\n\n")
                msgs.put(JSONObject().put("role", "assistant").put("content", (text.toString() + "\n" + calls).trim()))
                msgs.put(JSONObject().put("role", "user").put("content",
                    "תוצאות הכלים (המשתמש לא רואה אותן):\n$outs\nהמשיכי לענות למשתמש לפי התוצאות. אם צריך – השתמשי שוב בכלים."))
            } else {
                msgs.put(JSONObject().put("role", "assistant").put("content", content))
                msgs.put(JSONObject().put("role", "user").put("content", results))
            }
            if (text.isNotEmpty()) text.append("\n")
        }
        Msg(false, text.toString().trim().ifBlank { "לא הצלחתי להשלים את הבקשה. נסה לנסח אחרת." }, actions)
    }
}
