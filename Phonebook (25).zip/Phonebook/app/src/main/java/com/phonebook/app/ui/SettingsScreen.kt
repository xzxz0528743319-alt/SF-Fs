@file:OptIn(ExperimentalMaterial3Api::class)

package com.phonebook.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.ImportExport
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import com.phonebook.app.data.SystemContacts
import com.phonebook.app.net.Server
import com.phonebook.app.net.SharedBook
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
fun SettingsScreen(onClose: () -> Unit, onTrash: () -> Unit, onAdmin: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        OverlayTopBar(tr("הגדרות"), onClose)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Section(tr("חשבון וספר כללי")) { AccountSection(onAdmin) }
            Section(tr("💻 חיבור למחשב")) { PcLinkSection() }
            Section(tr("סנכרון עם אנשי הקשר של הטלפון")) { PhoneSyncSection() }
            Section(tr("ייבוא וגיבוי")) { ImportExportSection() }
            Section(tr("גיבוי אוטומטי וסל מחזור")) { BackupSection(onTrash) }
            Section(tr("נעילה ופרטיות")) { LockSection() }
            Section(tr("הקלטת שיחות")) { RecordingSection() }
            Section(tr("סיסמת מחיקה")) { DeletePasswordSection() }
            Section(tr("סינון ספאם")) { SpamSection() }
            Section(tr("מספרים חסומים")) { BlockedSection() }
            Section(tr("עוזרת AI")) { AiSection() }
            Section("🌐 " + tr("שפה") + if (I18n.code.value != "en") " / Language" else "") { LanguageSection() }
            Section(tr("מראה וגודל טקסט")) { ThemeSection() }
            Section(tr("ברירת מחדל והרשאות")) { DefaultsSection() }
            Section(tr("משוב והצעות")) { FeedbackSection() }
            Section(tr("גרסה ועדכונים")) { VersionSection() }
            val uriHandler = LocalUriHandler.current
            TextButton(onClick = { uriHandler.openUri(Prefs.PRIVACY_URL) }) { Text(tr("מדיניות פרטיות")) }
            Text(
                tr("ללא פרסומות וללא מעקב. אנשי קשר בספר האישי נשמרים רק בטלפון."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(4.dp)
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun BackupSection(onTrash: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var auto by remember { mutableStateOf(Prefs.autoBackup) }
    var last by remember { mutableLongStateOf(Prefs.lastBackup) }
    val dbv by LocalDb.changes.collectAsState()
    val trashCount by produceState(0, dbv) { value = withContext(Dispatchers.IO) { LocalDb.trashCount() } }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(tr("גיבוי שבועי אוטומטי של הספר האישי"), modifier = Modifier.weight(1f))
        Switch(checked = auto, onCheckedChange = { auto = it; Prefs.autoBackup = it })
    }
    Text(
        (if (last > 0) tr("גיבוי אחרון: ") + java.time.Instant.ofEpochMilli(last).atZone(java.time.ZoneId.systemDefault())
            .format(java.time.format.DateTimeFormatter.ofPattern("d.M.yyyy HH:mm")) + ". " else tr("עדיין לא בוצע גיבוי. ")) +
            tr("הקבצים נשמרים בתיקייה {0} (5 האחרונים). בנוסף אנדרואיד מגבה את האפליקציה לחשבון הגוגל שלך.", com.phonebook.app.data.Backup.folder),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { com.phonebook.app.data.Backup.backupNow(ctx) } }
                    .onSuccess { n -> last = Prefs.lastBackup; toast(ctx, if (n > 0) tr("גובו {0} אנשי קשר", n) else tr("הספר האישי ריק")) }
                    .onFailure { toast(ctx, tr("הגיבוי נכשל: {0}", it.message)) }
            }
        }) { Text(tr("גבה עכשיו")) }
        OutlinedButton(onClick = onTrash) { Text(tr("🗑️ סל מחזור ({0})", trashCount)) }
    }
}

@Composable
private fun LockSection() {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Prefs.lockEnabled) }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(tr("נעילת האפליקציה בטביעת אצבע או בקוד הטלפון"), modifier = Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = { want ->
            val activity = ctx as? com.phonebook.app.MainActivity
            if (want && activity?.canLock() != true) toast(ctx, tr("קודם צריך להגדיר נעילת מסך (קוד או טביעת אצבע) בהגדרות הטלפון"))
            else { on = want; Prefs.lockEnabled = want }
        })
    }
    Text(
        tr("כשהנעילה פעילה, צריך לאמת כדי לפתוח את האפליקציה (גם אחרי דקה ברקע). שיחות נכנסות לא ננעלות."),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun VersionSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var update by remember { mutableStateOf<com.phonebook.app.net.Updater.Update?>(null) }
    Text(tr("גרסה מותקנת: {0}", com.phonebook.app.net.Updater.currentVersionName(ctx)), fontWeight = FontWeight.SemiBold)
    if (com.phonebook.app.net.Updater.fromPlayStore(ctx)) {
        Text(tr("העדכונים מגיעים מחנות Google Play."), style = MaterialTheme.typography.bodySmall)
    } else Button(enabled = !checking, onClick = {
        checking = true
        scope.launch {
            runCatching { com.phonebook.app.net.Updater.check(ctx) }
                .onSuccess { u -> if (u == null) toast(ctx, tr("יש לך את הגרסה האחרונה ✓")) else update = u }
                .onFailure { toast(ctx, tr("הבדיקה נכשלה – בדוק את החיבור לאינטרנט")) }
            checking = false
        }
    }) { Text(if (checking) tr("בודק…") else tr("בדוק עדכונים")) }
    update?.let { UpdateDialog(it) { update = null } }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    AppCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun Input(label: String, value: String, password: Boolean = false, type: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else type),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun AccountSection(onAdmin: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val session by Prefs.session.collectAsState()
    var url by remember { mutableStateOf(Prefs.serverUrl) }
    var key by remember { mutableStateOf(Prefs.serverKey) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showServer by remember { mutableStateOf(!Server.configured()) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmUpload by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    val dbv by LocalDb.changes.collectAsState()
    val count by produceState(0, dbv) { value = withContext(Dispatchers.IO) { LocalDb.count(LocalDb.SHARED) } }

    fun go(block: suspend () -> Unit) = scope.launch {
        busy = true
        runCatching { block() }.onFailure { toast(ctx, it.message ?: tr("שגיאה")) }
        busy = false
    }

    if (showServer) {
        Text(tr("פרטי השרת של הספר הכללי (מקבלים פעם אחת ממי שהקים את השרת):"), style = MaterialTheme.typography.bodySmall)
        Input(tr("כתובת שרת"), url, type = KeyboardType.Uri) { url = it }
        Input(tr("מפתח ציבורי"), key) { key = it }
        Button(onClick = {
            Prefs.serverUrl = url; Prefs.serverKey = key
            showServer = !Server.configured()
            toast(ctx, if (Server.configured()) tr("נשמר") else tr("חסרים פרטים"))
        }) { Text(tr("שמור פרטי שרת")) }
    } else {
        TextButton(onClick = { showServer = true }) { Text(tr("שינוי פרטי שרת")) }
    }

    if (session == null) {
        Input(tr("אימייל"), email, type = KeyboardType.Email) { email = it }
        Input(tr("סיסמה (לפחות 6 תווים)"), password, password = true) { password = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = {
                go { Server.signIn(email, password); toast(ctx, tr("התחברת")); SharedBook.sync() }
            }) { Text(tr("התחברות")) }
            OutlinedButton(enabled = !busy, onClick = {
                go {
                    if (Server.signUp(email, password)) {
                        toast(ctx, tr("נרשמת והתחברת")); SharedBook.sync()
                    } else toast(ctx, tr("נשלח אליך מייל אישור. אשר אותו ואז התחבר."))
                }
            }) { Text(tr("הרשמה")) }
        }
        Text(tr("האימייל משמש רק להתחברות ולא מתפרסם."), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
        Text("מחובר: ${ltr(session ?: "")}")
        Text(tr("רשומות בספר הכללי: {0}", count))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = { go { val n = SharedBook.sync(); toast(ctx, tr("סונכרן ({0} עדכונים)", n)) } }) { Text(tr("סנכרן עכשיו")) }
            OutlinedButton(enabled = !busy, onClick = {
                Server.logout()
                LocalDb.clear(LocalDb.SHARED)
            }) { Text(tr("התנתק")) }
        }
        if (!Prefs.approved) InfoCard(tr("החשבון שלך ממתין לאישור מנהל. אחרי האישור תוכל לראות את הספר הכללי."))
        if (Prefs.isAdmin) Button(onClick = onAdmin) { Text(tr("🛡️ ניהול הספר הכללי")) }
        if (Prefs.approved) OutlinedButton(enabled = !busy, onClick = { confirmUpload = true }) {
            Text(tr("📤 העתק את כל הספר האישי לספר הכללי"))
        }
        progress?.let { (d, t) ->
            Text(if (t == 0) tr("בודק כפילויות...") else tr("מעלה לספר הכללי: {0} מתוך {1}", d, t))
            LinearProgressIndicator(progress = { if (t == 0) 0f else d.toFloat() / t }, modifier = Modifier.fillMaxWidth())
        }
        TextButton(onClick = { confirmDelete = true }) { Text(tr("מחיקת החשבון"), color = CallRed) }
    }
    if (confirmUpload) AlertDialog(
        onDismissRequest = { confirmUpload = false },
        title = { Text(tr("להעתיק את הספר האישי לספר הכללי?")) },
        text = {
            Text(
                tr("כל אנשי הקשר מהספר האישי ({0}) יועתקו גם לספר הכללי, וכל מי שמחובר יראה אותם. ", LocalDb.count(LocalDb.PERSONAL)) +
                    tr("מי שכבר נמצא בספר הכללי (לפי מספר טלפון) לא יועתק שוב. הספר האישי נשאר כמו שהוא. ") +
                    tr("זה יכול לקחת כמה דקות – לא לסגור את האפליקציה.") +
                    if (Prefs.isAdmin) "" else tr("\n\nהרשומות ימתינו לאישור מנהל.")
            )
        },
        confirmButton = {
            TextButton(onClick = {
                confirmUpload = false
                go {
                    progress = 0 to 0
                    try {
                        val n = SharedBook.uploadPersonal { d, t -> progress = d to t }
                        toast(ctx, if (n == 0) tr("כל אנשי הקשר כבר נמצאים בספר הכללי") else tr("הועתקו {0} אנשי קשר לספר הכללי", n))
                    } finally { progress = null }
                }
            }) { Text(tr("העתק")) }
        },
        dismissButton = { TextButton(onClick = { confirmUpload = false }) { Text(tr("ביטול")) } },
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text(tr("למחוק את החשבון?")) },
        text = { Text(tr("החשבון וכל הרשומות שהוספת לספר הכללי יימחקו לצמיתות. הספר האישי שבטלפון לא נפגע.")) },
        confirmButton = {
            TextButton(onClick = {
                confirmDelete = false
                go {
                    Server.deleteAccount()
                    LocalDb.clear(LocalDb.SHARED)
                    toast(ctx, tr("החשבון נמחק"))
                }
            }) { Text(tr("מחק לצמיתות"), color = CallRed) }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(tr("ביטול")) } },
    )
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
}

@Composable
private fun LanguageSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var open by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var custom by remember { mutableStateOf("") }

    fun choose(l: I18n.Lang) {
        open = false
        if (I18n.isReady(ctx, l.code)) { I18n.apply(ctx, l); return }
        scope.launch {
            progress = 0 to 0
            runCatching { I18n.translate(ctx, l) { d, t -> progress = d to t } }
                .onSuccess { I18n.apply(ctx, l); toast(ctx, "✓ " + l.name) }
                .onFailure { toast(ctx, tr("התרגום נכשל: {0}", it.message)) }
            progress = null
        }
    }

    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(I18n.current.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        OutlinedButton(enabled = progress == null, onClick = { open = true }) { Text(tr("בחירת שפה")) }
    }
    Text(
        tr("עברית ואנגלית מוכנות מראש. כל שפה אחרת מתורגמת פעם אחת בעזרת העוזרת (צריך להיות מחובר לספר הכללי) ואז נשמרת בטלפון."),
        style = MaterialTheme.typography.bodySmall
    )
    progress?.let { (d, t) ->
        Text(if (t == 0) tr("מתחיל לתרגם…") else tr("מתרגם… {0} מתוך {1}", d, t))
        LinearProgressIndicator(progress = { if (t == 0) 0f else d.toFloat() / t }, modifier = Modifier.fillMaxWidth())
    }
    if (open) AlertDialog(
        onDismissRequest = { open = false },
        title = { Text(tr("בחירת שפה") + " · Language") },
        text = {
            Column {
                androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(I18n.LANGS.size) { i ->
                        val l = I18n.LANGS[i]
                        val sel = l.code == I18n.code.value
                        Row(
                            Modifier.fillMaxWidth().clickable { choose(l) }.padding(vertical = 10.dp),
                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                        ) {
                            Text(l.name, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.weight(1f))
                            Text(
                                if (sel) "✓" else if (I18n.isReady(ctx, l.code)) "" else "⬇",
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    custom, { custom = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text(tr("שפה אחרת (כתוב את שמה)")) }
                )
            }
        },
        confirmButton = {
            TextButton(enabled = custom.isNotBlank(), onClick = {
                val name = custom.trim()
                choose(I18n.Lang("x-" + name.lowercase().replace(Regex("\\s+"), "-"), name, name, rtl = false))
            }) { Text(tr("תרגם")) }
        },
        dismissButton = { TextButton(onClick = { open = false }) { Text(tr("סגור")) } },
    )
}

@Composable
private fun PcLinkSection() {
    val ctx = LocalContext.current
    val session by Prefs.session.collectAsState()
    val running by com.phonebook.app.pc.PcLinkService.running.collectAsState()
    var on by remember { mutableStateOf(Prefs.pcLink) }
    Text(
        tr("מחייגים ושולחים הודעות מהמחשב – והטלפון מבצע. במחשב פותחים את \"ספר טלפונים למחשב\" (מורידים מדף ההורדה) ") +
            tr("ונכנסים עם אותו מייל וסיסמה של הספר הכללי. מדברים בטלפון, או באוזניות בלוטות'."),
        style = MaterialTheme.typography.bodySmall
    )
    if (session == null) {
        InfoCard(tr("כדי לחבר למחשב צריך קודם להתחבר לספר הכללי (למעלה)."))
        return
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Switch(on, {
            on = it
            if (it) com.phonebook.app.pc.PcLinkService.start(ctx) else com.phonebook.app.pc.PcLinkService.stop(ctx)
        })
        Spacer(Modifier.width(10.dp))
        Text(if (on && running) tr("✅ מחובר – אפשר לחייג מהמחשב") else if (on) tr("מתחבר…") else tr("כבוי"))
    }
}

@Composable
private fun PhoneSyncSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var toApp by remember { mutableStateOf(true) }
    var toPhone by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }

    fun run() = scope.launch {
        status = tr("מתחיל...")
        runCatching {
            withContext(Dispatchers.IO) { SystemContacts.sync(ctx, toApp, toPhone) { status = it } }
        }.onSuccess { r ->
            val parts = mutableListOf<String>()
            if (toApp) parts += tr("נוספו {0} לספר האישי", r.imported)
            if (r.updated > 0) parts += tr("הושלמו פרטים אצל {0}", r.updated)
            if (toPhone) parts += tr("נשמרו {0} בטלפון", r.exported)
            toast(ctx, tr("הסנכרון הסתיים: ") + parts.joinToString(", "))
        }.onFailure { toast(ctx, tr("הסנכרון נכשל: {0}", it.message)) }
        status = null
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.all { it }) run() else toast(ctx, tr("צריך לאשר גישה לאנשי הקשר"))
    }

    Text(
        tr("מחבר בין הספר האישי לאנשי הקשר של הטלפון – מכל האפליקציות והחשבונות (Google, סמסונג, וואטסאפ, SIM). ") +
            tr("נלקחים גם עיר, כתובת, אימייל, מקום עבודה, תפקיד, יום הולדת, כינוי והערה. מי שכבר קיים – לפי מספר טלפון – לא נוסף שוב, ") +
            tr("ורק משלימים אצלו פרטים שחסרים."),
        style = MaterialTheme.typography.bodySmall
    )
    var auto by remember { mutableStateOf(Prefs.autoPhoneSync) }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Switch(auto, { auto = it; Prefs.autoPhoneSync = it })
        Spacer(Modifier.width(10.dp))
        Text(tr("להוסיף אוטומטית אנשי קשר חדשים מהטלפון בכל פתיחה של האפליקציה"))
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Checkbox(toApp, { toApp = it }); Text(tr("להוסיף לספר האישי את מי שיש בטלפון"))
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Checkbox(toPhone, { toPhone = it }); Text(tr("לשמור בטלפון את מי שיש בספר האישי"))
    }
    Button(enabled = status == null && (toApp || toPhone), onClick = { confirm = true }) { Text(tr("🔄 סנכרן עכשיו")) }
    val dbv by LocalDb.changes.collectAsState()
    val fromPhone by produceState(0, dbv) { value = withContext(Dispatchers.IO) { LocalDb.countBatchPrefix(SystemContacts.PHONE_BATCH) } }
    var confirmRemove by remember { mutableStateOf(false) }
    if (fromPhone > 0) OutlinedButton(enabled = status == null, onClick = { confirmRemove = true }) {
        Text(tr("🧹 הסר את כל מי שנוסף מהטלפון ({0})", fromPhone))
    }
    if (confirmRemove) AlertDialog(
        onDismissRequest = { confirmRemove = false },
        title = { Text(tr("להסיר את אנשי הקשר שנוספו מהטלפון?")) },
        text = { Text(tr("{0} אנשי קשר שנוספו לספר האישי מהסנכרון עם הטלפון יעברו לסל המחזור (אפשר לשחזר). אנשי הקשר בטלפון עצמו לא נמחקים.", fromPhone)) },
        confirmButton = {
            TextButton(onClick = {
                confirmRemove = false
                Prefs.autoPhoneSync = false; auto = false
                val n = LocalDb.deleteBatchPrefix(SystemContacts.PHONE_BATCH)
                toast(ctx, tr("הוסרו {0} אנשי קשר. הסנכרון האוטומטי כובה.", n))
            }) { Text(tr("הסר")) }
        },
        dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text(tr("ביטול")) } },
    )
    status?.let {
        Text(it)
        LinearProgressIndicator(Modifier.fillMaxWidth())
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text(tr("לסנכרן עם אנשי הקשר של הטלפון?")) },
        text = {
            Text(
                (if (toPhone) tr("אנשי הקשר מהספר האישי ({0}) יישמרו באנשי הקשר של הטלפון ויופיעו גם בוואטסאפ. ", LocalDb.count(LocalDb.PERSONAL)) else "") +
                    (if (toApp) tr("אנשי קשר מהטלפון שחסרים באפליקציה יתווספו לספר האישי (אפשר לבטל עם 'ביטול הטעינה האחרונה'). ") else "") +
                    tr("זה יכול לקחת כמה דקות – לא לסגור את האפליקציה.")
            )
        },
        confirmButton = {
            TextButton(onClick = {
                confirm = false
                if (SystemContacts.hasPermission(ctx)) run() else perm.launch(SystemContacts.PERMISSIONS)
            }) { Text(tr("סנכרן")) }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text(tr("ביטול")) } },
    )
}

@Composable
private fun ImportExportSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            runCatching { ImportExport.import(ctx, uri) }
                .onSuccess { r ->
                    val parts = mutableListOf(tr("נוספו {0} לספר האישי", r.personal))
                    if (r.shared > 0) parts += tr("{0} לספר הכללי", r.shared)
                    if (r.duplicates > 0) parts += tr("{0} כפולים דולגו", r.duplicates)
                    if (r.skippedShared > 0) parts += tr("{0} רשומות 'כללי' דולגו – צריך להתחבר קודם", r.skippedShared)
                    toast(ctx, parts.joinToString(", "))
                }
                .onFailure { toast(ctx, tr("הייבוא נכשל: {0}", it.message)) }
            busy = false
        }
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            runCatching { ImportExport.exportCsv(ctx, uri) }
                .onSuccess { toast(ctx, tr("נשמרו {0} אנשי קשר", it)) }
                .onFailure { toast(ctx, tr("הגיבוי נכשל: {0}", it.message)) }
            busy = false
        }
    }

    Text(
        tr("ייבוא קובץ אקסל (xlsx), CSV או VCF. עמודות: שם (או שם משפחה + שם פרטי), טלפון, נייד, עיר, כתובת, אימייל, ספר. כל עמודה אחרת (למשל שם האב, בית כנסת, תפקיד) נשמרת כשדה נוסף. ") +
            tr("בעמודה 'ספר' כותבים 'כללי' או 'אישי' (ברירת מחדל: אישי)."),
        style = MaterialTheme.typography.bodySmall
    )
    var lastCount by remember { mutableIntStateOf(Prefs.lastBatchCount) }
    val dbChanges by LocalDb.changes.collectAsState()
    LaunchedEffect(dbChanges) { lastCount = Prefs.lastBatchCount }
    var confirmWipe by remember { mutableStateOf(false) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(enabled = !busy, onClick = { importer.launch(arrayOf("*/*")) }) { Text(tr("ייבוא קובץ")) }
        OutlinedButton(enabled = !busy, onClick = { exporter.launch("phonebook-backup-${LocalDate.now()}.csv") }) { Text(tr("גיבוי ל-CSV")) }
    }
    if (lastCount > 0 && Prefs.lastBatch.isNotBlank()) {
        OutlinedButton(onClick = {
            val n = LocalDb.deleteBatch(LocalDb.PERSONAL, Prefs.lastBatch)
            Prefs.lastBatch = ""; Prefs.lastBatchCount = 0; lastCount = 0
            toast(ctx, tr("בוטלה הטעינה האחרונה – נמחקו {0} אנשי קשר", n))
        }) { Text(tr("↩️ ביטול הטעינה האחרונה ({0} אנשי קשר)", lastCount)) }
    }
    // היסטוריית טעינות – אפשר להסיר כל טעינה בנפרד
    val batches by produceState(emptyList<LocalDb.Batch>(), dbChanges) { value = withContext(Dispatchers.IO) { LocalDb.batches() } }
    var showBatches by remember { mutableStateOf(false) }
    var removeBatch by remember { mutableStateOf<LocalDb.Batch?>(null) }
    if (batches.isNotEmpty()) TextButton(onClick = { showBatches = !showBatches }) {
        Text(if (showBatches) tr("הסתר טעינות קודמות") else tr("📋 טעינות קודמות ({0}) – להסרת טעינה שהשתבשה", batches.size))
    }
    if (showBatches) batches.forEach { b ->
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text((if (b.id.startsWith(SystemContacts.PHONE_BATCH)) tr("📱 מהטלפון") else tr("📄 טעינה")) + tr(" – {0} אנשי קשר", b.count), fontWeight = FontWeight.SemiBold)
                Text(tr("למשל: {0}", b.sample), style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { removeBatch = b }) { Text(tr("הסר"), color = CallRed) }
        }
    }
    removeBatch?.let { b ->
        AlertDialog(
            onDismissRequest = { removeBatch = null },
            title = { Text(tr("להסיר {0} אנשי קשר?", b.count)) },
            text = { Text(tr("כל אנשי הקשר שנוספו בטעינה הזו יעברו לסל המחזור (אפשר לשחזר משם).")) },
            confirmButton = {
                TextButton(onClick = {
                    removeBatch = null
                    val n = LocalDb.deleteBatch(LocalDb.PERSONAL, b.id)
                    if (b.id == Prefs.lastBatch) { Prefs.lastBatch = ""; Prefs.lastBatchCount = 0 }
                    toast(ctx, tr("הוסרו {0} אנשי קשר", n))
                }) { Text(tr("הסר")) }
            },
            dismissButton = { TextButton(onClick = { removeBatch = null }) { Text(tr("ביטול")) } },
        )
    }
    TextButton(onClick = { confirmWipe = true }) { Text(tr("🗑️ מחיקת כל הספר האישי"), color = CallRed) }
    if (confirmWipe) {
        var pw by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text(tr("למחוק את כל הספר האישי?")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("כל אנשי הקשר בספר האישי יימחקו מהטלפון. מומלץ לגבות קודם ל-CSV."))
                    if (Prefs.hasDeletePassword) Input(tr("סיסמת מחיקה"), pw, password = true) { pw = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (!Prefs.checkDeletePassword(pw)) { toast(ctx, tr("סיסמה שגויה")); return@TextButton }
                    LocalDb.clear(LocalDb.PERSONAL); Prefs.lastBatch = ""; Prefs.lastBatchCount = 0; lastCount = 0
                    confirmWipe = false; toast(ctx, tr("הספר האישי נמחק"))
                }) { Text(tr("מחק הכל"), color = CallRed) }
            },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text(tr("ביטול")) } },
        )
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
}

@Composable
private fun DeletePasswordSection() {
    val ctx = LocalContext.current
    var has by remember { mutableStateOf(Prefs.hasDeletePassword) }
    var old by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    Text(
        if (has) tr("מוגדרת סיסמה. כל מחיקה של איש קשר תדרוש אותה.") else tr("אופציונלי: סיסמה שתידרש לפני כל מחיקה."),
        style = MaterialTheme.typography.bodySmall
    )
    if (has) Input(tr("סיסמה נוכחית"), old, password = true) { old = it }
    Input(if (has) tr("סיסמה חדשה (ריק = ביטול הסיסמה)") else tr("סיסמה חדשה"), pw, password = true) { pw = it }
    Button(onClick = {
        if (!Prefs.checkDeletePassword(old)) {
            toast(ctx, tr("הסיסמה הנוכחית שגויה")); return@Button
        }
        Prefs.setDeletePassword(pw)
        has = Prefs.hasDeletePassword
        old = ""; pw = ""
        toast(ctx, if (has) tr("הסיסמה נשמרה") else tr("הסיסמה בוטלה"))
    }) { Text(tr("שמור")) }
}

@Composable
private fun AiSection() {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.aiKey) }
    var model by remember { mutableStateOf(Prefs.aiModel) }
    Text(tr("העוזרת עובדת דרך השרת של הספר הכללי – לא צריך מפתח משלך, רק להיות מחובר. ") +
            tr("העוזרת מחפשת אנשי קשר בעצמה ומכינה כפתורי חיוג / SMS / וואטסאפ. במסך העוזרת אפשר לבחור אם לחפש גם בספר האישי. ") +
            tr("(לא חובה: מפתח אישי של Claude – אם ממלאים, העוזרת תעבוד ישירות דרכו.)"), style = MaterialTheme.typography.bodySmall)
    Input(tr("מפתח API אישי (לא חובה)"), key, password = true) { key = it }
    Input(tr("מודל"), model) { model = it }
    Button(onClick = { Prefs.aiKey = key; Prefs.aiModel = model.ifBlank { "claude-haiku-5-5" }; toast(ctx, tr("נשמר")) }) { Text(tr("שמור")) }
}

@Composable
private fun ThemeSection() {
    val scale by Prefs.textScale.collectAsState()
    Text(tr("גודל טקסט"), style = MaterialTheme.typography.labelLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(tr("רגיל"), tr("גדול"), tr("גדול מאוד")).forEachIndexed { i, label ->
            FilterChip(selected = scale == i, onClick = { Prefs.setTextScale(i) }, label = { Text(label) })
        }
    }
    Text(tr("ערכת צבעים"), style = MaterialTheme.typography.labelLarge)
    val mode by Prefs.theme.collectAsState()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(tr("לפי הטלפון"), tr("בהיר"), tr("כהה")).forEachIndexed { i, label ->
            FilterChip(selected = mode == i, onClick = { Prefs.setTheme(i) }, label = { Text(label) })
        }
    }
}

@Composable
private fun FeedbackSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Text(tr("מצאת באג? יש לך רעיון? כתוב כאן ונשלח את זה למנהל."), style = MaterialTheme.typography.bodySmall)
    OutlinedTextField(text, { text = it }, minLines = 3, placeholder = { Text(tr("מה תרצה לספר לנו?")) }, modifier = Modifier.fillMaxWidth())
    Button(enabled = !busy && text.isNotBlank(), onClick = {
        val msg = text.trim()
        scope.launch {
            busy = true
            var saved = false
            var to = Prefs.feedbackEmail
            if (Server.loggedIn()) {
                runCatching { to = SharedBook.feedbackEmail().ifBlank { to }; Prefs.feedbackEmail = to }
                saved = runCatching { SharedBook.sendFeedback(msg, Prefs.email) }.isSuccess
            }
            busy = false
            val version = com.phonebook.app.net.Updater.currentVersionName(ctx)
            val body = tr("{0}\n\n---\nגרסה {1} · {2} {3} · Android {4}", msg, version, android.os.Build.MANUFACTURER, android.os.Build.MODEL, android.os.Build.VERSION.RELEASE)
            if (to.isNotBlank()) {
                val i = android.content.Intent(android.content.Intent.ACTION_SENDTO, android.net.Uri.parse("mailto:"))
                    .putExtra(android.content.Intent.EXTRA_EMAIL, arrayOf(to))
                    .putExtra(android.content.Intent.EXTRA_SUBJECT, tr("משוב – ספר טלפונים"))
                    .putExtra(android.content.Intent.EXTRA_TEXT, body)
                try {
                    ctx.startActivity(i); text = ""
                    toast(ctx, tr("נפתח המייל – לחץ שם \"שלח\""))
                } catch (_: Exception) {
                    if (saved) { text = ""; toast(ctx, tr("המשוב נשלח, תודה!")) } else toast(ctx, tr("לא נמצאה אפליקציית מייל"))
                }
            } else if (saved) {
                text = ""; toast(ctx, tr("המשוב נשלח, תודה!"))
            } else toast(ctx, tr("כדי לשלוח משוב צריך להתחבר לספר הכללי בהגדרות"))
        }
    }) { Text(tr("📨 שלח משוב")) }
}

@Composable
private fun SpamSection() {
    var on by remember { mutableStateOf(Prefs.spamFilter) }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Switch(on, { on = it; Prefs.spamFilter = it })
        Spacer(Modifier.width(10.dp))
        Text(tr("זיהוי אוטומטי של הודעות פרסומת והונאה"))
    }
    Text(
        tr("הודעות ממספרים שלא באלפון, עם \"פרסומת\", \"להסרה\", קישורים מקוצרים, הצעות הלוואה / זכייה, או בקשה לעדכן פרטים בקישור – ") +
            tr("עוברות ללשונית \"ספאם\" בהודעות, בלי התראה עם צליל. מי שנמצא באלפון לא ייחשב ספאם. ") +
            tr("הבדיקה נעשית רק בטלפון. אפשר לסמן ידנית \"ספאם\" או \"לא ספאם\" בלחיצה ארוכה על שיחה."),
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
private fun BlockedSection() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var number by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    val list = remember(tick) { com.phonebook.app.data.Blocking.list(ctx) }
    Text(tr("מספר חסום לא יוכל להתקשר או לשלוח לך הודעות."), style = MaterialTheme.typography.bodySmall)
    if (list.isEmpty()) Text(tr("אין מספרים חסומים"), color = MaterialTheme.colorScheme.onSurfaceVariant)
    list.forEach { n ->
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(ltr(n), modifier = Modifier.weight(1f))
            TextButton(onClick = { com.phonebook.app.data.Blocking.unblock(ctx, n); tick++ }) { Text(tr("בטל חסימה")) }
        }
    }
    Input(tr("מספר לחסימה"), number, type = KeyboardType.Phone) { number = it }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            if (number.isNotBlank()) {
                toast(ctx, if (com.phonebook.app.data.Blocking.block(ctx, number.trim())) tr("המספר נחסם") else tr("לא ניתן לחסום – צריך להגדיר את האפליקציה כברירת מחדל"))
                number = ""; tick++
            }
        }) { Text(tr("חסום")) }
        OutlinedButton(onClick = { confirmClear = true }) { Text(tr("ניקוי כל יומן השיחות")) }
    }
    if (confirmClear) ConfirmDialog(tr("לנקות את כל יומן השיחות?"), tr("כל השיחות ביומן יימחקו. אי אפשר לבטל."), tr("נקה"), onDismiss = { confirmClear = false }) {
        confirmClear = false
        toast(ctx, if (com.phonebook.app.data.CallLogEdit.clearAll(ctx)) tr("היומן נוקה") else tr("לא ניתן לנקות – אשר את ההרשאות"))
    }
}

@Composable
private fun RecordingSection() {
    val ctx = LocalContext.current
    var auto by remember { mutableStateOf(Prefs.autoRecord) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Prefs.autoRecord = granted; auto = granted
        if (!granted) toast(ctx, tr("בלי הרשאת מיקרופון אי אפשר להקליט"))
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text(tr("הקלטה אוטומטית של כל שיחה"), modifier = Modifier.weight(1f))
        Switch(checked = auto, onCheckedChange = { on ->
            if (on && !com.phonebook.app.call.CallRecorder.hasPermission(ctx)) micLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
            else { Prefs.autoRecord = on; auto = on }
        })
    }
    Text(
        tr("אפשר גם להקליט שיחה מסוימת בכפתור \"הקלט\" במסך השיחה. ההקלטות נשמרות בתיקייה {0}. ", com.phonebook.app.call.CallRecorder.folder) +
            tr("אנדרואיד לא מאפשר לאפליקציות להקליט ישירות את הצד השני, לכן הוא יישמע טוב בהקלטה רק כשהרמקול פועל."),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
