// ספר טלפונים – העוזרת דרך השרת (Supabase Edge Function בשם assistant)
// כל משתמש מחובר ומאושר יכול להשתמש בעוזרת בלי מפתח משלו.
// המפתח נשמר רק בשרת: Edge Functions → Secrets
//   GEMINI_API_KEY    – מפתח חינמי של Google (aistudio.google.com/apikey)   ← מומלץ
//   או ANTHROPIC_API_KEY – מפתח של Claude (בתשלום)
// האפליקציה שולחת בקשה בפורמט של Claude, והפונקציה מעבירה אותה לספק שהוגדר.

const URL_ = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
const GEMINI = Deno.env.get("GEMINI_API_KEY") ?? "";
const GEMINI_MODEL = Deno.env.get("GEMINI_MODEL") ?? "gemini-2.5-flash";
const ANTHROPIC = Deno.env.get("ANTHROPIC_API_KEY") ?? "";
const ANTHROPIC_MODEL = Deno.env.get("ANTHROPIC_MODEL") ?? "claude-haiku-5-5";

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json; charset=utf-8" } });
const fail = (status: number, message: string) => json(status, { error: { message } });

// מזהה המשתמש מתוך הטוקן (החתימה כבר נבדקה ע"י Supabase)
function userId(req: Request): string | null {
  try {
    const t = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
    const p = t.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    const payload = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(p + "=".repeat((4 - p.length % 4) % 4)), (c) => c.charCodeAt(0))));
    return payload.role === "authenticated" && payload.sub ? payload.sub : null;
  } catch {
    return null;
  }
}

async function approved(uid: string): Promise<boolean> {
  if (!URL_ || !SERVICE) return true;
  try {
    const r = await fetch(`${URL_}/rest/v1/app_users?id=eq.${uid}&select=approved`, {
      headers: { apikey: SERVICE, authorization: `Bearer ${SERVICE}` },
    });
    if (!r.ok) return true;
    const rows = await r.json();
    return rows.length === 0 || rows[0].approved !== false;
  } catch {
    return true;
  }
}

// ---------- המרה מפורמט Claude לפורמט OpenAI (ש-Gemini תומך בו) ----------
// deno-lint-ignore no-explicit-any
type Any = any;

function toOpenAI(body: Any) {
  const messages: Any[] = [];
  if (body.system) messages.push({ role: "system", content: body.system });
  for (const m of body.messages ?? []) {
    if (typeof m.content === "string") {
      messages.push({ role: m.role, content: m.content });
      continue;
    }
    if (m.role === "assistant") {
      const text = m.content.filter((b: Any) => b.type === "text").map((b: Any) => b.text).join("\n");
      const calls = m.content.filter((b: Any) => b.type === "tool_use").map((b: Any) => ({
        id: b.id, type: "function", function: { name: b.name, arguments: JSON.stringify(b.input ?? {}) },
      }));
      messages.push({ role: "assistant", content: text || null, ...(calls.length ? { tool_calls: calls } : {}) });
    } else {
      for (const b of m.content) {
        if (b.type === "tool_result") {
          messages.push({ role: "tool", tool_call_id: b.tool_use_id, content: typeof b.content === "string" ? b.content : JSON.stringify(b.content) });
        } else if (b.type === "text") messages.push({ role: "user", content: b.text });
      }
    }
  }
  const tools = (body.tools ?? []).map((t: Any) => ({
    type: "function", function: { name: t.name, description: t.description, parameters: t.input_schema },
  }));
  return { model: GEMINI_MODEL, messages, max_tokens: Math.max(2048, body.max_tokens ?? 0), reasoning_effort: "low", ...(tools.length ? { tools } : {}) };
}

function fromOpenAI(r: Any) {
  const msg = r.choices?.[0]?.message ?? {};
  const content: Any[] = [];
  if (msg.content) content.push({ type: "text", text: msg.content });
  for (const c of msg.tool_calls ?? []) {
    let input = {};
    try { input = JSON.parse(c.function?.arguments || "{}"); } catch { /* */ }
    content.push({ type: "tool_use", id: c.id || crypto.randomUUID(), name: c.function?.name, input });
  }
  const stop = (msg.tool_calls ?? []).length ? "tool_use" : "end_turn";
  return { content, stop_reason: stop };
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return fail(405, "POST only");
  const uid = userId(req);
  if (!uid) return fail(401, "צריך להתחבר באפליקציה");
  if (!(await approved(uid))) return fail(403, "החשבון שלך ממתין לאישור מנהל");

  let body: Any;
  try { body = await req.json(); } catch { return fail(400, "bad json"); }

  if (GEMINI) {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${GEMINI}` },
      body: JSON.stringify(toOpenAI(body)),
    });
    const text = await r.text();
    if (!r.ok) {
      let m = text.slice(0, 300);
      try { const e = JSON.parse(text); m = (Array.isArray(e) ? e[0] : e)?.error?.message ?? m; } catch { /* */ }
      return fail(r.status === 429 ? 429 : 502, r.status === 429 ? "העוזרת עמוסה כרגע – נסה שוב בעוד דקה" : `Gemini: ${m}`);
    }
    return json(200, fromOpenAI(JSON.parse(text)));
  }

  if (ANTHROPIC) {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": ANTHROPIC, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ ...body, model: ANTHROPIC_MODEL }),
    });
    return new Response(await r.text(), { status: r.status, headers: { "content-type": "application/json; charset=utf-8" } });
  }

  return fail(503, "העוזרת עוד לא הופעלה בשרת – המנהל צריך להוסיף מפתח (GEMINI_API_KEY) ב-Supabase");
});
