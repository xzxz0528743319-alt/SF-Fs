@file:OptIn(ExperimentalMaterial3Api::class)

package com.phonebook.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.ImportExport
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import com.phonebook.app.data.SystemContacts
import com.phonebook.app.net.Server
import com.phonebook.app.net.SharedBook
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

@Composable
fun SettingsScreen(onClose: () -> Unit, onTrash: () -> Unit, onAdmin: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        OverlayTopBar("הגדרות", onClose)
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Section("חשבון וספר כללי") { AccountSection(onAdmin) }
            Section("סנכרון עם אנשי הקשר של הטלפון") { PhoneSyncSection() }
            Section("ייבוא וגיבוי") { ImportExportSection() }
            Section("גיבוי אוטומטי וסל מחזור") { BackupSection(onTrash) }
            Section("נעילה ופרטיות") { LockSection() }
            Section("הקלטת שיחות") { RecordingSection() }
            Section("סיסמת מחיקה") { DeletePasswordSection() }
            Section("סינון ספאם") { SpamSection() }
            Section("מספרים חסומים") { BlockedSection() }
            Section("עוזרת AI") { AiSection() }
            Section("מראה וגודל טקסט") { ThemeSection() }
            Section("ברירת מחדל והרשאות") { DefaultsSection() }
            Section("גרסה ועדכונים") { VersionSection() }
            val uriHandler = LocalUriHandler.current
            TextButton(onClick = { uriHandler.openUri(Prefs.PRIVACY_URL) }) { Text("מדיניות פרטיות") }
            Text(
                "ללא פרסומות וללא מעקב. אנשי קשר בספר האישי נשמרים רק בטלפון.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(4.dp)
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun BackupSection(onTrash: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var auto by remember { mutableStateOf(Prefs.autoBackup) }
    var last by remember { mutableLongStateOf(Prefs.lastBackup) }
    val dbv by LocalDb.changes.collectAsState()
    val trashCount by produceState(0, dbv) { value = withContext(Dispatchers.IO) { LocalDb.trashCount() } }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text("גיבוי שבועי אוטומטי של הספר האישי", modifier = Modifier.weight(1f))
        Switch(checked = auto, onCheckedChange = { auto = it; Prefs.autoBackup = it })
    }
    Text(
        (if (last > 0) "גיבוי אחרון: " + java.time.Instant.ofEpochMilli(last).atZone(java.time.ZoneId.systemDefault())
            .format(java.time.format.DateTimeFormatter.ofPattern("d.M.yyyy HH:mm")) + ". " else "עדיין לא בוצע גיבוי. ") +
            "הקבצים נשמרים בתיקייה ${com.phonebook.app.data.Backup.folder} (5 האחרונים). בנוסף אנדרואיד מגבה את האפליקציה לחשבון הגוגל שלך.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            scope.launch {
                runCatching { withContext(Dispatchers.IO) { com.phonebook.app.data.Backup.backupNow(ctx) } }
                    .onSuccess { n -> last = Prefs.lastBackup; toast(ctx, if (n > 0) "גובו $n אנשי קשר" else "הספר האישי ריק") }
                    .onFailure { toast(ctx, "הגיבוי נכשל: ${it.message}") }
            }
        }) { Text("גבה עכשיו") }
        OutlinedButton(onClick = onTrash) { Text("🗑️ סל מחזור ($trashCount)") }
    }
}

@Composable
private fun LockSection() {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Prefs.lockEnabled) }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text("נעילת האפליקציה בטביעת אצבע או בקוד הטלפון", modifier = Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = { want ->
            val activity = ctx as? com.phonebook.app.MainActivity
            if (want && activity?.canLock() != true) toast(ctx, "קודם צריך להגדיר נעילת מסך (קוד או טביעת אצבע) בהגדרות הטלפון")
            else { on = want; Prefs.lockEnabled = want }
        })
    }
    Text(
        "כשהנעילה פעילה, צריך לאמת כדי לפתוח את האפליקציה (גם אחרי דקה ברקע). שיחות נכנסות לא ננעלות.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun VersionSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var update by remember { mutableStateOf<com.phonebook.app.net.Updater.Update?>(null) }
    Text("גרסה מותקנת: ${com.phonebook.app.net.Updater.currentVersionName(ctx)}", fontWeight = FontWeight.SemiBold)
    if (com.phonebook.app.net.Updater.fromPlayStore(ctx)) {
        Text("העדכונים מגיעים מחנות Google Play.", style = MaterialTheme.typography.bodySmall)
    } else Button(enabled = !checking, onClick = {
        checking = true
        scope.launch {
            runCatching { com.phonebook.app.net.Updater.check(ctx) }
                .onSuccess { u -> if (u == null) toast(ctx, "יש לך את הגרסה האחרונה ✓") else update = u }
                .onFailure { toast(ctx, "הבדיקה נכשלה – בדוק את החיבור לאינטרנט") }
            checking = false
        }
    }) { Text(if (checking) "בודק…" else "בדוק עדכונים") }
    update?.let { UpdateDialog(it) { update = null } }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    AppCard {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun Input(label: String, value: String, password: Boolean = false, type: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else type),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun AccountSection(onAdmin: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val session by Prefs.session.collectAsState()
    var url by remember { mutableStateOf(Prefs.serverUrl) }
    var key by remember { mutableStateOf(Prefs.serverKey) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showServer by remember { mutableStateOf(!Server.configured()) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmUpload by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    val dbv by LocalDb.changes.collectAsState()
    val count by produceState(0, dbv) { value = withContext(Dispatchers.IO) { LocalDb.count(LocalDb.SHARED) } }

    fun go(block: suspend () -> Unit) = scope.launch {
        busy = true
        runCatching { block() }.onFailure { toast(ctx, it.message ?: "שגיאה") }
        busy = false
    }

    if (showServer) {
        Text("פרטי השרת של הספר הכללי (מקבלים פעם אחת ממי שהקים את השרת):", style = MaterialTheme.typography.bodySmall)
        Input("כתובת שרת", url, type = KeyboardType.Uri) { url = it }
        Input("מפתח ציבורי", key) { key = it }
        Button(onClick = {
            Prefs.serverUrl = url; Prefs.serverKey = key
            showServer = !Server.configured()
            toast(ctx, if (Server.configured()) "נשמר" else "חסרים פרטים")
        }) { Text("שמור פרטי שרת") }
    } else {
        TextButton(onClick = { showServer = true }) { Text("שינוי פרטי שרת") }
    }

    if (session == null) {
        Input("אימייל", email, type = KeyboardType.Email) { email = it }
        Input("סיסמה (לפחות 6 תווים)", password, password = true) { password = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = {
                go { Server.signIn(email, password); toast(ctx, "התחברת"); SharedBook.sync() }
            }) { Text("התחברות") }
            OutlinedButton(enabled = !busy, onClick = {
                go {
                    if (Server.signUp(email, password)) {
                        toast(ctx, "נרשמת והתחברת"); SharedBook.sync()
                    } else toast(ctx, "נשלח אליך מייל אישור. אשר אותו ואז התחבר.")
                }
            }) { Text("הרשמה") }
        }
        Text("האימייל משמש רק להתחברות ולא מתפרסם.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
        Text("מחובר: ${ltr(session ?: "")}")
        Text("רשומות בספר הכללי: $count")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy, onClick = { go { val n = SharedBook.sync(); toast(ctx, "סונכרן ($n עדכונים)") } }) { Text("סנכרן עכשיו") }
            OutlinedButton(enabled = !busy, onClick = {
                Server.logout()
                LocalDb.clear(LocalDb.SHARED)
            }) { Text("התנתק") }
        }
        if (!Prefs.approved) InfoCard("החשבון שלך ממתין לאישור מנהל. אחרי האישור תוכל לראות את הספר הכללי.")
        if (Prefs.isAdmin) Button(onClick = onAdmin) { Text("🛡️ ניהול הספר הכללי") }
        if (Prefs.approved) OutlinedButton(enabled = !busy, onClick = { confirmUpload = true }) {
            Text("📤 העתק את כל הספר האישי לספר הכללי")
        }
        progress?.let { (d, t) ->
            Text(if (t == 0) "בודק כפילויות..." else "מעלה לספר הכללי: $d מתוך $t")
            LinearProgressIndicator(progress = { if (t == 0) 0f else d.toFloat() / t }, modifier = Modifier.fillMaxWidth())
        }
        TextButton(onClick = { confirmDelete = true }) { Text("מחיקת החשבון", color = CallRed) }
    }
    if (confirmUpload) AlertDialog(
        onDismissRequest = { confirmUpload = false },
        title = { Text("להעתיק את הספר האישי לספר הכללי?") },
        text = {
            Text(
                "כל אנשי הקשר מהספר האישי (${LocalDb.count(LocalDb.PERSONAL)}) יועתקו גם לספר הכללי, וכל מי שמחובר יראה אותם. " +
                    "מי שכבר נמצא בספר הכללי (לפי מספר טלפון) לא יועתק שוב. הספר האישי נשאר כמו שהוא. " +
                    "זה יכול לקחת כמה דקות – לא לסגור את האפליקציה." +
                    if (Prefs.isAdmin) "" else "\n\nהרשומות ימתינו לאישור מנהל."
            )
        },
        confirmButton = {
            TextButton(onClick = {
                confirmUpload = false
                go {
                    progress = 0 to 0
                    try {
                        val n = SharedBook.uploadPersonal { d, t -> progress = d to t }
                        toast(ctx, if (n == 0) "כל אנשי הקשר כבר נמצאים בספר הכללי" else "הועתקו $n אנשי קשר לספר הכללי")
                    } finally { progress = null }
                }
            }) { Text("העתק") }
        },
        dismissButton = { TextButton(onClick = { confirmUpload = false }) { Text("ביטול") } },
    )
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("למחוק את החשבון?") },
        text = { Text("החשבון וכל הרשומות שהוספת לספר הכללי יימחקו לצמיתות. הספר האישי שבטלפון לא נפגע.") },
        confirmButton = {
            TextButton(onClick = {
                confirmDelete = false
                go {
                    Server.deleteAccount()
                    LocalDb.clear(LocalDb.SHARED)
                    toast(ctx, "החשבון נמחק")
                }
            }) { Text("מחק לצמיתות", color = CallRed) }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("ביטול") } },
    )
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
}

@Composable
private fun PhoneSyncSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var toApp by remember { mutableStateOf(true) }
    var toPhone by remember { mutableStateOf(true) }
    var status by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }

    fun run() = scope.launch {
        status = "מתחיל..."
        runCatching {
            withContext(Dispatchers.IO) { SystemContacts.sync(ctx, toApp, toPhone) { status = it } }
        }.onSuccess { r ->
            val parts = mutableListOf<String>()
            if (toApp) parts += "נוספו ${r.imported} לספר האישי"
            if (r.updated > 0) parts += "הושלמו פרטים אצל ${r.updated}"
            if (toPhone) parts += "נשמרו ${r.exported} בטלפון"
            toast(ctx, "הסנכרון הסתיים: " + parts.joinToString(", "))
        }.onFailure { toast(ctx, "הסנכרון נכשל: ${it.message}") }
        status = null
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.all { it }) run() else toast(ctx, "צריך לאשר גישה לאנשי הקשר")
    }

    Text(
        "מחבר בין הספר האישי לאנשי הקשר של הטלפון – מכל האפליקציות והחשבונות (Google, סמסונג, וואטסאפ, SIM). " +
            "נלקחים גם עיר, כתובת, אימייל, מקום עבודה, תפקיד, יום הולדת, כינוי והערה. מי שכבר קיים – לפי מספר טלפון – לא נוסף שוב, " +
            "ורק משלימים אצלו פרטים שחסרים.",
        style = MaterialTheme.typography.bodySmall
    )
    var auto by remember { mutableStateOf(Prefs.autoPhoneSync) }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Switch(auto, { auto = it; Prefs.autoPhoneSync = it })
        Spacer(Modifier.width(10.dp))
        Text("להוסיף אוטומטית אנשי קשר חדשים מהטלפון בכל פתיחה של האפליקציה")
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Checkbox(toApp, { toApp = it }); Text("להוסיף לספר האישי את מי שיש בטלפון")
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Checkbox(toPhone, { toPhone = it }); Text("לשמור בטלפון את מי שיש בספר האישי")
    }
    Button(enabled = status == null && (toApp || toPhone), onClick = { confirm = true }) { Text("🔄 סנכרן עכשיו") }
    status?.let {
        Text(it)
        LinearProgressIndicator(Modifier.fillMaxWidth())
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("לסנכרן עם אנשי הקשר של הטלפון?") },
        text = {
            Text(
                (if (toPhone) "אנשי הקשר מהספר האישי (${LocalDb.count(LocalDb.PERSONAL)}) יישמרו באנשי הקשר של הטלפון ויופיעו גם בוואטסאפ. " else "") +
                    (if (toApp) "אנשי קשר מהטלפון שחסרים באפליקציה יתווספו לספר האישי (אפשר לבטל עם 'ביטול הטעינה האחרונה'). " else "") +
                    "זה יכול לקחת כמה דקות – לא לסגור את האפליקציה."
            )
        },
        confirmButton = {
            TextButton(onClick = {
                confirm = false
                if (SystemContacts.hasPermission(ctx)) run() else perm.launch(SystemContacts.PERMISSIONS)
            }) { Text("סנכרן") }
        },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("ביטול") } },
    )
}

@Composable
private fun ImportExportSection() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            runCatching { ImportExport.import(ctx, uri) }
                .onSuccess { r ->
                    val parts = mutableListOf("נוספו ${r.personal} לספר האישי")
                    if (r.shared > 0) parts += "${r.shared} לספר הכללי"
                    if (r.duplicates > 0) parts += "${r.duplicates} כפולים דולגו"
                    if (r.skippedShared > 0) parts += "${r.skippedShared} רשומות 'כללי' דולגו – צריך להתחבר קודם"
                    toast(ctx, parts.joinToString(", "))
                }
                .onFailure { toast(ctx, "הייבוא נכשל: ${it.message}") }
            busy = false
        }
    }
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            busy = true
            runCatching { ImportExport.exportCsv(ctx, uri) }
                .onSuccess { toast(ctx, "נשמרו $it אנשי קשר") }
                .onFailure { toast(ctx, "הגיבוי נכשל: ${it.message}") }
            busy = false
        }
    }

    Text(
        "ייבוא קובץ אקסל (xlsx), CSV או VCF. עמודות: שם (או שם משפחה + שם פרטי), טלפון, נייד, עיר, כתובת, אימייל, ספר. כל עמודה אחרת (למשל שם האב, בית כנסת, תפקיד) נשמרת כשדה נוסף. " +
            "בעמודה 'ספר' כותבים 'כללי' או 'אישי' (ברירת מחדל: אישי).",
        style = MaterialTheme.typography.bodySmall
    )
    var lastCount by remember { mutableIntStateOf(Prefs.lastBatchCount) }
    val dbChanges by LocalDb.changes.collectAsState()
    LaunchedEffect(dbChanges) { lastCount = Prefs.lastBatchCount }
    var confirmWipe by remember { mutableStateOf(false) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(enabled = !busy, onClick = { importer.launch(arrayOf("*/*")) }) { Text("ייבוא קובץ") }
        OutlinedButton(enabled = !busy, onClick = { exporter.launch("phonebook-backup-${LocalDate.now()}.csv") }) { Text("גיבוי ל-CSV") }
    }
    if (lastCount > 0 && Prefs.lastBatch.isNotBlank()) {
        OutlinedButton(onClick = {
            val n = LocalDb.deleteBatch(LocalDb.PERSONAL, Prefs.lastBatch)
            Prefs.lastBatch = ""; Prefs.lastBatchCount = 0; lastCount = 0
            toast(ctx, "בוטלה הטעינה האחרונה – נמחקו $n אנשי קשר")
        }) { Text("↩️ ביטול הטעינה האחרונה ($lastCount אנשי קשר)") }
    }
    TextButton(onClick = { confirmWipe = true }) { Text("🗑️ מחיקת כל הספר האישי", color = CallRed) }
    if (confirmWipe) {
        var pw by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("למחוק את כל הספר האישי?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("כל אנשי הקשר בספר האישי יימחקו מהטלפון. מומלץ לגבות קודם ל-CSV.")
                    if (Prefs.hasDeletePassword) Input("סיסמת מחיקה", pw, password = true) { pw = it }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (!Prefs.checkDeletePassword(pw)) { toast(ctx, "סיסמה שגויה"); return@TextButton }
                    LocalDb.clear(LocalDb.PERSONAL); Prefs.lastBatch = ""; Prefs.lastBatchCount = 0; lastCount = 0
                    confirmWipe = false; toast(ctx, "הספר האישי נמחק")
                }) { Text("מחק הכל", color = CallRed) }
            },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("ביטול") } },
        )
    }
    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
}

@Composable
private fun DeletePasswordSection() {
    val ctx = LocalContext.current
    var has by remember { mutableStateOf(Prefs.hasDeletePassword) }
    var old by remember { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    Text(
        if (has) "מוגדרת סיסמה. כל מחיקה של איש קשר תדרוש אותה." else "אופציונלי: סיסמה שתידרש לפני כל מחיקה.",
        style = MaterialTheme.typography.bodySmall
    )
    if (has) Input("סיסמה נוכחית", old, password = true) { old = it }
    Input(if (has) "סיסמה חדשה (ריק = ביטול הסיסמה)" else "סיסמה חדשה", pw, password = true) { pw = it }
    Button(onClick = {
        if (!Prefs.checkDeletePassword(old)) {
            toast(ctx, "הסיסמה הנוכחית שגויה"); return@Button
        }
        Prefs.setDeletePassword(pw)
        has = Prefs.hasDeletePassword
        old = ""; pw = ""
        toast(ctx, if (has) "הסיסמה נשמרה" else "הסיסמה בוטלה")
    }) { Text("שמור") }
}

@Composable
private fun AiSection() {
    val ctx = LocalContext.current
    var key by remember { mutableStateOf(Prefs.aiKey) }
    var model by remember { mutableStateOf(Prefs.aiModel) }
    Text("העוזרת עובדת דרך השרת של הספר הכללי – לא צריך מפתח משלך, רק להיות מחובר. " +
            "העוזרת מחפשת אנשי קשר בעצמה ומכינה כפתורי חיוג / SMS / וואטסאפ. במסך העוזרת אפשר לבחור אם לחפש גם בספר האישי. " +
            "(לא חובה: מפתח אישי של Claude – אם ממלאים, העוזרת תעבוד ישירות דרכו.)", style = MaterialTheme.typography.bodySmall)
    Input("מפתח API אישי (לא חובה)", key, password = true) { key = it }
    Input("מודל", model) { model = it }
    Button(onClick = { Prefs.aiKey = key; Prefs.aiModel = model.ifBlank { "claude-haiku-5-5" }; toast(ctx, "נשמר") }) { Text("שמור") }
}

@Composable
private fun ThemeSection() {
    val scale by Prefs.textScale.collectAsState()
    Text("גודל טקסט", style = MaterialTheme.typography.labelLarge)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("רגיל", "גדול", "גדול מאוד").forEachIndexed { i, label ->
            FilterChip(selected = scale == i, onClick = { Prefs.setTextScale(i) }, label = { Text(label) })
        }
    }
    Text("ערכת צבעים", style = MaterialTheme.typography.labelLarge)
    val mode by Prefs.theme.collectAsState()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("לפי הטלפון", "בהיר", "כהה").forEachIndexed { i, label ->
            FilterChip(selected = mode == i, onClick = { Prefs.setTheme(i) }, label = { Text(label) })
        }
    }
}

@Composable
private fun SpamSection() {
    var on by remember { mutableStateOf(Prefs.spamFilter) }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Switch(on, { on = it; Prefs.spamFilter = it })
        Spacer(Modifier.width(10.dp))
        Text("זיהוי אוטומטי של הודעות פרסומת והונאה")
    }
    Text(
        "הודעות ממספרים שלא באלפון, עם \"פרסומת\", \"להסרה\", קישורים מקוצרים, הצעות הלוואה / זכייה, או בקשה לעדכן פרטים בקישור – " +
            "עוברות ללשונית \"ספאם\" בהודעות, בלי התראה עם צליל. מי שנמצא באלפון לא ייחשב ספאם. " +
            "הבדיקה נעשית רק בטלפון. אפשר לסמן ידנית \"ספאם\" או \"לא ספאם\" בלחיצה ארוכה על שיחה.",
        style = MaterialTheme.typography.bodySmall
    )
}

@Composable
private fun BlockedSection() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var number by remember { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    val list = remember(tick) { com.phonebook.app.data.Blocking.list(ctx) }
    Text("מספר חסום לא יוכל להתקשר או לשלוח לך הודעות.", style = MaterialTheme.typography.bodySmall)
    if (list.isEmpty()) Text("אין מספרים חסומים", color = MaterialTheme.colorScheme.onSurfaceVariant)
    list.forEach { n ->
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text(ltr(n), modifier = Modifier.weight(1f))
            TextButton(onClick = { com.phonebook.app.data.Blocking.unblock(ctx, n); tick++ }) { Text("בטל חסימה") }
        }
    }
    Input("מספר לחסימה", number, type = KeyboardType.Phone) { number = it }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            if (number.isNotBlank()) {
                toast(ctx, if (com.phonebook.app.data.Blocking.block(ctx, number.trim())) "המספר נחסם" else "לא ניתן לחסום – צריך להגדיר את האפליקציה כברירת מחדל")
                number = ""; tick++
            }
        }) { Text("חסום") }
        OutlinedButton(onClick = { confirmClear = true }) { Text("ניקוי כל יומן השיחות") }
    }
    if (confirmClear) ConfirmDialog("לנקות את כל יומן השיחות?", "כל השיחות ביומן יימחקו. אי אפשר לבטל.", "נקה", onDismiss = { confirmClear = false }) {
        confirmClear = false
        toast(ctx, if (com.phonebook.app.data.CallLogEdit.clearAll(ctx)) "היומן נוקה" else "לא ניתן לנקות – אשר את ההרשאות")
    }
}

@Composable
private fun RecordingSection() {
    val ctx = LocalContext.current
    var auto by remember { mutableStateOf(Prefs.autoRecord) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        Prefs.autoRecord = granted; auto = granted
        if (!granted) toast(ctx, "בלי הרשאת מיקרופון אי אפשר להקליט")
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        Text("הקלטה אוטומטית של כל שיחה", modifier = Modifier.weight(1f))
        Switch(checked = auto, onCheckedChange = { on ->
            if (on && !com.phonebook.app.call.CallRecorder.hasPermission(ctx)) micLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
            else { Prefs.autoRecord = on; auto = on }
        })
    }
    Text(
        "אפשר גם להקליט שיחה מסוימת בכפתור \"הקלט\" במסך השיחה. ההקלטות נשמרות בתיקייה ${com.phonebook.app.call.CallRecorder.folder}. " +
            "אנדרואיד לא מאפשר לאפליקציות להקליט ישירות את הצד השני, לכן הוא יישמע טוב בהקלטה רק כשהרמקול פועל.",
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}
