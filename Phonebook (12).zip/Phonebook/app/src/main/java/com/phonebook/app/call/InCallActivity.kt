package com.phonebook.app.call

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.PowerManager
import android.telecom.CallAudioState
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import com.phonebook.app.ui.PhonebookTheme
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import android.telecom.Call as TCall

/** מסך השיחה: מוצג גם על מסך נעול */
class InCallActivity : ComponentActivity() {

    private var proximity: PowerManager.WakeLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        enableEdgeToEdge()
        handle(intent)

        val pm = getSystemService(PowerManager::class.java)
        if (pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
            proximity = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "phonebook:proximity")
        }
        // כיבוי מסך כשהטלפון צמוד לאוזן (לא ברמקול)
        lifecycleScope.launch {
            combine(CallManager.call, CallManager.audio) { c, a ->
                val live = c?.state == TCall.STATE_ACTIVE || c?.state == TCall.STATE_DIALING || c?.state == TCall.STATE_CONNECTING
                live && a.route != CallAudioState.ROUTE_SPEAKER && a.route != CallAudioState.ROUTE_BLUETOOTH
            }.distinctUntilChanged().collect { want ->
                val wl = proximity ?: return@collect
                if (want && !wl.isHeld) wl.acquire()
                if (!want && wl.isHeld) wl.release(PowerManager.RELEASE_FLAG_WAIT_FOR_NO_PROXIMITY)
            }
        }

        setContent {
            PhonebookTheme {
                CallScreen(onFinished = { finish() })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(i: Intent?) {
        if (i?.getBooleanExtra(EXTRA_ANSWER, false) == true) CallManager.answer()
    }

    override fun onDestroy() {
        proximity?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_ANSWER = "answer"
        fun intent(ctx: Context) = Intent(ctx, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    }
}
