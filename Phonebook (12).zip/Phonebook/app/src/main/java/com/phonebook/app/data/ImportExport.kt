package com.phonebook.app.data

import android.content.Context
import android.net.Uri
import com.phonebook.app.net.Server
import com.phonebook.app.net.SharedBook
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.UUID

data class ImportResult(val personal: Int, val shared: Int, val skippedShared: Int, val duplicates: Int)

/** ייבוא קבצי VCF / CSV וגיבוי לקובץ CSV */
object ImportExport {

    private val HEADERS = mapOf(
        "name" to listOf("שם", "שם מלא", "שם ומשפחה", "שם משפחה ושם פרטי", "name", "full name"),
        "last" to listOf("שם משפחה", "משפחה", "last name", "surname"),
        "first" to listOf("שם פרטי", "פרטי", "first name"),
        "phone" to listOf("טלפון", "טלפון 1", "טלפון בבית", "טל בית", "בית", "phone", "tel"),
        "phone2" to listOf("נייד", "טלפון נייד", "פלאפון", "סלולרי", "טלפון 2", "טלפון2", "phone 2", "phone2", "mobile", "cell"),
        "city" to listOf("עיר", "ישוב", "יישוב", "city"),
        "address" to listOf("כתובת", "רחוב", "address", "street"),
        "father" to listOf("שם האב", "שם אב", "אב", "father"),
        "chem" to listOf("חם", "חותן", "שם החותן", "שם חותן", "שם החם"),
        "shtibel" to listOf("שטיבל", "בית כנסת", "ביהכנ", "ביהכ\"נ"),
        "email" to listOf("אימייל", "מייל", "דואל", "דוא\"ל", "email", "e-mail"),
        "book" to listOf("ספר", "book"),
        "extra" to listOf("פרטים נוספים", "שדות נוספים"),
    )
    private val ORDER = listOf("name", "phone", "phone2", "city", "address", "father", "chem", "shtibel", "email", "book", "extra")
    private val HEB_HEADER = listOf("שם", "טלפון", "טלפון 2", "עיר", "כתובת", "שם האב", "חם", "בית כנסת", "אימייל", "ספר", "פרטים נוספים")

    /** מספר טלפון תקין: לפחות 7 ספרות ורק תווים של מספר טלפון */
    private val PHONE_OK = Regex("^[0-9+()\\-. *#/]{7,30}$")

    fun isValidPhone(p: String): Boolean = PHONE_OK.matches(p.trim()) && Phone.digits(p).length >= 7

    /** שם תקין: בלי תווי בקרה ובלי סימני "�" של קובץ שנקרא לא נכון */
    fun isValidName(n: String): Boolean {
        val t = n.trim()
        if (t.isEmpty() || t.length > 80) return false
        if (t.any { it == '\uFFFD' || (it.code < 32) || it in '\u0080'..'\u009F' }) return false
        val good = t.count { it.isLetterOrDigit() || it == ' ' || it in "'\"-.,()/" }
        return good >= t.length * 0.85
    }

    /** אקסל שומר מספרים כמספר ומוחק את ה-0 שבהתחלה: 527654321 ← 0527654321 */
    private fun fixPhone(p: String): String {
        var t = p.trim().removeSuffix(".0")
        if (Regex("^\\d+\\.?\\d*E\\d+$", RegexOption.IGNORE_CASE).matches(t)) t = t.toBigDecimalOrNull()?.toPlainString() ?: t
        if (t.all { it.isDigit() } && (t.length == 8 || t.length == 9) && !t.startsWith("0")) t = "0$t"
        return t
    }

    class ImportError(msg: String) : Exception(msg)

    suspend fun import(ctx: Context, uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw ImportError("לא ניתן לקרוא את הקובץ")
        val (personal, shared) = parseFile(bytes)
        if (personal.isEmpty() && shared.isEmpty())
            throw ImportError("לא נמצאו בקובץ אנשי קשר עם שם ומספר טלפון תקינים")

        // לא מכפילים מספר שכבר קיים בספר האישי
        val seen = HashSet<String>()
        val fresh = personal.filter { c ->
            val t = Phone.tail(c.phone)
            t.isNotEmpty() && seen.add(t) && LocalDb.findByPhone(LocalDb.PERSONAL, c.phone) == null
        }
        val batch = UUID.randomUUID().toString()
        LocalDb.upsertAll(LocalDb.PERSONAL, fresh, batch = batch)
        if (fresh.isNotEmpty()) {
            Prefs.lastBatch = batch
            Prefs.lastBatchCount = fresh.size
        }

        var sharedCount = 0
        var skipped = 0
        if (shared.isNotEmpty()) {
            if (Server.loggedIn()) {
                sharedCount = SharedBook.addMany(shared)
            } else skipped = shared.size
        }
        ImportResult(fresh.size, sharedCount, skipped, personal.size - fresh.size)
    }

    /** מזהה את סוג הקובץ לפי התוכן ומחזיר (ספר אישי, ספר כללי) */
    fun parseFile(bytes: ByteArray): Pair<List<Contact>, List<Contact>> {
        val rows: List<List<String>> = when {
            bytes.size >= 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte() -> {
                val r = Xlsx.read(bytes)
                if (r == null) throw ImportError("הקובץ הוא ZIP ולא קובץ אקסל. בחר קובץ xlsx, csv או vcf.")
                r
            }
            bytes.size >= 4 && (bytes[0].toInt() and 0xFF) == 0xD0 && (bytes[1].toInt() and 0xFF) == 0xCF ->
                throw ImportError("זה קובץ אקסל ישן (xls). פתח אותו באקסל ושמור בשם כ-xlsx או CSV, ואז טען שוב.")
            else -> {
                val text = decode(bytes).removePrefix("\uFEFF")
                val sample = text.take(4000)
                if (sample.count { it == '\uFFFD' || (it.code < 32 && it !in "\r\n\t") } > sample.length / 50)
                    throw ImportError("סוג הקובץ לא נתמך. אפשר לטעון קבצי xlsx, csv או vcf.")
                if (text.trimStart().startsWith("BEGIN:VCARD", ignoreCase = true)) {
                    return parseVcf(text).filter { isValidName(it.name) && isValidPhone(it.phone) } to emptyList()
                }
                val firstLine = text.lineSequence().firstOrNull() ?: return emptyList<Contact>() to emptyList()
                val delim = listOf(',', ';', '\t').maxBy { d -> firstLine.count { it == d } }
                parseCsv(text, delim)
            }
        }
        val personal = mutableListOf<Contact>()
        val shared = mutableListOf<Contact>()
        rowsToContacts(rows).forEach { (c, isShared) -> if (isShared) shared += c else personal += c }
        return personal to shared
    }

    private fun norm(h: String) = h.trim().lowercase().replace(Regex("[:*]"), "").replace(Regex("\\s+"), " ")

    /** ממיר טבלה (משורות csv או גיליון אקסל) לאנשי קשר, לפי שמות העמודות */
    fun rowsToContacts(allRows: List<List<String>>): List<Pair<Contact, Boolean>> {
        val rows = allRows.filter { r -> r.any { it.isNotBlank() } }
        if (rows.isEmpty()) return emptyList()

        // שורת הכותרת יכולה להיות אחת מ-5 השורות הראשונות (לפעמים יש כותרת גיליון מעליה)
        var headerIdx = -1
        var idx = HashMap<String, Int>()
        for (h in 0 until minOf(5, rows.size)) {
            val header = rows[h].map { norm(it) }
            val found = HashMap<String, Int>()
            HEADERS.forEach { (field, names) ->
                val i = header.indexOfFirst { cell -> names.any { norm(it) == cell } }
                if (i >= 0 && i !in found.values) found[field] = i
            }
            val hasName = "name" in found || "last" in found || "first" in found
            val hasPhone = "phone" in found || "phone2" in found
            if (hasName && hasPhone) { headerIdx = h; idx = found; break }
        }
        // עמודות עם כותרת שלא זיהינו – נשמרות כשדות נוספים בשם הכותרת
        val otherCols: List<Pair<Int, String>> = if (headerIdx >= 0)
            rows[headerIdx].mapIndexedNotNull { i, h -> if (i in idx.values || h.isBlank()) null else i to h.trim() }
        else emptyList()
        val dataRows = if (headerIdx >= 0) rows.drop(headerIdx + 1) else {
            ORDER.forEachIndexed { i, f -> idx[f] = i }
            rows
        }
        return dataRows.mapNotNull { r ->
            fun f(k: String) = idx[k]?.let { r.getOrNull(it) }?.trim() ?: ""
            val name = f("name").ifBlank { listOf(f("last"), f("first")).filter { it.isNotBlank() }.joinToString(" ") }
            val p1 = fixPhone(f("phone"))
            val p2 = fixPhone(f("phone2"))
            val phones = listOf(p1, p2).filter { isValidPhone(it) }.distinct()
            if (!isValidName(name) || phones.isEmpty()) return@mapNotNull null
            val c = Contact(
                id = UUID.randomUUID().toString(), name = name, phone = phones[0], phone2 = phones.getOrElse(1) { "" },
                city = f("city"), address = f("address"), father = f("father"),
                chem = f("chem"), shtibel = f("shtibel"), email = f("email"),
            ).let { base ->
                val more = Fields.fromText(f("extra")) +
                    otherCols.mapNotNull { (i, h) -> r.getOrNull(i)?.trim()?.takeIf { it.isNotBlank() }?.let { h to it } }
                if (more.isEmpty()) base else base.withDetails(base.details + more)
            }
            c to f("book").contains("כלל")
        }
    }

    /** קבצי CSV מאקסל בעברית שמורים לרוב ב-windows-1255 */
    private fun decode(bytes: ByteArray): String = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes)).toString()
    } catch (_: CharacterCodingException) {
        String(bytes, Charset.forName("windows-1255"))
    }

    // ---------------- CSV ----------------

    fun parseCsv(text: String, delim: Char): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val sb = StringBuilder()
        var inQ = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (inQ) {
                if (ch == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        sb.append('"'); i++
                    } else inQ = false
                } else sb.append(ch)
            } else when (ch) {
                '"' -> inQ = true
                delim -> { row.add(sb.toString()); sb.clear() }
                '\r' -> {}
                '\n' -> { row.add(sb.toString()); sb.clear(); rows.add(row); row = mutableListOf() }
                else -> sb.append(ch)
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) {
            row.add(sb.toString()); rows.add(row)
        }
        return rows.filter { r -> r.any { it.isNotBlank() } }
    }

    // ---------------- VCF ----------------

    fun parseVcf(raw: String): List<Contact> {
        val lines = raw.replace("\r\n", "\n").replace("\r", "\n").replace(Regex("\n[ \t]"), "").split("\n")
        // איחוד שורות quoted-printable שנחתכו ב-'='
        val joined = mutableListOf<String>()
        var i = 0
        while (i < lines.size) {
            var l = lines[i]
            if (l.uppercase().contains("QUOTED-PRINTABLE")) {
                while (l.endsWith("=") && i + 1 < lines.size) {
                    l = l.dropLast(1) + lines[++i]
                }
            }
            joined += l
            i++
        }

        val out = mutableListOf<Contact>()
        var fn = ""; var n = ""; var email = ""; var city = ""; var addr = ""
        var phones = mutableListOf<String>()
        for (line in joined) {
            val l = line.trim()
            when {
                l.equals("BEGIN:VCARD", true) -> {
                    fn = ""; n = ""; email = ""; city = ""; addr = ""; phones = mutableListOf()
                }
                l.equals("END:VCARD", true) -> {
                    val name = fn.ifBlank { n }
                    if (name.isNotBlank() && phones.isNotEmpty()) out += Contact(
                        id = UUID.randomUUID().toString(), name = name, phone = phones[0],
                        phone2 = phones.getOrElse(1) { "" }, city = city, address = addr, email = email,
                    )
                }
                else -> {
                    val c = l.indexOf(':')
                    if (c <= 0) continue
                    val key = l.substring(0, c).uppercase()
                    var value = l.substring(c + 1)
                    if (key.contains("QUOTED-PRINTABLE")) value = qp(value)
                    value = value.replace("\\,", ",").replace("\\;", "\u0000").replace("\\n", " ").replace("\\N", " ")
                    val prop = key.substringBefore(';').substringAfter('.')
                    when (prop) {
                        "FN" -> fn = value.replace("\u0000", ";").trim()
                        "N" -> n = value.split(';').let { p ->
                            listOf(p.getOrElse(1) { "" }, p.getOrElse(0) { "" }).filter { it.isNotBlank() }.joinToString(" ")
                        }.replace("\u0000", ";").trim()
                        "TEL" -> if (value.isNotBlank()) phones += value.trim()
                        "EMAIL" -> if (email.isBlank()) email = value.trim()
                        "ADR" -> {
                            val p = value.split(';')
                            addr = p.getOrElse(2) { "" }.trim()
                            city = p.getOrElse(3) { "" }.trim()
                        }
                    }
                }
            }
        }
        return out
    }

    private fun qp(s: String): String {
        val out = ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '=' && i + 2 < s.length) {
                val b = s.substring(i + 1, i + 3).toIntOrNull(16)
                if (b != null) {
                    out.write(b); i += 3; continue
                }
            }
            out.write(ch.code and 0xFF)
            i++
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    // ---------------- גיבוי ----------------

    /** טקסט CSV של כל אנשי הקשר (אישי + כללי), מתאים לאקסל */
    fun csvText(includeShared: Boolean = true): Pair<String, Int> {
        fun esc(s: String) = if (s.any { it == ',' || it == '"' || it == '\n' }) "\"" + s.replace("\"", "\"\"") + "\"" else s
        fun row(c: Contact, book: String) = listOf(c.name, c.phone, c.phone2, c.city, c.address, c.father, c.chem, c.shtibel, c.email, book, Fields.toText(c.extras))
            .joinToString(",") { esc(it) }
        val personal = LocalDb.all(LocalDb.PERSONAL)
        val shared = if (includeShared) LocalDb.all(LocalDb.SHARED) else emptyList()
        val sb = StringBuilder("\uFEFF").append(HEB_HEADER.joinToString(",")).append("\r\n")
        personal.forEach { sb.append(row(it, "אישי")).append("\r\n") }
        shared.forEach { sb.append(row(it, "כללי")).append("\r\n") }
        return sb.toString() to (personal.size + shared.size)
    }

    suspend fun exportCsv(ctx: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        val (text, n) = csvText()
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            ?: error("לא ניתן לשמור את הקובץ")
        n
    }
}
