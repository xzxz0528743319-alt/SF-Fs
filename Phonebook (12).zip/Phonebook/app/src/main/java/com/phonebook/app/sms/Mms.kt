package com.phonebook.app.sms

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.telephony.SmsManager
import androidx.core.content.FileProvider
import java.io.File
import java.util.UUID

/** חלק של הודעת MMS שמוצג בשיחה */
data class MmsPart(val type: String, val text: String?, val uri: Uri)

/**
 * קבלת MMS (תמונות והודעות קבוצתיות):
 * 1. הרשת שולחת הודעת "יש לך MMS" (WAP push) עם כתובת להורדה
 * 2. מורידים את ההודעה מהשרת של חברת הסלולר
 * 3. מפענחים ושומרים אותה במאגר ההודעות של הטלפון
 */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.WAP_PUSH_DELIVER_ACTION) return
        val data = intent.getByteArrayExtra("data") ?: return
        val notif = MmsPdu.parse(data) ?: return
        if (notif.type != MmsPdu.TYPE_NOTIFICATION_IND) return
        val location = notif.contentLocation ?: return
        val sub = intent.getIntExtra("subscription", -1)
        Mms.download(context, location, notif.from ?: "", sub)
    }
}

/** נקרא כשההורדה מהשרת הסתיימה */
class MmsDownloadedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val path = intent.getStringExtra(Mms.EXTRA_FILE) ?: return
        val from = intent.getStringExtra(Mms.EXTRA_FROM) ?: ""
        val file = File(path)
        val pending = goAsync()
        Thread {
            try {
                val ok = resultCode == Activity.RESULT_OK && file.exists() && file.length() > 0
                val msg = if (ok) MmsPdu.parse(file.readBytes()) else null
                if (msg != null && msg.type == MmsPdu.TYPE_RETRIEVE_CONF) {
                    val sender = msg.from?.takeIf { it.isNotBlank() } ?: from
                    Mms.store(context, msg, sender)
                    val text = msg.parts.firstOrNull { it.isText }?.text()
                    val hasImage = msg.parts.any { it.contentType.startsWith("image/") }
                    SmsNotifier.show(context, sender, listOfNotNull(if (hasImage) "📷 תמונה" else null, text).joinToString(" ").ifBlank { "הודעת MMS" })
                } else if (from.isNotBlank()) {
                    SmsNotifier.show(context, from, "התקבלה הודעת MMS שלא ניתן היה להוריד (בדוק שהנתונים הסלולריים פועלים)")
                }
            } catch (_: Exception) {
            } finally {
                file.delete()
                pending.finish()
            }
        }.start()
    }
}

object Mms {
    const val EXTRA_FILE = "file"
    const val EXTRA_FROM = "from"

    private fun authority(ctx: Context) = ctx.packageName + ".mmsfiles"

    fun download(ctx: Context, location: String, from: String, subId: Int) {
        try {
            val dir = File(ctx.cacheDir, "mms").apply { mkdirs() }
            val file = File(dir, UUID.randomUUID().toString() + ".pdu").apply { createNewFile() }
            val uri = FileProvider.getUriForFile(ctx, authority(ctx), file)
            try {
                ctx.grantUriPermission("com.android.phone", uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            val done = PendingIntent.getBroadcast(
                ctx, file.name.hashCode(),
                Intent(ctx, MmsDownloadedReceiver::class.java).putExtra(EXTRA_FILE, file.absolutePath).putExtra(EXTRA_FROM, from),
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            )
            val sm: SmsManager = when {
                Build.VERSION.SDK_INT >= 31 && subId >= 0 -> ctx.getSystemService(SmsManager::class.java).createForSubscriptionId(subId)
                Build.VERSION.SDK_INT >= 31 -> ctx.getSystemService(SmsManager::class.java)
                subId >= 0 -> @Suppress("DEPRECATION") SmsManager.getSmsManagerForSubscriptionId(subId)
                else -> @Suppress("DEPRECATION") SmsManager.getDefault()
            }
            sm.downloadMultimediaMessage(ctx, location, uri, null, done)
        } catch (_: Exception) {
            if (from.isNotBlank()) SmsNotifier.show(ctx, from, "התקבלה הודעת MMS שלא ניתן היה להוריד")
        }
    }

    /** שמירת ההודעה במאגר ההודעות של הטלפון */
    fun store(ctx: Context, m: MmsPdu.Message, from: String) {
        val cr = ctx.contentResolver
        val recipients = (listOf(from) + m.to).filter { it.isNotBlank() }.distinct()
        val threadId = try {
            if (recipients.size > 1) Telephony.Threads.getOrCreateThreadId(ctx, recipients.toSet())
            else Telephony.Threads.getOrCreateThreadId(ctx, from)
        } catch (_: Exception) {
            Telephony.Threads.getOrCreateThreadId(ctx, from)
        }
        val v = ContentValues().apply {
            put("thread_id", threadId)
            put("date", m.date)
            put("date_sent", m.date)
            put("msg_box", 1)            // דואר נכנס
            put("read", 0)
            put("seen", 0)
            put("m_type", 132)           // retrieve-conf
            put("v", 0x12)
            put("ct_t", "application/vnd.wap.multipart.related")
            m.subject?.let { put("sub", it); put("sub_cs", 106) }
            m.transactionId?.let { put("tr_id", it) }
            m.messageId?.let { put("m_id", it) }
        }
        val msgUri = cr.insert(Uri.parse("content://mms/inbox"), v) ?: return
        val id = ContentUris.parseId(msgUri)
        m.parts.filter { !it.isSmil }.forEachIndexed { i, p ->
            val pv = ContentValues().apply {
                put("mid", id)
                put("ct", p.contentType)
                put("cid", "<part$i>")
                put("cl", p.name ?: "part$i")
                if (p.isText) {
                    put("chset", 106)
                    put("text", p.text())
                }
            }
            val partUri = cr.insert(Uri.parse("content://mms/$id/part"), pv)
            if (!p.isText && partUri != null) {
                try {
                    cr.openOutputStream(partUri)?.use { it.write(p.data) }
                } catch (_: Exception) {
                }
            }
        }
        // כתובות: השולח (137) ושאר הנמענים (151)
        cr.insert(Uri.parse("content://mms/$id/addr"), ContentValues().apply {
            put("address", from); put("type", 137); put("charset", 106)
        })
        m.to.forEach { t ->
            cr.insert(Uri.parse("content://mms/$id/addr"), ContentValues().apply {
                put("address", t); put("type", 151); put("charset", 106)
            })
        }
    }

    /** חלקי הודעת MMS לתצוגה: טקסט ותמונות */
    fun parts(ctx: Context, mmsId: Long): List<MmsPart> = try {
        ctx.contentResolver.query(
            Uri.parse("content://mms/part"), arrayOf("_id", "ct", "text"), "mid=?", arrayOf(mmsId.toString()), null
        )?.use { c ->
            buildList {
                while (c.moveToNext()) {
                    val pid = c.getLong(0)
                    val ct = c.getString(1) ?: ""
                    if (ct.contains("smil")) continue
                    add(MmsPart(ct, if (ct.startsWith("text/")) c.getString(2) else null, Uri.parse("content://mms/part/$pid")))
                }
            }
        } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }

    /** כתובת השולח או הנמען של הודעת MMS */
    fun address(ctx: Context, mmsId: Long, inbox: Boolean): String = try {
        ctx.contentResolver.query(
            Uri.parse("content://mms/$mmsId/addr"), arrayOf("address", "type"), null, null, null
        )?.use { c ->
            var found = ""
            while (c.moveToNext()) {
                val a = c.getString(0) ?: continue
                if (a == "insert-address-token") continue
                val type = c.getInt(1)
                if ((inbox && type == 137) || (!inbox && type == 151)) return@use a
                if (found.isEmpty()) found = a
            }
            found
        } ?: ""
    } catch (_: Exception) {
        ""
    }
}
