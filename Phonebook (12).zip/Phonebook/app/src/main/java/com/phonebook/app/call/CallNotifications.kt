package com.phonebook.app.call

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.telecom.Call
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.content.ContextCompat
import com.phonebook.app.App
import com.phonebook.app.R
import com.phonebook.app.data.CallerId

fun callStatusText(state: Int): String = when (state) {
    Call.STATE_RINGING -> "שיחה נכנסת"
    Call.STATE_DIALING, Call.STATE_CONNECTING -> "מחייג…"
    Call.STATE_ACTIVE -> "בשיחה"
    Call.STATE_HOLDING -> "בהמתנה"
    Call.STATE_SELECT_PHONE_ACCOUNT -> "בחר כרטיס SIM"
    Call.STATE_DISCONNECTING, Call.STATE_DISCONNECTED -> "השיחה הסתיימה"
    else -> ""
}

object CallNotifications {
    private const val ID = 1001
    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    fun cancel(ctx: Context) = NotificationManagerCompat.from(ctx).cancel(ID)

    @SuppressLint("MissingPermission")
    fun update(ctx: Context) {
        val info = CallManager.call.value
        if (info == null || info.state == Call.STATE_DISCONNECTED) {
            cancel(ctx); return
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return

        val name = CallerId.lookup(ctx, info.number)?.name ?: info.number.ifBlank { "מספר חסוי" }
        val open = PendingIntent.getActivity(ctx, 0, InCallActivity.intent(ctx), FLAGS)

        val builder = if (info.state == Call.STATE_RINGING) {
            val answer = PendingIntent.getActivity(
                ctx, 1, InCallActivity.intent(ctx).putExtra(InCallActivity.EXTRA_ANSWER, true), FLAGS
            )
            val person = Person.Builder().setName(name).setImportant(true).build()
            NotificationCompat.Builder(ctx, App.CH_INCOMING)
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(person, CallActionReceiver.pending(ctx, CallActionReceiver.DECLINE), answer))
                .setFullScreenIntent(open, true)
                .setPriority(NotificationCompat.PRIORITY_MAX)
        } else {
            NotificationCompat.Builder(ctx, App.CH_ONGOING)
                .setContentTitle(name)
                .setContentText(callStatusText(info.state))
                .addAction(0, "נתק", CallActionReceiver.pending(ctx, CallActionReceiver.HANGUP))
                .apply {
                    if (info.state == Call.STATE_ACTIVE && info.connectTime > 0) {
                        setUsesChronometer(true); setWhen(info.connectTime); setShowWhen(true)
                    }
                }
        }
        builder.setSmallIcon(R.drawable.ic_stat_phone)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
        try {
            NotificationManagerCompat.from(ctx).notify(ID, builder.build())
        } catch (_: Exception) {
        }
    }
}

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            DECLINE, HANGUP -> CallManager.hangup()
        }
    }

    companion object {
        const val DECLINE = "com.phonebook.app.DECLINE"
        const val HANGUP = "com.phonebook.app.HANGUP"

        fun pending(ctx: Context, action: String): PendingIntent = PendingIntent.getBroadcast(
            ctx, action.hashCode(),
            Intent(ctx, CallActionReceiver::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }
}
