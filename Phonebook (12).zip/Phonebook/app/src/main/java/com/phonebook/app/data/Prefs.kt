package com.phonebook.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import java.security.MessageDigest

object Prefs {
    const val PRIVACY_URL = "https://github.com/xzxz0528743319-alt/SF-Fs/blob/main/PRIVACY.md"

    private lateinit var sp: SharedPreferences

    /** 0 = לפי המערכת, 1 = בהיר, 2 = כהה */
    val theme = MutableStateFlow(0)

    /** כתובת המייל של המשתמש המחובר, או null */
    val session = MutableStateFlow<String?>(null)

    /** עולה בכל שינוי של נעיצה / ארכיון / שמורות – המסכים מתרעננים */
    val flags = MutableStateFlow(0)

    private fun strSet(k: String): Set<String> = sp.getStringSet(k, emptySet()) ?: emptySet()
    private fun toggle(k: String, v: String, on: Boolean) {
        val s = strSet(k).toMutableSet()
        if (on) s += v else s -= v
        sp.edit().putStringSet(k, s).apply()
        flags.value = flags.value + 1
    }

    fun isArchived(threadId: Long) = threadId.toString() in strSet("archived")
    fun setArchived(threadId: Long, on: Boolean) = toggle("archived", threadId.toString(), on)
    fun isPinned(threadId: Long) = threadId.toString() in strSet("pinned")
    fun setPinned(threadId: Long, on: Boolean) = toggle("pinned", threadId.toString(), on)
    fun isStarred(msgId: Long) = msgId.toString() in strSet("starred")
    fun setStarred(msgId: Long, on: Boolean) = toggle("starred", msgId.toString(), on)
    fun starredIds(): Set<Long> = strSet("starred").mapNotNull { it.toLongOrNull() }.toSet()

    // ---- ספאם (מפתח שולח: 9 ספרות אחרונות או שם השולח) ----
    fun spamMarked(): Set<String> = strSet("spam_marked")
    fun spamTrusted(): Set<String> = strSet("spam_trusted")
    fun setSpamMark(key: String, spam: Boolean) {
        val m = strSet("spam_marked").toMutableSet()
        val t = strSet("spam_trusted").toMutableSet()
        if (spam) { m += key; t -= key } else { m -= key; t += key }
        sp.edit().putStringSet("spam_marked", m).putStringSet("spam_trusted", t).apply()
        flags.value = flags.value + 1
    }
    var spamFilter: Boolean
        get() = sp.getBoolean("spam_filter", true)
        set(v) { sp.edit().putBoolean("spam_filter", v).apply(); flags.value = flags.value + 1 }

    // ---- מועדפים (לפי 9 הספרות האחרונות של המספר) ----
    fun isFavorite(phone: String) = Phone.tail(phone).let { it.isNotEmpty() && it in strSet("favorites") }
    fun setFavorite(phone: String, on: Boolean) = Phone.tail(phone).let { if (it.isNotEmpty()) toggle("favorites", it, on) }
    fun favoriteTails(): Set<String> = strSet("favorites")

    // ---- גודל טקסט: 0 רגיל, 1 גדול, 2 גדול מאוד ----
    val textScale = MutableStateFlow(0)
    fun setTextScale(v: Int) {
        sp.edit().putInt("text_scale", v).apply(); textScale.value = v
    }

    // ---- נעילה ----
    var lockEnabled: Boolean
        get() = sp.getBoolean("lock", false)
        set(v) = sp.edit().putBoolean("lock", v).apply()

    // ---- גיבוי אוטומטי ----
    var autoBackup: Boolean
        get() = sp.getBoolean("auto_backup", true)
        set(v) = sp.edit().putBoolean("auto_backup", v).apply()
    var lastBackup: Long
        get() = sp.getLong("last_backup", 0)
        set(v) = sp.edit().putLong("last_backup", v).apply()

    // ---- שרת: מנהל / אישור משתמש ----
    var isAdmin: Boolean
        get() = sp.getBoolean("is_admin", false)
        set(v) = sp.edit().putBoolean("is_admin", v).apply()
    var approved: Boolean
        get() = sp.getBoolean("approved", true)
        set(v) = sp.edit().putBoolean("approved", v).apply()

    // ---- עדכונים ----
    var lastUpdateCheck: Long
        get() = sp.getLong("update_check", 0)
        set(v) = sp.edit().putLong("update_check", v).apply()

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        theme.value = sp.getInt("theme", 0)
        textScale.value = sp.getInt("text_scale", 0)
        session.value = if (refreshToken.isNotBlank()) email else null
    }

    private fun s(k: String, def: String = "") = sp.getString(k, def) ?: def
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    var lastBatch: String
        get() = s("last_batch")
        set(v) = put("last_batch", v)
    var lastBatchCount: Int
        get() = sp.getInt("last_batch_n", 0)
        set(v) = sp.edit().putInt("last_batch_n", v).apply()
    var cleanupDone: Boolean
        get() = sp.getBoolean("cleanup_v1", false)
        set(v) = sp.edit().putBoolean("cleanup_v1", v).apply()

    var autoRecord: Boolean
        get() = sp.getBoolean("auto_record", false)
        set(v) = sp.edit().putBoolean("auto_record", v).apply()

    var setupDone: Boolean
        get() = sp.getBoolean("setup_done", false)
        set(v) = sp.edit().putBoolean("setup_done", v).apply()

    fun setTheme(v: Int) {
        sp.edit().putInt("theme", v).apply()
        theme.value = v
    }

    // ---- שרת ----
    var serverUrl: String
        get() = s("sb_url")
        set(v) = put("sb_url", v.trim().trimEnd('/'))
    var serverKey: String
        get() = s("sb_key")
        set(v) = put("sb_key", v.trim())

    var accessToken: String
        get() = s("access")
        set(v) = put("access", v)
    var refreshToken: String
        get() = s("refresh")
        set(v) = put("refresh", v)
    var tokenExpiry: Long
        get() = sp.getLong("expiry", 0)
        set(v) = sp.edit().putLong("expiry", v).apply()
    var userId: String
        get() = s("uid")
        set(v) = put("uid", v)
    var email: String
        get() = s("email")
        set(v) = put("email", v)
    var lastSync: String
        get() = s("last_sync")
        set(v) = put("last_sync", v)

    fun clearSession() {
        sp.edit().remove("access").remove("refresh").remove("expiry").remove("uid")
            .remove("email").remove("last_sync").remove("is_admin").remove("approved").apply()
        session.value = null
    }

    // ---- סיסמת מחיקה ----
    val hasDeletePassword: Boolean get() = s("del_pw").isNotBlank()
    fun setDeletePassword(pw: String?) = put("del_pw", if (pw.isNullOrBlank()) "" else hash(pw))
    fun checkDeletePassword(pw: String) = !hasDeletePassword || hash(pw) == s("del_pw")
    private fun hash(pw: String) = MessageDigest.getInstance("SHA-256")
        .digest(pw.toByteArray()).joinToString("") { "%02x".format(it) }

    // ---- עוזרת ----
    var aiKey: String
        get() = s("ai_key")
        set(v) = put("ai_key", v.trim())
    var autoPhoneSync: Boolean
        get() = sp.getBoolean("auto_phone_sync", true)
        set(v) = sp.edit().putBoolean("auto_phone_sync", v).apply()
    var aiPersonal: Boolean
        get() = s("ai_personal") == "1"
        set(v) = put("ai_personal", if (v) "1" else "")
    var aiModel: String
        get() = s("ai_model", "claude-haiku-5-5")
        set(v) = put("ai_model", v.trim())
}
