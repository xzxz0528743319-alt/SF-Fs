package com.phonebook.app.net

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject

/**
 * עדכון האפליקציה מתוכה: בודק ב-GitHub אם יש גרסה חדשה, מוריד ומתקין.
 * (לא פעיל כשהאפליקציה הותקנה מ-Google Play – שם החנות מעדכנת.)
 */
object Updater {
    private const val REPO = "xzxz0528743319-alt/SF-Fs"
    private const val TAG = "app"

    data class Update(val versionCode: Long, val url: String, val sizeBytes: Long)

    fun currentVersionCode(ctx: Context): Long = try {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else @Suppress("DEPRECATION") pi.versionCode.toLong()
    } catch (_: Exception) {
        0
    }

    fun currentVersionName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Exception) {
        ""
    }

    /** האם הותקנה מחנות Google Play */
    fun fromPlayStore(ctx: Context): Boolean = try {
        val installer = if (Build.VERSION.SDK_INT >= 30) ctx.packageManager.getInstallSourceInfo(ctx.packageName).installingPackageName
        else @Suppress("DEPRECATION") ctx.packageManager.getInstallerPackageName(ctx.packageName)
        installer == "com.android.vending"
    } catch (_: Exception) {
        false
    }

    /** מחזיר עדכון אם יש גרסה חדשה יותר, אחרת null */
    suspend fun check(ctx: Context): Update? = withContext(Dispatchers.IO) {
        if (fromPlayStore(ctx)) return@withContext null
        val req = Request.Builder().url("https://api.github.com/repos/$REPO/releases/tags/$TAG")
            .header("Accept", "application/vnd.github+json").build()
        val json = JSONObject(Net.execute(req))
        // שם הגרסה בבנייה: "Phonebook N" ומספר הגרסה באפליקציה הוא 100 + N
        val run = Regex("(\\d+)").find(json.optString("name"))?.value?.toLongOrNull() ?: return@withContext null
        val remote = 100 + run
        val assets = json.optJSONArray("assets") ?: return@withContext null
        var url = ""
        var size = 0L
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.optString("name") == "phonebook.apk") {
                url = a.optString("browser_download_url"); size = a.optLong("size")
            }
        }
        if (url.isBlank() || remote <= currentVersionCode(ctx)) null else Update(remote, url, size)
    }

    /** מוריד ומתקין. onProgress מקבל 0..1 */
    suspend fun install(ctx: Context, u: Update, onProgress: (Float) -> Unit) = withContext(Dispatchers.IO) {
        val installer = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        val sessionId = installer.createSession(params)
        installer.openSession(sessionId).use { session ->
            Net.client.newCall(Request.Builder().url(u.url).build()).execute().use { resp ->
                if (!resp.isSuccessful) throw ApiError("ההורדה נכשלה (${resp.code})")
                val body = resp.body ?: throw ApiError("ההורדה נכשלה")
                val total = body.contentLength().takeIf { it > 0 } ?: u.sizeBytes
                session.openWrite("phonebook.apk", 0, total).use { out ->
                    body.byteStream().use { input ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) onProgress(done.toFloat() / total)
                        }
                    }
                    session.fsync(out)
                }
            }
            val pi = PendingIntent.getBroadcast(
                ctx, sessionId, Intent(ctx, UpdateReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            )
            session.commit(pi.intentSender)
        }
    }
}

/** תוצאת ההתקנה: אם צריך אישור מהמשתמש – פותחים את מסך האישור */
class UpdateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = intent.getParcelableExtra<Intent>(Intent.EXTRA_INTENT) ?: return
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(confirm)
                } catch (_: Exception) {
                }
            }
            PackageInstaller.STATUS_SUCCESS -> {}
            else -> {
                val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
                Toast.makeText(context, "העדכון לא הותקן. $msg", Toast.LENGTH_LONG).show()
            }
        }
    }
}
