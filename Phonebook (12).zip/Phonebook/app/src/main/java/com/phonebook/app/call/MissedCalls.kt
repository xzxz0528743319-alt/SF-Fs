package com.phonebook.app.call

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.phonebook.app.App
import com.phonebook.app.MainActivity
import com.phonebook.app.R
import com.phonebook.app.data.CallerId

/**
 * כשהאפליקציה היא אפליקציית הטלפון, המערכת מבקשת ממנה להציג את ההתראה על שיחות שלא נענו.
 */
class MissedCallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelecomManager.ACTION_SHOW_MISSED_CALLS_NOTIFICATION) return
        val count = intent.getIntExtra(TelecomManager.EXTRA_NOTIFICATION_COUNT, 0)
        val number = intent.getStringExtra(TelecomManager.EXTRA_NOTIFICATION_PHONE_NUMBER) ?: ""
        if (count <= 0) MissedCalls.cancel(context) else MissedCalls.show(context, count, number)
    }
}

object MissedCalls {
    private const val ID = 3001

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, count: Int, number: String) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val name = if (number.isNotBlank()) CallerId.lookup(ctx, number)?.name ?: number else ""
        val open = PendingIntent.getActivity(
            ctx, 31, Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_CALLS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(ctx, App.CH_MISSED)
            .setSmallIcon(R.drawable.ic_stat_phone)
            .setContentTitle(if (count == 1) "שיחה שלא נענתה" else "$count שיחות שלא נענו")
            .setContentText(if (name.isNotBlank()) name else "לחץ כדי לראות ביומן")
            .setCategory(NotificationCompat.CATEGORY_MISSED_CALL)
            .setContentIntent(open)
            .setAutoCancel(true)
        if (number.isNotBlank()) {
            b.addAction(
                0, "התקשר חזרה",
                PendingIntent.getActivity(
                    ctx, 32,
                    Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)).setClass(ctx, MainActivity::class.java)
                        .putExtra(MainActivity.EXTRA_CALL_NOW, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            b.addAction(
                0, "הודעה",
                PendingIntent.getActivity(
                    ctx, 33,
                    Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_SMS, number)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        try {
            NotificationManagerCompat.from(ctx).notify(ID, b.build())
        } catch (_: Exception) {
        }
    }

    /** נקרא כשהמשתמש פותח את יומן השיחות */
    fun cancel(ctx: Context) {
        NotificationManagerCompat.from(ctx).cancel(ID)
        try {
            ctx.getSystemService(TelecomManager::class.java).cancelMissedCallsNotification()
        } catch (_: Exception) {
        }
    }
}
