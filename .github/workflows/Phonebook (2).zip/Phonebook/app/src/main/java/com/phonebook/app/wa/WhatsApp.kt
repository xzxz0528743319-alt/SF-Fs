package com.phonebook.app.wa

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.provider.ContactsContract
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.phonebook.app.data.LocalDb

/**
 * חיבור לוואטסאפ – מה שאפשר בלי לפרוץ את וואטסאפ (וואטסאפ לא מאפשרת לאפליקציות לקרוא את השיחות):
 *  1. אנשי הקשר בטלפון שיש להם וואטסאפ (וואטסאפ עצמה רושמת אותם באנשי הקשר של הטלפון).
 *  2. מעכשיו והלאה: מי שכותב / מתקשר אליך בוואטסאפ – לפי ההתראות (רק שם, מספר ושעה. בלי תוכן ההודעות).
 * כך העוזרת יכולה למצוא "את מי שכתב לי בוואטסאפ אתמול" ולהתקשר אליו בשיחה רגילה.
 */
object WhatsApp {
    data class Chat(val name: String, val number: String, val at: Long, val count: Int, val call: Boolean)
    data class WaContact(val name: String, val number: String)

    private const val PKG = "com.whatsapp"
    private const val PKG_BIZ = "com.whatsapp.w4b"
    private lateinit var helper: SQLiteOpenHelper

    fun init(ctx: Context) {
        helper = object : SQLiteOpenHelper(ctx, "whatsapp_log.db", null, 1) {
            override fun onCreate(db: SQLiteDatabase) {
                db.execSQL("CREATE TABLE chats (number TEXT PRIMARY KEY, name TEXT NOT NULL, at INTEGER NOT NULL, count INTEGER NOT NULL, call INTEGER NOT NULL)")
            }
            override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
        }
    }

    private fun ready() = ::helper.isInitialized

    /** האם המשתמש נתן גישה להתראות (נדרש כדי לזהות מי כותב בוואטסאפ) */
    fun hasAccess(ctx: Context): Boolean {
        val flat = Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: return false
        val me = ComponentName(ctx, WaListener::class.java).flattenToString()
        return flat.split(":").any { it.equals(me, true) }
    }

    fun installed(ctx: Context) = listOf(PKG, PKG_BIZ).any { runCatching { ctx.packageManager.getPackageInfo(it, 0) }.isSuccess }

    fun isWhatsApp(pkg: String) = pkg == PKG || pkg == PKG_BIZ

    /** רושם שמישהו כתב / התקשר בוואטסאפ */
    fun record(name: String, number: String, call: Boolean) {
        if (!ready() || number.isBlank()) return
        runCatching {
            val db = helper.writableDatabase
            // (בלי "ON CONFLICT" – לא נתמך באנדרואיד 10)
            val now = System.currentTimeMillis()
            val updated = db.compileStatement("UPDATE chats SET name=?, at=?, count=count+1, call=? WHERE number=?").apply {
                bindString(1, name); bindLong(2, now); bindLong(3, if (call) 1 else 0); bindString(4, number)
            }.executeUpdateDelete()
            if (updated == 0) db.insert("chats", null, android.content.ContentValues().apply {
                put("number", number); put("name", name); put("at", now); put("count", 1); put("call", if (call) 1 else 0)
            })
            // שומרים רק 500 אחרונים
            db.execSQL("DELETE FROM chats WHERE number NOT IN (SELECT number FROM chats ORDER BY at DESC LIMIT 500)")
            LocalDb.changes.value++
        }
    }

    /** השיחות האחרונות בוואטסאפ (מהחדשה לישנה) */
    fun recent(limit: Int = 30, query: String = ""): List<Chat> {
        if (!ready()) return emptyList()
        val q = query.trim()
        return runCatching {
            helper.readableDatabase.rawQuery(
                "SELECT name, number, at, count, call FROM chats " +
                    (if (q.isNotEmpty()) "WHERE name LIKE ? OR number LIKE ? " else "") +
                    "ORDER BY at DESC LIMIT $limit",
                if (q.isNotEmpty()) arrayOf("%$q%", "%${q.filter { it.isDigit() }.ifBlank { q }}%") else null
            ).use { c ->
                buildList { while (c.moveToNext()) add(Chat(c.getString(0), c.getString(1), c.getLong(2), c.getInt(3), c.getInt(4) == 1)) }
            }
        }.getOrDefault(emptyList())
    }

    fun clear() {
        if (!ready()) return
        runCatching { helper.writableDatabase.delete("chats", null, null) }
    }

    /** אנשי הקשר בטלפון שיש להם וואטסאפ (וואטסאפ רושמת אותם באנשי הקשר) */
    fun contacts(ctx: Context, query: String = "", limit: Int = 40): List<WaContact> {
        val out = mutableListOf<WaContact>()
        val q = query.trim()
        runCatching {
            ctx.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data.DISPLAY_NAME, ContactsContract.Data.DATA1),
                ContactsContract.Data.MIMETYPE + "=?" + if (q.isNotEmpty()) " AND " + ContactsContract.Data.DISPLAY_NAME + " LIKE ?" else "",
                if (q.isNotEmpty()) arrayOf("vnd.android.cursor.item/vnd.com.whatsapp.profile", "%$q%") else arrayOf("vnd.android.cursor.item/vnd.com.whatsapp.profile"),
                ContactsContract.Data.DISPLAY_NAME
            )?.use { c ->
                val seen = HashSet<String>()
                while (c.moveToNext() && out.size < limit) {
                    val jid = c.getString(1).orEmpty()             // למשל 972501234567@s.whatsapp.net
                    val num = jidToNumber(jid) ?: continue
                    if (seen.add(num)) out += WaContact(c.getString(0).orEmpty(), num)
                }
            }
        }
        return out
    }

    /** "972501234567@s.whatsapp.net" → "+972501234567". קבוצות (@g.us) – לא */
    fun jidToNumber(jid: String?): String? {
        if (jid == null || !jid.contains("@s.whatsapp.net")) return null
        val d = jid.substringBefore("@").filter { it.isDigit() }
        return if (d.length >= 8) "+$d" else null
    }
}

/** מאזין להתראות של וואטסאפ – רק כדי לדעת מי כתב / התקשר (שם + מספר + שעה) */
class WaListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!WhatsApp.isWhatsApp(sbn.packageName)) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        // המספר נמצא במזהה השיחה של ההתראה (באנדרואיד 10 ומעלה)
        val ex = n.extras ?: return
        val title = (ex.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE) ?: ex.getCharSequence(Notification.EXTRA_TITLE))?.toString().orEmpty()
        if (n.shortcutId?.contains("@g.us") == true) return          // קבוצה – לא אדם אחד
        val number = WhatsApp.jidToNumber(n.shortcutId)
            ?: personTel(ex)
            ?: numberByName(title.substringBefore(" (").trim())  // גרסאות חדשות מסתירות את המספר – מחפשים לפי השם באנשי הקשר
            ?: return
        val isCall = n.category == Notification.CATEGORY_CALL || n.category == Notification.CATEGORY_MISSED_CALL
        val name = title.substringBefore(" (").substringBefore(":").trim().ifBlank { number }
        WhatsApp.record(name, number, isCall)
    }

    private fun personTel(ex: android.os.Bundle): String? = runCatching {
        @Suppress("DEPRECATION")
        val list = ex.getParcelableArrayList<android.app.Person>(Notification.EXTRA_PEOPLE_LIST)
        list?.firstNotNullOfOrNull { p -> p.uri?.takeIf { it.startsWith("tel:") }?.removePrefix("tel:") }
    }.getOrNull()

    private fun numberByName(name: String): String? {
        if (name.isBlank()) return null
        return runCatching {
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + "=?", arrayOf(name), null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        }.getOrNull()
    }
}
