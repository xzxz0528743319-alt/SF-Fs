package com.phonebook.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.collectAsState
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.phonebook.app.data.Prefs
import com.phonebook.app.ui.AppRoot
import com.phonebook.app.ui.LockScreen
import com.phonebook.app.ui.PhonebookTheme

class MainActivity : FragmentActivity() {
    private val launch = mutableStateOf<Intent?>(null)
    private val locked = mutableStateOf(false)
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // אייקונים לבנים בשורת המצב, על הכותרת הכחולה
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        sanitize(intent)
        if (savedInstanceState == null) launch.value = callNow(intent)
        if (fromDriving(intent)) drivingOpenAt = System.currentTimeMillis()
        locked.value = Prefs.lockEnabled && canLock() && !fromDriving(intent)
        setContent {
            PhonebookTheme {
                // יציאה ממצב נהיגה – נועלים שוב (אם הנעילה מופעלת)
                val drv = com.phonebook.app.ui.AssistantBus.driving.collectAsState().value
                androidx.compose.runtime.LaunchedEffect(drv) {
                    if (drv) wasDriving = true
                    else if (wasDriving) { wasDriving = false; if (Prefs.lockEnabled && canLock()) locked.value = true }
                }
                if (locked.value) LockScreen(onUnlock = { authenticate() })
                else AppRoot(launch.value, onConsumed = { launch.value = null })
            }
        }
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = System.currentTimeMillis()
    }

    override fun onStart() {
        super.onStart()
        // נועלים שוב אם האפליקציה הייתה ברקע יותר מדקה
        // בנהיגה (הכפתור הצף / חזרה משיחה) – בלי נעילה, כדי לא לגעת בטלפון
        if (Prefs.lockEnabled && canLock() && stoppedAt > 0 && System.currentTimeMillis() - stoppedAt > 60_000 &&
            System.currentTimeMillis() - drivingOpenAt > 3000 && !com.phonebook.app.ui.AssistantBus.driving.value
        ) locked.value = true
    }

    override fun onResume() {
        super.onResume()
        top = this
        com.phonebook.app.pc.DrivingBubbleService.inApp(true)
        val b = com.phonebook.app.ui.AssistantBus
        if (b.callEndedAt > 0 && System.currentTimeMillis() - b.callEndedAt < 5000) {
            b.callEndedAt = 0L
            moveTaskToBack(true)
        }
    }

    override fun onPause() {
        if (top === this) top = null
        com.phonebook.app.pc.DrivingBubbleService.inApp(false)
        com.phonebook.app.widget.FavoritesWidget.refresh(this)
        super.onPause()
    }

    override fun onDestroy() {
        if (top === this) top = null
        super.onDestroy()
    }

    private var wasDriving = false
    private var drivingOpenAt = 0L
    private fun fromDriving(i: Intent?) = i?.getBooleanExtra(EXTRA_ASSISTANT_VOICE, false) == true

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        sanitize(intent)
        if (fromDriving(intent)) { drivingOpenAt = System.currentTimeMillis(); locked.value = false }   // פתיחה מהכפתור הצף בנהיגה – בלי נעילה
        launch.value = callNow(intent)
    }

    /**
     * אבטחה: אפליקציה אחרת בטלפון לא יכולה לגרום לנו לחייג בלי אישור או לפתוח בלי נעילה.
     * פעולות מיוחדות מתבצעות רק אם הכוונה נוצרה ע"י האפליקציה עצמה (עם הסוד הפנימי).
     */
    private fun sanitize(i: Intent?) {
        if (i == null || trusted(i)) return
        i.removeExtra(EXTRA_CALL_NOW)
        i.removeExtra(EXTRA_ASSISTANT_VOICE)
        i.removeExtra(EXTRA_ASSISTANT_TALK)
    }

    /** חיוג מהווידג'ט / מתזכורת – מחייגים מיד, גם כשהאפליקציה נעולה (החיוג עצמו לא חושף את הספר) */
    private fun callNow(i: Intent?): Intent? {
        if (i?.getBooleanExtra(EXTRA_CALL_NOW, false) == true && i.data?.scheme == "tel") {
            com.phonebook.app.ui.Actions.call(this, android.net.Uri.decode(i.data?.schemeSpecificPart ?: ""))
            return null
        }
        return i
    }

    private val authenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    fun canLock() = BiometricManager.from(this).canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS

    fun authenticate() {
        if (!canLock()) {
            locked.value = false; return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                locked.value = false
            }
        })
        prompt.authenticate(
            BiometricPrompt.PromptInfo.Builder()
                .setTitle(com.phonebook.app.ui.tr("ספר טלפונים נעול"))
                .setSubtitle(com.phonebook.app.ui.tr("טביעת אצבע או קוד הטלפון"))
                .setAllowedAuthenticators(authenticators)
                .build()
        )
    }

    companion object {
        /** הפעילות הפתוחה כרגע (כדי להחזיר את המשתמש ל-Waze אחרי שיחה) */
        @Volatile var top: MainActivity? = null
        private const val EXTRA_TOKEN = "pb_token"

        /** מסמן כוונה כ"נוצרה ע"י האפליקציה" */
        fun sign(i: Intent): Intent = i.putExtra(EXTRA_TOKEN, Prefs.intentToken)
        fun trusted(i: Intent?) = i?.getStringExtra(EXTRA_TOKEN) == Prefs.intentToken
        const val EXTRA_OPEN_SMS = "open_sms"
        const val EXTRA_ASSISTANT_VOICE = "assistant_voice"
        const val EXTRA_OPEN_CALLS = "open_calls"
        const val EXTRA_CALL_NOW = "call_now"
        /** מהווידג'ט: לפתוח את העוזרת ולהתחיל להקשיב (לא מצב נהיגה) */
        const val EXTRA_ASSISTANT_TALK = "assistant_talk"
    }
}
