package com.phonebook.app.call

import com.phonebook.app.ui.tr
import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.phonebook.app.App
import com.phonebook.app.MainActivity
import com.phonebook.app.R
import com.phonebook.app.data.CallerId

/**
 * כשהאפליקציה היא אפליקציית הטלפון, המערכת מבקשת ממנה להציג את ההתראה על שיחות שלא נענו.
 */
class MissedCallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelecomManager.ACTION_SHOW_MISSED_CALLS_NOTIFICATION) return
        val count = intent.getIntExtra(TelecomManager.EXTRA_NOTIFICATION_COUNT, 0)
        val claimed = intent.getStringExtra(TelecomManager.EXTRA_NOTIFICATION_PHONE_NUMBER) ?: ""
        if (count <= 0) { MissedCalls.cancel(context); return }
        // אבטחה: אפליקציה אחרת יכולה לשלוח "שיחה שלא נענתה" מזויפת עם מספר משלה (למשל 1900…),
        // כדי שנלחץ "חזור". לכן מציגים מספר רק אם הוא באמת ביומן השיחות כשיחה שלא נענתה מהיום האחרון
        val pending = goAsync()
        Thread {
            try {
                val tail = com.phonebook.app.data.Phone.tail(claimed)
                val since = System.currentTimeMillis() - 24 * 3600_000L
                fun inLog() = tail.isNotEmpty() && runCatching {
                    com.phonebook.app.data.LogRepo.load(context, 1).any { it.date > since && com.phonebook.app.data.Phone.tail(it.number) == tail }
                }.getOrDefault(false)
                // היומן לפעמים נכתב רגע אחרי ההודעה – בודקים שוב אחרי שנייה וחצי
                val real = inLog() || (tail.isNotEmpty() && run { Thread.sleep(1500); inLog() })
                val premium = claimed.filter { it.isDigit() }.removePrefix("972").trimStart('0').startsWith("19")
                MissedCalls.show(context, count, if (real && !premium) claimed else "")
            } finally { pending.finish() }
        }.start()
    }
}

object MissedCalls {
    private const val ID = 3001

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, count: Int, number: String) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val name = if (number.isNotBlank()) CallerId.lookup(ctx, number)?.name ?: number else ""
        val open = PendingIntent.getActivity(
            ctx, 31, Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_CALLS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(ctx, App.CH_MISSED)
            .setSmallIcon(R.drawable.ic_stat_phone)
            .setContentTitle(if (count == 1) tr("שיחה שלא נענתה") else tr("{0} שיחות שלא נענו", count))
            .setContentText(if (name.isNotBlank()) name else tr("לחץ כדי לראות ביומן"))
            .setCategory(NotificationCompat.CATEGORY_MISSED_CALL)
            .setContentIntent(open)
            .setAutoCancel(true)
        if (number.isNotBlank()) {
            b.addAction(
                0, tr("התקשר חזרה"),
                PendingIntent.getActivity(
                    ctx, 32,
                    Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)).setClass(ctx, MainActivity::class.java)
                        .putExtra(MainActivity.EXTRA_CALL_NOW, true).also { MainActivity.sign(it) }
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            b.addAction(0, tr("⏰ בעוד שעה"), com.phonebook.app.drive.Reminders.broadcast(ctx, com.phonebook.app.drive.Reminders.ACTION_LATER, number, 60, ID))
            b.addAction(
                0, tr("הודעה"),
                PendingIntent.getActivity(
                    ctx, 33,
                    Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_SMS, number)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        try {
            NotificationManagerCompat.from(ctx).notify(ID, b.build())
        } catch (_: Exception) {
        }
    }

    /** נקרא כשהמשתמש פותח את יומן השיחות */
    fun cancel(ctx: Context) {
        NotificationManagerCompat.from(ctx).cancel(ID)
        try {
            ctx.getSystemService(TelecomManager::class.java).cancelMissedCallsNotification()
        } catch (_: Exception) {
        }
    }
}
