package com.phonebook.app.data

import android.content.Context
import android.provider.CallLog
import android.provider.Telephony

enum class LogKind { IN, OUT, MISSED, REJECTED, SMS_IN, SMS_OUT }

data class LogItem(
    val number: String,
    val name: String?,
    val date: Long,
    val kind: LogKind,
    val duration: Long,
    val snippet: String?,
    val id: Long = 0,
    val sim: String? = null,
)

/** יומן שיחות בלבד (ההודעות נמצאות בלשונית הודעות).
 *  filter: 0 = הכל, 1 = שלא נענו, 2 = נכנסות, 3 = יוצאות */
object LogRepo {
    fun load(ctx: Context, filter: Int): List<LogItem> {
        val out = calls(ctx).filter {
            when (filter) {
                1 -> it.kind == LogKind.MISSED || it.kind == LogKind.REJECTED
                2 -> it.kind == LogKind.IN
                3 -> it.kind == LogKind.OUT
                else -> true
            }
        }.sortedByDescending { it.date }
        val names = HashMap<String, String?>()
        return out.take(500).map { item ->
            if (item.name != null || item.number.isBlank()) item
            else item.copy(name = names.getOrPut(item.number) { CallerId.lookup(ctx, item.number)?.name })
        }
    }

    private fun calls(ctx: Context): List<LogItem> = try {
        val sims = com.phonebook.app.call.Sims.labels(ctx)
        val uri = CallLog.Calls.CONTENT_URI.buildUpon()
            .appendQueryParameter(CallLog.Calls.LIMIT_PARAM_KEY, "400").build()
        ctx.contentResolver.query(
            uri,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls._ID, CallLog.Calls.PHONE_ACCOUNT_ID),
            null, null, "${CallLog.Calls.DATE} DESC"
        )?.use { c ->
            buildList {
                while (c.moveToNext()) {
                    val kind = when (c.getInt(2)) {
                        CallLog.Calls.OUTGOING_TYPE -> LogKind.OUT
                        CallLog.Calls.MISSED_TYPE -> LogKind.MISSED
                        CallLog.Calls.REJECTED_TYPE, CallLog.Calls.BLOCKED_TYPE -> LogKind.REJECTED
                        else -> LogKind.IN
                    }
                    add(LogItem(c.getString(0) ?: "", c.getString(1)?.takeIf { it.isNotBlank() }, c.getLong(3), kind, c.getLong(4), null, c.getLong(5), sims[c.getString(6) ?: ""]))
                }
            }
        } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }

    private fun sms(ctx: Context): List<LogItem> = try {
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
            null, null, "${Telephony.Sms.DATE} DESC"
        )?.use { c ->
            buildList {
                while (c.moveToNext() && size < 300) {
                    val sent = c.getInt(3) != Telephony.Sms.MESSAGE_TYPE_INBOX
                    add(LogItem(c.getString(0) ?: "", null, c.getLong(2), if (sent) LogKind.SMS_OUT else LogKind.SMS_IN, 0, c.getString(1)))
                }
            }
        } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }
}
