-- ספר טלפונים – הקמת בסיס הנתונים של הספר הכללי ב-Supabase
-- מריצים פעם אחת: Supabase → SQL Editor → מדביקים את כל הקובץ → Run

create table if not exists public.contacts (
  id          uuid primary key default gen_random_uuid(),
  owner       uuid default auth.uid() references auth.users(id) on delete set null,
  name        text not null,
  phone       text not null default '',
  phone2      text not null default '',
  city        text not null default '',
  address     text not null default '',
  father      text not null default '',
  chem        text not null default '',
  shtibel     text not null default '',
  email       text not null default '',   -- נשמר אבל לעולם לא מתפרסם
  deleted     boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- שדות נוספים שהמשתמש מגדיר בעצמו (רשימת "שם שדה – ערך")
alter table public.contacts add column if not exists extra text not null default '';

create index if not exists contacts_updated_idx on public.contacts (updated_at, id);

-- עדכון אוטומטי של זמן השינוי (לסנכרון)
create or replace function public.contacts_touch() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  -- אי אפשר להעביר בעלות (מותר רק לרוקן אותה כשחשבון נמחק)
  if new.owner is not null then new.owner = old.owner; end if;
  return new;
end $$;

drop trigger if exists contacts_touch on public.contacts;
create trigger contacts_touch before update on public.contacts
  for each row execute function public.contacts_touch();

-- הרשאות: כל משתמש רואה ומשנה ישירות רק את הרשומות שהוא הוסיף
alter table public.contacts enable row level security;

drop policy if exists "read own"   on public.contacts;
drop policy if exists "insert own" on public.contacts;
drop policy if exists "update own" on public.contacts;

create policy "read own"   on public.contacts for select using (owner = auth.uid());
create policy "insert own" on public.contacts for insert with check (owner = auth.uid());
create policy "update own" on public.contacts for update using (owner = auth.uid()) with check (owner = auth.uid());
-- אין הרשאת DELETE: מחיקה = סימון deleted, כדי שכל הטלפונים יידעו להסיר את הרשומה

-- תצוגה ציבורית לכל המשתמשים המחוברים – בלי עמודת האימייל
drop view if exists public.contacts_public;
create view public.contacts_public as
  select id, owner, name, phone, phone2, city, address, father, chem, shtibel, deleted, updated_at, extra
  from public.contacts;

revoke all on public.contacts_public from anon, public;
grant select on public.contacts_public to authenticated;
revoke all on public.contacts from anon;

-- מחיקת חשבון: הרשומות של המשתמש מסומנות כמחוקות ומרוקנות (כדי שכל הטלפונים יסירו אותן), ואז החשבון נמחק
create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  update public.contacts
     set deleted = true, name = '', phone = '', phone2 = '', city = '', address = '',
         father = '', chem = '', shtibel = '', email = ''
   where owner = auth.uid();
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- דיווחים על תשובות של העוזרת (נדרש במדיניות התוכן של Google Play)
create table if not exists public.ai_reports (
  id          bigserial primary key,
  reporter    uuid default auth.uid() references auth.users(id) on delete set null,
  question    text not null default '',
  answer      text not null default '',
  created_at  timestamptz not null default now()
);
alter table public.ai_reports enable row level security;
drop policy if exists "insert reports" on public.ai_reports;
create policy "insert reports" on public.ai_reports for insert to authenticated with check (true);

-- =====================================================================
-- ניהול הספר הכללי: מנהלים, אישור משתמשים, אישור רשומות חדשות, דיווחים
-- (בטוח להריץ שוב את כל הקובץ – לא מוחק נתונים)
-- =====================================================================

create table if not exists public.app_users (
  id          uuid primary key references auth.users(id) on delete cascade,
  email       text not null default '',
  approved    boolean not null default true,
  is_admin    boolean not null default false,
  created_at  timestamptz not null default now()
);

-- כל משתמש חדש נרשם כאן. המשתמש הראשון שנרשם הופך למנהל.
create or replace function public.on_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.app_users (id, email, is_admin)
  values (new.id, coalesce(new.email, ''), not exists (select 1 from public.app_users where is_admin))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_new_user on auth.users;
create trigger on_new_user after insert on auth.users for each row execute function public.on_new_user();

-- משתמשים שכבר קיימים
insert into public.app_users (id, email, created_at)
  select id, coalesce(email, ''), created_at from auth.users
  on conflict (id) do nothing;
update public.app_users set is_admin = true
 where id = (select id from public.app_users order by created_at limit 1)
   and not exists (select 1 from public.app_users where is_admin);

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_admin from public.app_users where id = auth.uid()), false)
$$;
create or replace function public.is_approved() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select approved from public.app_users where id = auth.uid()), true)
$$;
create or replace function public.my_status() returns json
language sql stable security definer set search_path = public as $$
  select json_build_object('is_admin', public.is_admin(), 'approved', public.is_approved())
$$;
grant execute on function public.is_admin(), public.is_approved(), public.my_status() to authenticated;

alter table public.app_users enable row level security;
drop policy if exists "users read"   on public.app_users;
drop policy if exists "users admin"  on public.app_users;
create policy "users read"  on public.app_users for select using (id = auth.uid() or public.is_admin());
create policy "users admin" on public.app_users for update using (public.is_admin()) with check (public.is_admin());

-- רשומות חדשות של משתמש רגיל ממתינות לאישור מנהל (הרשומות הקיימות נשארות מאושרות)
alter table public.contacts add column if not exists approved boolean not null default true;

create or replace function public.contacts_new() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.approved = public.is_admin();
  return new;
end $$;
drop trigger if exists contacts_new on public.contacts;
create trigger contacts_new before insert on public.contacts for each row execute function public.contacts_new();

create or replace function public.contacts_touch() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  if new.owner is not null then new.owner = old.owner; end if;
  -- רק מנהל יכול לאשר רשומה
  if not public.is_admin() then new.approved = old.approved; end if;
  return new;
end $$;

drop policy if exists "insert own"  on public.contacts;
create policy "insert own" on public.contacts for insert with check (owner = auth.uid() and public.is_approved());
drop policy if exists "admin read"   on public.contacts;
drop policy if exists "admin update" on public.contacts;
create policy "admin read"   on public.contacts for select using (public.is_admin());
create policy "admin update" on public.contacts for update using (public.is_admin()) with check (public.is_admin());

-- התצוגה הכללית: רק רשומות מאושרות (או שלי), ורק למשתמש שלא נחסם
create or replace view public.contacts_public as
  select id, owner, name, phone, phone2, city, address, father, chem, shtibel, deleted, updated_at, extra
  from public.contacts
  where public.is_approved() and (approved or owner = auth.uid() or public.is_admin());
revoke all on public.contacts_public from anon, public;
grant select on public.contacts_public to authenticated;

-- דיווחים על רשומות שגויות
create table if not exists public.reports (
  id          bigserial primary key,
  contact_id  uuid references public.contacts(id) on delete cascade,
  reporter    uuid default auth.uid() references auth.users(id) on delete set null,
  reason      text not null default '',
  handled     boolean not null default false,
  created_at  timestamptz not null default now()
);
alter table public.reports enable row level security;
drop policy if exists "reports insert" on public.reports;
drop policy if exists "reports admin"  on public.reports;
create policy "reports insert" on public.reports for insert to authenticated with check (reporter = auth.uid());
create policy "reports admin"  on public.reports for all using (public.is_admin()) with check (public.is_admin());

-- =====================================================================
-- משוב מהמשתמשים + הגדרות כלליות (למשל כתובת המייל שאליה נשלח המשוב)
-- =====================================================================
create table if not exists public.app_config (
  key    text primary key,
  value  text not null default ''
);
alter table public.app_config enable row level security;
drop policy if exists "config read"  on public.app_config;
drop policy if exists "config admin" on public.app_config;
create policy "config read"  on public.app_config for select to authenticated using (true);
create policy "config admin" on public.app_config for all using (public.is_admin()) with check (public.is_admin());

create table if not exists public.feedback (
  id          bigserial primary key,
  sender      uuid default auth.uid() references auth.users(id) on delete set null,
  email       text not null default '',
  message     text not null default '',
  created_at  timestamptz not null default now()
);
alter table public.feedback enable row level security;
drop policy if exists "feedback insert" on public.feedback;
drop policy if exists "feedback admin"  on public.feedback;
create policy "feedback insert" on public.feedback for insert to authenticated with check (sender = auth.uid());
create policy "feedback admin"  on public.feedback for all using (public.is_admin()) with check (public.is_admin());

-- =====================================================================
-- חיבור למחשב: המחשב שולח "חייג" / "שלח SMS", והטלפון של אותו משתמש מבצע
-- =====================================================================
create table if not exists public.pc_commands (
  id          bigserial primary key,
  owner       uuid not null default auth.uid() references auth.users(id) on delete cascade,
  kind        text not null default 'call',
  number      text not null default '',
  body        text not null default '',
  done        boolean not null default false,
  created_at  timestamptz not null default now()
);
create index if not exists pc_commands_owner_idx on public.pc_commands (owner, done, created_at);
alter table public.pc_commands enable row level security;
drop policy if exists "pc own" on public.pc_commands;
create policy "pc own" on public.pc_commands for all using (owner = auth.uid()) with check (owner = auth.uid());

-- מתי הטלפון היה מחובר לאחרונה (כדי שהמחשב יראה "הטלפון מחובר")
create table if not exists public.pc_link (
  owner    uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  seen_at  timestamptz not null default now()
);
alter table public.pc_link enable row level security;
drop policy if exists "pc link own" on public.pc_link;
create policy "pc link own" on public.pc_link for all using (owner = auth.uid()) with check (owner = auth.uid());

-- =====================================================================
-- גיבוי פרטי של הספר האישי (רק המשתמש עצמו רואה – לא חלק מהספר הכללי)
-- =====================================================================
create table if not exists public.personal_backup (
  owner       uuid primary key default auth.uid() references auth.users(id) on delete cascade,
  data        text not null default '',
  count       int not null default 0,
  updated_at  timestamptz not null default now()
);
alter table public.personal_backup enable row level security;
drop policy if exists "backup own" on public.personal_backup;
create policy "backup own" on public.personal_backup for all using (owner = auth.uid()) with check (owner = auth.uid());

-- =====================================================================
-- דיווחי ספאם משותפים: כל משתמש מדווח על מספר פעם אחת; האפליקציה מקבלת רק את המספר הכולל
-- (מי דיווח – לא נחשף לאף אחד)
-- =====================================================================
create table if not exists public.spam_reports (
  tail        text not null,
  reporter    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (tail, reporter)
);
alter table public.spam_reports enable row level security;
drop policy if exists "spam report own" on public.spam_reports;
create policy "spam report own" on public.spam_reports for all using (reporter = auth.uid()) with check (reporter = auth.uid());

create or replace function public.spam_count(t text) returns int
language sql stable security definer set search_path = public as $$
  select count(*)::int from public.spam_reports where tail = t;
$$;
revoke all on function public.spam_count(text) from public;
grant execute on function public.spam_count(text) to authenticated;
