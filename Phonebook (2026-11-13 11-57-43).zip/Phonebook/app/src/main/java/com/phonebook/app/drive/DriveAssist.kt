package com.phonebook.app.drive

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import com.phonebook.app.call.CallManager
import com.phonebook.app.data.CallerId
import com.phonebook.app.data.Prefs
import com.phonebook.app.data.Spam
import com.phonebook.app.net.SpamCloud
import com.phonebook.app.pc.DrivingBubbleService
import com.phonebook.app.sms.SmsSender
import com.phonebook.app.ui.AssistantBus
import com.phonebook.app.ui.VoiceInput
import com.phonebook.app.ui.isCancel
import com.phonebook.app.ui.tr

/**
 * עוזר נהיגה – בלי לגעת בטלפון:
 *  • שיחה נכנסת: מקריא מי מתקשר (ואזהרת ספאם), ומקשיב ל"ענה" / "דחה".
 *  • SMS נכנס: מקריא את ההודעה, מאפשר להכתיב תשובה, ומאשר לפני שליחה.
 *  • מי שהתקשר ולא נענה בזמן נהיגה – מקבל SMS "אני נוהג" (פעם בחצי שעה לכל מספר).
 * "נהיגה" = הכפתור הצף פעיל, או שהעוזרת פתוחה במצב נהיגה.
 */
object DriveAssist {
    private val main = Handler(Looper.getMainLooper())
    private var voice: VoiceInput? = null
    /** מזהה הפעולה הנוכחית – פעולה ישנה שהתבטלה לא ממשיכה */
    private var session = 0
    private var mode = 0          // 0 = כלום, 1 = שיחה נכנסת, 2 = הודעה
    private val replied = HashMap<String, Long>()

    fun driving() = DrivingBubbleService.running() || AssistantBus.driving.value

    private fun v(ctx: Context) = voice ?: VoiceInput(ctx.applicationContext).also { voice = it }

    private fun micOk(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun ringing() = CallManager.call.value?.state == Call.STATE_RINGING

    private fun words(t: String) = t.lowercase().replace(Regex("[\\p{P}\\p{S}]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun has(t: String, list: List<String>): Boolean {
        val s = words(t)
        return list.any { s == it || s.startsWith("$it ") || s.endsWith(" $it") || s.contains(" $it ") }
    }

    private val YES = listOf("כן", "ענה", "תענה", "לענות", "עני", "תעני", "שלח", "תשלח", "לשלוח", "בטח", "yes", "answer", "accept", "send", "ok", "אוקיי")
    private val NO = listOf("לא", "דחה", "תדחה", "לדחות", "דחי", "תדחי", "no", "reject", "decline")

    private fun isYes(t: String) = has(t, YES) && !has(t, listOf("לא"))
    private fun isNo(t: String) = has(t, NO) || isCancel(t)

    /** סוגר כל הקשבה / הקראה פתוחה */
    private fun end(ctx: Context) {
        mode = 0
        session++
        voice?.stop(send = false)
        voice?.releaseFocus()
    }

    /** מקשיב למילה אחת-שתיים (כן / לא / ענה / דחה). null = לא נאמר כלום */
    private fun command(ctx: Context, seconds: Int, cb: (String?) -> Unit) {
        val vi = v(ctx)
        var done = false
        val timeout = Runnable { if (!done) { done = true; vi.stop(send = false); cb(null) } }
        main.postDelayed(timeout, seconds * 1000L + 1500)
        vi.start(1) { said -> if (!done) { done = true; main.removeCallbacks(timeout); cb(said) } }
    }

    // ---------------------------------------------------------------- שיחה נכנסת

    fun onIncoming(ctx: Context, number: String) {
        val drv = driving()
        val announce = Prefs.announceCaller == 2 || (Prefs.announceCaller == 1 && drv)
        val byVoice = drv && Prefs.voiceAnswer && micOk(ctx)
        if (!announce && !byVoice) return
        val my = ++session
        mode = 1
        val app = ctx.applicationContext
        Thread {
            val known = runCatching { CallerId.lookup(app, number) }.getOrNull()
            val spam = if (known == null && number.isNotBlank()) SpamCloud.countBlocking(number) else 0
            main.post {
                if (my != session || !ringing()) return@post
                val who = when {
                    number.isBlank() -> tr("מספר חסוי")
                    known != null -> known.name
                    else -> tr("מספר לא שמור")
                }
                var text = tr("שיחה מ{0}", who)
                if (spam >= SpamCloud.WARN_AT) text += ". " + tr("זהירות – {0} משתמשים דיווחו על המספר הזה כספאם", spam)
                if (byVoice) {
                    // משתיקים את הצלצול כדי לשמוע את התשובה שלך
                    runCatching { app.getSystemService(TelecomManager::class.java).silenceRinger() }
                    v(app).holdFocus()
                    Speaker.speak(app, text + ". " + tr("לענות או לדחות?")) {
                        if (my == session && ringing()) listenAnswer(app, my, 1) else v(app).releaseFocus()
                    }
                } else Speaker.speak(app, text)
            }
        }.start()
    }

    private fun listenAnswer(ctx: Context, my: Int, triesLeft: Int) {
        command(ctx, 7) { said ->
            if (my != session || !ringing()) return@command
            when {
                said != null && isYes(said) -> {
                    end(ctx)
                    CallManager.answer()
                    // בלי דיבורית בלוטות' – עוברים לרמקול, כדי לא להרים את הטלפון לאוזן
                    main.postDelayed({
                        val a = CallManager.audio.value
                        if (a.route == CallAudioState.ROUTE_EARPIECE && (a.supported and CallAudioState.ROUTE_BLUETOOTH) == 0) CallManager.setSpeaker(true)
                    }, 1200)
                }
                said != null && isNo(said) -> { end(ctx); CallManager.hangup(); Speaker.speak(ctx, tr("השיחה נדחתה")) }
                triesLeft > 0 -> Speaker.speak(ctx, tr("לא הבנתי. אמור ענה, או דחה.")) {
                    if (my == session && ringing()) listenAnswer(ctx, my, triesLeft - 1)
                }
                else -> { mode = 0; v(ctx).releaseFocus() }
            }
        }
    }

    /** נקרא כשמצב השיחה משתנה – אם כבר ענו/דחו ביד, מפסיקים להקשיב */
    fun callChanged(ctx: Context) {
        if (mode == 1 && !ringing()) { end(ctx); Speaker.stop() }
    }

    /** שיחה הסתיימה */
    fun onCallEnded(ctx: Context, number: String, incoming: Boolean, answered: Boolean, seconds: Long) {
        val app = ctx.applicationContext
        if (mode == 1) end(app)
        if (incoming && !answered && driving() && Prefs.driveAutoReply) autoReply(app, number)
        if (answered && seconds >= 20 && Prefs.noteAfterCall && !driving() && number.isNotBlank()) Reminders.askNote(app, number)
    }

    private fun autoReply(ctx: Context, number: String) {
        val digits = number.filter { it.isDigit() }
        if (digits.length < 9) return
        val now = System.currentTimeMillis()
        synchronized(replied) {
            if (now - (replied[digits] ?: 0L) < 30 * 60_000L) return
            replied[digits] = now
        }
        Thread {
            if (SpamCloud.countBlocking(number) >= SpamCloud.WARN_AT) return@Thread
            val text = Prefs.driveReplyText.ifBlank { tr("אני נוהג כרגע ולא יכול לענות. אחזור אליך בהקדם 🚗") }
            runCatching { SmsSender.send(ctx, number, text) }
        }.start()
    }

    // ---------------------------------------------------------------- SMS נכנס

    fun onSms(ctx: Context, address: String, body: String) {
        if (!driving() || !Prefs.driveReadSms) return
        if (CallManager.call.value != null || mode != 0) return
        val app = ctx.applicationContext
        Thread {
            val known = runCatching { CallerId.lookup(app, address) }.getOrNull()
            if (Spam.check(address, body, known != null) != Spam.Kind.NONE) return@Thread
            main.post {
                if (mode != 0 || CallManager.call.value != null) return@post
                val my = ++session
                mode = 2
                val who = known?.name ?: address.filter { it.isDigit() }.chunked(3).joinToString(" ").ifBlank { address }
                val canReply = micOk(app) && address.count { it.isDigit() } >= 9
                v(app).holdFocus()
                val text = tr("הודעה מ{0}: {1}", who, body.take(400)) +
                    if (canReply) ". " + tr("לענות? אמור את התשובה, או ביטול.") else ""
                Speaker.speak(app, text) {
                    if (my != session) return@speak
                    if (canReply) dictate(app, my, address, who) else end(app)
                }
            }
        }.start()
    }

    private fun dictate(ctx: Context, my: Int, address: String, who: String) {
        val vi = v(ctx)
        var done = false
        val timeout = Runnable { if (!done && my == session) { done = true; end(ctx) } }
        main.postDelayed(timeout, 16_000)
        vi.start(3) { said ->
            if (done || my != session) return@start
            done = true; main.removeCallbacks(timeout)
            val t = said.trim()
            if (t.isEmpty() || isCancel(t) || words(t) == "לא") { Speaker.speak(ctx, tr("בסדר")) { end(ctx) }; return@start }
            vi.holdFocus()
            Speaker.speak(ctx, tr("לשלוח ל{0}: {1}? אמור כן או לא.", who, t)) {
                if (my != session) return@speak
                command(ctx, 6) { ans ->
                    if (my != session) return@command
                    if (ans != null && isYes(ans)) {
                        runCatching { SmsSender.send(ctx, address, t) }
                        Speaker.speak(ctx, tr("נשלח")) { end(ctx) }
                    } else Speaker.speak(ctx, tr("לא נשלח")) { end(ctx) }
                }
            }
        }
    }
}
