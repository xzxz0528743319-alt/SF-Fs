package com.phonebook.app.call

import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.PhoneAccountHandle
import android.telecom.VideoProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CallInfo(val number: String, val state: Int, val connectTime: Long, val id: Int = 0, val canMerge: Boolean = false)
data class AudioInfo(val muted: Boolean = false, val route: Int = CallAudioState.ROUTE_EARPIECE, val supported: Int = CallAudioState.ROUTE_EARPIECE or CallAudioState.ROUTE_SPEAKER)

/** מחזיק את השיחה הנוכחית ומעביר פקודות (מענה, ניתוק, השתקה...) למערכת */
@Suppress("DEPRECATION")
object CallManager {
    private val _call = MutableStateFlow<CallInfo?>(null)
    val call: StateFlow<CallInfo?> = _call.asStateFlow()
    /** שיחות נוספות (ממתינה / בהמתנה) מלבד השיחה המוצגת */
    private val _others = MutableStateFlow<List<CallInfo>>(emptyList())
    val others: StateFlow<List<CallInfo>> = _others.asStateFlow()

    private val _audio = MutableStateFlow(AudioInfo())
    val audio: StateFlow<AudioInfo> = _audio.asStateFlow()

    var service: InCallService? = null
    var onChange: (() -> Unit)? = null

    private val calls = mutableListOf<Call>()
    /** שיחות נכנסות, ואלה מהן שנענו – כדי לדעת מה "לא נענה" (לתשובה אוטומטית בנהיגה / הערה אחרי שיחה) */
    private val incoming = HashSet<Call>()
    private val answered = HashSet<Call>()
    private var current: Call? = null

    private val callback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            if (state == Call.STATE_ACTIVE) answered += call
            publish()
            service?.let { com.phonebook.app.drive.DriveAssist.callChanged(it) }
        }
        override fun onDetailsChanged(call: Call, details: Call.Details) = publish()
    }

    fun added(call: Call) {
        calls += call
        call.registerCallback(callback)
        current = call
        val ringing = call.state == Call.STATE_RINGING
        if (ringing) incoming += call
        publish()
        if (ringing) service?.let { com.phonebook.app.drive.DriveAssist.onIncoming(it, call.details.handle?.schemeSpecificPart ?: "") }
    }

    fun removed(call: Call) {
        call.unregisterCallback(callback)
        val wasIncoming = incoming.remove(call)
        val wasAnswered = answered.remove(call) || call.details.connectTimeMillis > 0
        val secs = if (call.details.connectTimeMillis > 0) (System.currentTimeMillis() - call.details.connectTimeMillis) / 1000 else 0L
        service?.let {
            runCatching {
                com.phonebook.app.drive.DriveAssist.onCallEnded(it, call.details.handle?.schemeSpecificPart ?: "", wasIncoming, wasAnswered, secs)
            }
        }
        calls -= call
        if (current == call) current = calls.lastOrNull()
        publish()
        // השיחה מהנהיגה הסתיימה – חוזרים ל-Waze (ולא לאפליקציה)
        if (calls.isEmpty() && com.phonebook.app.ui.AssistantBus.backAfterCall) {
            com.phonebook.app.ui.AssistantBus.callEndedAt = System.currentTimeMillis()
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                com.phonebook.app.ui.AssistantBus.backAfterCall = false
                com.phonebook.app.MainActivity.top?.let { it.moveTaskToBack(true); com.phonebook.app.ui.AssistantBus.callEndedAt = 0L }
            }, 700)
        }
    }

    private fun info(it: Call) = CallInfo(
        number = it.details.handle?.schemeSpecificPart ?: "",
        state = it.state,
        connectTime = it.details.connectTimeMillis,
        id = System.identityHashCode(it),
        canMerge = it.details.can(Call.Details.CAPABILITY_MERGE_CONFERENCE) || it.conferenceableCalls.isNotEmpty(),
    )

    private fun publish() {
        val c = current
        if (c == null) CallRecorder.stop()
        else if (c.state == Call.STATE_ACTIVE && com.phonebook.app.data.Prefs.autoRecord && !CallRecorder.recording.value) {
            service?.let { svc -> CallRecorder.start(svc, c.details.handle?.schemeSpecificPart ?: "") }
        }
        _call.value = current?.let { info(it) }
        _others.value = calls.filter { it != current && it.state != Call.STATE_DISCONNECTED }.map { info(it) }
        onChange?.invoke()
    }

    /** מענה. אם יש שיחה פעילה – היא עוברת להמתנה */
    fun answer() {
        val ringing = current?.takeIf { it.state == Call.STATE_RINGING } ?: calls.firstOrNull { it.state == Call.STATE_RINGING } ?: return
        calls.filter { it != ringing && it.state == Call.STATE_ACTIVE }.forEach { it.hold() }
        ringing.answer(VideoProfile.STATE_AUDIO_ONLY)
        current = ringing
        publish()
    }

    /** מעבר בין שתי שיחות: הפעילה להמתנה, וזו שבהמתנה לפעילה */
    fun swap() {
        val other = calls.firstOrNull { it != current && it.state == Call.STATE_HOLDING } ?: return
        current?.takeIf { it.state == Call.STATE_ACTIVE }?.hold()
        other.unhold()
        current = other
        publish()
    }

    /** איחוד לשיחת ועידה */
    fun merge() {
        val c = current ?: return
        val other = calls.firstOrNull { it != c } ?: return
        try {
            if (c.conferenceableCalls.contains(other)) c.conference(other) else c.mergeConference()
        } catch (_: Exception) {
        }
    }

    /** ניתוק שיחה ממתינה / בהמתנה לפי מזהה */
    fun hangupOther(id: Int) {
        calls.firstOrNull { System.identityHashCode(it) == id }?.let {
            if (it.state == Call.STATE_RINGING) it.reject(false, null) else it.disconnect()
        }
    }

    fun hangup() {
        val c = current ?: return
        if (c.state == Call.STATE_RINGING) c.reject(false, null) else c.disconnect()
    }

    fun toggleHold() {
        val c = current ?: return
        if (c.state == Call.STATE_HOLDING) c.unhold() else c.hold()
    }

    fun setMuted(muted: Boolean) {
        service?.setMuted(muted)
    }

    fun setRoute(route: Int) {
        service?.setAudioRoute(route)
    }

    fun setSpeaker(on: Boolean) {
        service?.setAudioRoute(if (on) CallAudioState.ROUTE_SPEAKER else CallAudioState.ROUTE_WIRED_OR_EARPIECE)
    }

    fun dtmf(c: Char) {
        current?.let {
            it.playDtmfTone(c)
            it.stopDtmfTone()
        }
    }

    fun selectAccount(handle: PhoneAccountHandle) {
        current?.phoneAccountSelected(handle, false)
    }

    fun audioChanged(state: CallAudioState) {
        _audio.value = AudioInfo(state.isMuted, state.route, state.supportedRouteMask)
    }
}
