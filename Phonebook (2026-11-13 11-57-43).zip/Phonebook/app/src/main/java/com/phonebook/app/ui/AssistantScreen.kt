@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import android.content.Intent
import android.net.Uri
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.Assistant
import com.phonebook.app.net.Server
import kotlinx.coroutines.launch

private val SUGGESTIONS get() = listOf(
    tr("מצא את משפחת כהן מבני ברק"),
    tr("תתקשר ללוי מירושלים"),
    tr("נסח הודעת מזל טוב לחתונה ושלח בוואטסאפ"),
    tr("נסח הודעה קצרה שאני מאחר"),
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AssistantScreen(onSettings: () -> Unit, onSms: (String, String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val history = remember { mutableStateListOf<Assistant.Msg>() }
    var input by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    var reportIndex by remember { mutableStateOf<Int?>(null) }
    var autoCall by remember { mutableStateOf<Assistant.Action?>(null) }
    var countdown by remember { mutableIntStateOf(3) }

    // הקראה בקול
    val tts = remember { mutableStateOf<android.speech.tts.TextToSpeech?>(null) }
    DisposableEffect(Unit) {
        var engine: android.speech.tts.TextToSpeech? = null
        engine = android.speech.tts.TextToSpeech(ctx) { st ->
            if (st == android.speech.tts.TextToSpeech.SUCCESS) {
                engine?.language = I18n.locale()
                tts.value = engine
            }
        }
        onDispose { engine?.stop(); engine?.shutdown() }
    }
    val voice = remember { VoiceInput(ctx) }
    DisposableEffect(Unit) { onDispose { voice.stop(send = false); voice.releaseFocus() } }
    val vListening by voice.listening.collectAsState()
    val vText by voice.text.collectAsState()
    val driving by AssistantBus.driving.collectAsState()
    DisposableEffect(Unit) { onDispose { AssistantBus.driving.value = false } }

    val mainHandler = remember { android.os.Handler(android.os.Looper.getMainLooper()) }
    fun speak(t: String, after: (() -> Unit)? = null) {
        val clean = t.replace(Regex("[*_#`>]"), "").take(600)
        val engine = tts.value
        if (clean.isBlank() || engine == null) { voice.releaseFocus(); after?.invoke(); return }
        voice.holdFocus()   // המוזיקה נשארת מושתקת עד שהעוזרת מסיימת לדבר
        engine.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { voice.releaseFocus(); after?.let { mainHandler.post(it) } }
            @Deprecated("") override fun onError(id: String?) { voice.releaseFocus(); after?.let { mainHandler.post(it) } }
        })
        engine.speak(clean, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "ai")
    }
    var quick by remember { mutableStateOf(Prefs.aiQuick) }

    fun send(q: String, spoken: Boolean = false) {
        val text = q.trim()
        if (text.isEmpty() || busy) return
        history += Assistant.Msg(true, text)
        input = ""
        scope.launch {
            busy = true
            val reply = runCatching { Assistant.ask(history.toList()) }.getOrElse { Assistant.Msg(false, tr("שגיאה: {0}", it.message)) }
            history += reply
            busy = false
            val calls = reply.actions.filter { it.kind == "call" }
            if (Prefs.aiAutoCall && calls.size == 1 && reply.actions.size == 1) autoCall = calls[0]   // ההקראה של "מתקשר ל…" תגיע מהספירה
            else if (spoken && Prefs.aiSpeak) speak(reply.text) else voice.releaseFocus()
        }
    }
    var personal by remember { mutableStateOf(Prefs.aiPersonal) }
    var autoDial by remember { mutableStateOf(Prefs.aiAutoCall) }
    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!said.isNullOrBlank()) send(said, spoken = true)
    }
    // חזרה לאפליקציה שהייתה לפני (Waze / Google Maps) – במצב נהיגה
    fun backToDriving() { if (driving) com.phonebook.app.MainActivity.top?.moveTaskToBack(true) }
    /** חיוג בנהיגה: אחרי הניתוק חוזרים אוטומטית ל-Waze */
    fun markReturn() { if (driving) { AssistantBus.backAfterCall = true; AssistantBus.callEndedAt = 0L } }
    fun onHeard(said: String) {
        if (isCancel(said)) {
            voice.releaseFocus()
            toast(ctx, tr("בוטל"))
            backToDriving()
        } else send(said, spoken = true)
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) voice.start(if (driving) 5 else 3) { said -> onHeard(said) }
        else toast(ctx, tr("צריך לאשר את המיקרופון כדי לדבר עם העוזרת"))
    }
    fun listen() {
        if (voice.available()) {
            tts.value?.stop()
            if (androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.RECORD_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) voice.start(if (driving) 5 else 3) { said -> onHeard(said) }
            else micPerm.launch(android.Manifest.permission.RECORD_AUDIO)
            return
        }
        try {
            speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (I18n.code.value == "he") "he-IL" else I18n.locale().toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PROMPT, tr("דבר עם העוזרת"))
            })
        } catch (_: Exception) {
            toast(ctx, tr("זיהוי דיבור לא זמין בטלפון"))
        }
    }
    fun doAction(a: Assistant.Action) {
        when (a.kind) {
            "call" -> Actions.call(ctx, a.number)
            "sms" -> onSms(a.number, a.text)
            else -> {
                val num = com.phonebook.app.data.Phone.international(a.number)
                val url = "https://wa.me/$num" + if (a.text.isNotBlank()) "?text=" + Uri.encode(a.text) else ""
                try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { toast(ctx, tr("וואטסאפ לא מותקן")) }
            }
        }
    }

    // חיוג אוטומטי: 3 שניות שבהן אפשר לבטל
    LaunchedEffect(autoCall) {
        val a = autoCall ?: return@LaunchedEffect
        val secs = if (driving) 6 else 3
        if (driving) {
            // קודם מקריאים למי מתקשרים, ורק כשההקראה נגמרת מתחילים להקשיב ל"ביטול" ולספור –
            // כך כל 6 השניות פנויות לביטול (קודם ההקראה "אכלה" חלק מהזמן, והמיקרופון שמע את ההקראה עצמה)
            if (Prefs.aiSpeak && tts.value != null) {
                countdown = secs
                val spoken = kotlinx.coroutines.CompletableDeferred<Unit>()
                speak(tr("מתקשר ל{0}. כדי לבטל, אמור ביטול.", a.name)) { spoken.complete(Unit) }
                kotlinx.coroutines.withTimeoutOrNull(8000) { spoken.await() }
                if (autoCall != a) return@LaunchedEffect
            }
            voice.startCancelWatch(secs + 1) {
                if (autoCall == a) { autoCall = null; toast(ctx, tr("החיוג בוטל")); speak(tr("בוטל")); backToDriving() }
            }
        } else if (Prefs.aiSpeak && tts.value != null) speak(tr("מתקשר ל{0}", a.name))
        for (i in secs downTo 1) { countdown = i; kotlinx.coroutines.delay(1000) }
        if (autoCall == a) {
            autoCall = null
            voice.stopCancelWatch()
            tts.value?.stop()
            markReturn()
            doAction(a)
            // (לא delay כאן – ה-autoCall=null מבטל את ה-LaunchedEffect, ולכן החזרה לא קרתה לפעמים)
            if (driving) mainHandler.postDelayed({ backToDriving() }, 900)
        }
    }

    // לחיצה על הכפתור הצף לנהיגה – מתחילים להקשיב מיד
    val voiceReq by AssistantBus.voice.collectAsState()
    LaunchedEffect(voiceReq) { if (voiceReq > AssistantBus.handled) { AssistantBus.handled = voiceReq; AssistantBus.driving.value = true; listen() } }
    val talkReq by AssistantBus.talk.collectAsState()
    LaunchedEffect(talkReq) { if (talkReq > AssistantBus.talkHandled) { AssistantBus.talkHandled = talkReq; AssistantBus.driving.value = false; listen() } }

    LaunchedEffect(history.size, busy) {
        val last = listState.layoutInfo.totalItemsCount - 1
        if (last > 0) listState.animateScrollToItem(last)
    }

    reportIndex?.let { i ->
        AlertDialog(
            onDismissRequest = { reportIndex = null },
            title = { Text(tr("לדווח על התשובה?")) },
            text = { Text(tr("התשובה תוסתר ותישלח לבדיקה, כדי לשפר את העוזרת.")) },
            confirmButton = {
                TextButton(onClick = {
                    reportIndex = null
                    val answer = history.getOrNull(i) ?: return@TextButton
                    val question = history.take(i).lastOrNull { it.user }?.text ?: ""
                    history[i] = Assistant.Msg(false, tr("התשובה דווחה והוסתרה."))
                    scope.launch {
                        runCatching { Server.reportAi(question, answer.text) }
                            .onSuccess { toast(ctx, tr("תודה, הדיווח נשלח")) }
                            .onFailure { toast(ctx, tr("התשובה הוסתרה. כדי לשלוח את הדיווח צריך להתחבר בהגדרות.")) }
                    }
                }) { Text(tr("דווח")) }
            },
            dismissButton = { TextButton(onClick = { reportIndex = null }) { Text(tr("ביטול")) } },
        )
    }

    if (driving) {
        DrivingView(
            autoCall = autoCall, countdown = countdown, listening = vListening, heard = vText, busy = busy,
            last = history.lastOrNull()?.takeIf { !it.user },
            onCancelCall = { autoCall = null; voice.stopCancelWatch(); tts.value?.stop(); backToDriving() },
            onCancelListen = { voice.stop(send = false); backToDriving() },
            onSendNow = { voice.stop(send = true) },
            onAction = { if (it.kind == "call") markReturn(); doAction(it); if (it.kind == "call") mainHandler.postDelayed({ backToDriving() }, 900) },
            onTalk = { listen() },
            onExit = { voice.stop(send = false); tts.value?.stop(); autoCall = null; AssistantBus.driving.value = false },
        )
        return
    }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                AppCard {
                    Column(Modifier.padding(16.dp)) {
                        Text(tr("שלום! אני מחפשת אנשי קשר, מנסחת הודעות ומכינה לך כפתור לחיוג, SMS או וואטסאפ. אפשר גם לדבר איתי 🎤"))
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(personal, { personal = it; Prefs.aiPersonal = it })
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (personal) tr("מחפשת גם בספר האישי שלך") else tr("מחפשת רק בספר הכללי (הספר האישי לא נשלח)"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(autoDial, { autoDial = it; Prefs.aiAutoCall = it })
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (autoDial) tr("מחייגת לבד כשמבקשים להתקשר (אפשר לבטל תוך 3 שניות)") else tr("מציגה כפתור חיוג – אתה לוחץ"),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (history.isNotEmpty()) TextButton(onClick = { history.clear() }) { Text(tr("🗑️ שיחה חדשה")) }
                    }
                }
            }
            if (Prefs.aiKey.isBlank() && !Server.loggedIn()) item {
                InfoCard(tr("כדי להשתמש בעוזרת צריך להתחבר לספר הכללי בהגדרות. לחץ כאן."), Modifier.clickable { onSettings() })
            }
            itemsIndexed(history) { index, m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.Start else Arrangement.End) {
                    Column(horizontalAlignment = if (m.user) Alignment.Start else Alignment.End) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (m.user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLowest,
                            shadowElevation = if (m.user) 0.dp else 1.dp,
                            modifier = Modifier.widthIn(max = 320.dp)
                        ) {
                            SelectionContainer {
                                Text(
                                    m.text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    color = if (m.user) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        if (!m.user) m.actions.forEach { a ->
                            Button(onClick = { doAction(a) }, modifier = Modifier.padding(top = 6.dp)) { Text(a.label) }
                        }
                        if (!m.user) Row {
                            TextButton(onClick = {
                                clipboard.setText(AnnotatedString(m.text)); toast(ctx, tr("הועתק"))
                            }) {
                                Icon(Icons.Filled.ContentCopy, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(tr("העתק"))
                            }
                            TextButton(onClick = { reportIndex = index }) {
                                Icon(Icons.Filled.Flag, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(tr("דווח"))
                            }
                        }
                    }
                }
            }
            if (vListening) item {
                AppCard {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            if (driving) tr("🎤 מקשיב… (שולח אחרי 5 שניות של שקט)") else tr("🎤 מקשיב…"),
                            fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary
                        )
                        if (vText.isNotBlank()) Text(vText, Modifier.padding(top = 6.dp), fontSize = if (driving) 22.sp else 18.sp)
                        if (driving) {
                            Spacer(Modifier.height(10.dp))
                            BigCancel { voice.stop(send = false); backToDriving() }
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { voice.stop(send = true) }, enabled = vText.isNotBlank(),
                                modifier = Modifier.fillMaxWidth().height(56.dp)) { Text(tr("שלח עכשיו"), fontSize = 18.sp) }
                        } else Row {
                            TextButton(onClick = { voice.stop(send = true) }, enabled = vText.isNotBlank()) { Text(tr("שלח עכשיו")) }
                            TextButton(onClick = { voice.stop(send = false) }) { Text(tr("ביטול"), color = CallRed) }
                        }
                    }
                }
            }
            autoCall?.let { a ->
                item {
                    AppCard {
                        if (driving) Column(Modifier.padding(14.dp)) {
                            Text(tr("📞 מחייג ל{0} בעוד {1}…", a.name, countdown), fontWeight = FontWeight.Bold, fontSize = 22.sp)
                            Text(tr("אפשר גם לומר \"ביטול\""), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(10.dp))
                            BigCancel { autoCall = null; voice.stopCancelWatch(); tts.value?.stop(); backToDriving() }
                        } else Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(tr("📞 מחייג ל{0} בעוד {1}…", a.name, countdown), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { autoCall = null; doAction(a) }) { Text(tr("עכשיו")) }
                            TextButton(onClick = { autoCall = null; tts.value?.stop() }) { Text(tr("ביטול"), color = CallRed) }
                        }
                    }
                }
            }
            if (busy) item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                }
            }
        }
        // בקשות שמורות – לחיצה אחת (נוח בנהיגה). לחיצה ארוכה מוחקת
        if (quick.isNotEmpty()) Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quick.forEach { q ->
                Surface(
                    shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.combinedClickable(
                        onClick = { send(q, spoken = false) },
                        onLongClick = { quick = quick - q; Prefs.aiQuick = quick; toast(ctx, tr("הבקשה השמורה נמחקה")) }
                    )
                ) { Text("⭐ $q", Modifier.padding(horizontal = 14.dp, vertical = 9.dp), color = MaterialTheme.colorScheme.onPrimaryContainer) }
            }
        }
        if (history.isEmpty()) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SUGGESTIONS.forEach { s -> SuggestionChip(onClick = { send(s) }, label = { Text(s) }) }
            }
        }
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text(tr("מה לנסח או את מי לחפש?")) },
                maxLines = 4,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            if (input.isNotBlank() && input.trim() !in quick) IconButton(onClick = {
                quick = (quick + input.trim()).takeLast(12); Prefs.aiQuick = quick
                toast(ctx, tr("נשמר – לחיצה אחת על ⭐ שולחת את הבקשה"))
            }) { Text("⭐", fontSize = 22.sp) }
            if (input.isBlank()) FilledTonalIconButton(onClick = { if (vListening) voice.stop(send = true) else { AssistantBus.driving.value = false; listen() } }, enabled = !busy, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.Mic, tr("דבר"))
            } else FilledIconButton(onClick = { send(input) }, enabled = !busy, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.Send, tr("שלח"))
            }
        }
    }
}

/** אותות לעוזרת מבחוץ (למשל מהכפתור הצף לנהיגה) */
object AssistantBus {
    val voice = kotlinx.coroutines.flow.MutableStateFlow(0)
    /** חיוג מנהיגה – כשהשיחה מסתיימת חוזרים לאפליקציה הקודמת (Waze) */
    @Volatile var backAfterCall = false
    @Volatile var callEndedAt = 0L
    /** מצב נהיגה: מסך נקי – רק מה שצריך לשיחה */
    val driving = kotlinx.coroutines.flow.MutableStateFlow(false)
    /** מהווידג'ט: להתחיל להקשיב (בלי מצב נהיגה) */
    val talk = kotlinx.coroutines.flow.MutableStateFlow(0)
    var talkHandled = 0
    var handled = 0
}

/** כפתור ביטול ענק – לנהיגה */
@Composable
private fun BigCancel(onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = CallRed, contentColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth().height(96.dp)
    ) { Text("✕  " + tr("ביטול"), fontSize = 30.sp, fontWeight = FontWeight.Bold) }
}

/** מסך נקי לנהיגה: רק מה שקורה עכשיו + כפתורים ענקיים */
@Composable
private fun DrivingView(
    autoCall: Assistant.Action?, countdown: Int, listening: Boolean, heard: String, busy: Boolean, last: Assistant.Msg?,
    onCancelCall: () -> Unit, onCancelListen: () -> Unit, onSendNow: () -> Unit,
    onAction: (Assistant.Action) -> Unit, onTalk: () -> Unit, onExit: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.weight(1f))
        when {
            autoCall != null -> {
                Text(tr("📞 מחייג ל{0}", autoCall.name), fontSize = 30.sp, fontWeight = FontWeight.Bold,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Text("$countdown", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text(tr("אפשר גם לומר \"ביטול\""), fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.weight(1f))
                BigCancel(onCancelCall)
            }
            listening -> {
                Text(tr("🎤 מקשיב…"), fontSize = 30.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                if (heard.isNotBlank()) Text(heard, fontSize = 26.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Spacer(Modifier.weight(1f))
                if (heard.isNotBlank()) Button(onClick = onSendNow, shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth().height(72.dp)) { Text(tr("שלח עכשיו"), fontSize = 22.sp) }
                BigCancel(onCancelListen)
            }
            busy -> {
                CircularProgressIndicator(Modifier.size(64.dp), strokeWidth = 5.dp)
                Text(tr("רגע…"), fontSize = 26.sp)
                Spacer(Modifier.weight(1f))
            }
            else -> {
                if (last != null && last.text.isNotBlank()) Text(
                    last.text, fontSize = 22.sp, maxLines = 6,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                last?.actions?.forEach { a ->
                    Button(onClick = { onAction(a) }, shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.fillMaxWidth().height(80.dp)) { Text(a.label, fontSize = 22.sp, maxLines = 1) }
                }
                Spacer(Modifier.weight(1f))
                Button(onClick = onTalk, shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth().height(110.dp)) {
                    Icon(Icons.Filled.Mic, null, Modifier.size(40.dp)); Spacer(Modifier.width(10.dp))
                    Text(tr("דבר"), fontSize = 30.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        TextButton(onClick = onExit) { Text(tr("יציאה ממצב נהיגה"), fontSize = 16.sp) }
    }
}
