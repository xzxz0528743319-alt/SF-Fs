@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.call

import android.Manifest
import android.annotation.SuppressLint
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.telecom.CallAudioState
import android.telecom.TelecomManager
import androidx.compose.foundation.background
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection
import com.phonebook.app.data.CallerId
import com.phonebook.app.data.CallerInfo
import com.phonebook.app.ui.CallGreen
import com.phonebook.app.ui.CallRed
import com.phonebook.app.ui.formatDuration
import com.phonebook.app.ui.ltr
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import android.telecom.Call as TCall

@Composable
fun CallScreen(onFinished: () -> Unit) {
    val info by CallManager.call.collectAsState()
    val audio by CallManager.audio.collectAsState()
    val ctx = LocalContext.current

    LaunchedEffect(info == null) {
        if (info == null) {
            delay(900)
            if (CallManager.call.value == null) onFinished()
        }
    }

    Box(Modifier.fillMaxSize()) {
        StarrySky()
        val c = info
        if (c == null) {
            Text(
                "השיחה הסתיימה", color = Color.White, fontSize = 22.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        } else {
            CallContent(c, audio)
        }
    }
}

@Composable
private fun CallContent(c: CallInfo, audio: AudioInfo) {
        val others by CallManager.others.collectAsState()
        val ctx = LocalContext.current
        val caller by produceState<CallerInfo?>(null, c.number) {
            value = withContext(Dispatchers.IO) { CallerId.lookup(ctx, c.number) }
        }
        var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
        LaunchedEffect(c.state) {
            while (c.state == TCall.STATE_ACTIVE) {
                now = System.currentTimeMillis(); delay(1000)
            }
        }
        var showPad by remember { mutableStateOf(false) }

        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(8.dp))
            val title = caller?.name ?: c.number.ifBlank { "מספר חסוי" }
            val waiting = c.state == TCall.STATE_RINGING || c.state == TCall.STATE_DIALING || c.state == TCall.STATE_CONNECTING
            Box(Modifier.size(180.dp), contentAlignment = Alignment.Center) {
                if (waiting) PulseRings()
                Box(
                    Modifier
                        .size(108.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0x66A78BFA), Color(0x664F8DFF))))
                        .border(2.dp, Color.White.copy(alpha = 0.35f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(title.trim().take(1), color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(20.dp))
            Text(title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
            if (caller != null && c.number.isNotBlank()) {
                Text(ltr(c.number), color = Color.White.copy(alpha = 0.85f), fontSize = 18.sp)
            }
            caller?.let { ci ->
                val line = listOf(ci.detail, ci.source).filter { it.isNotBlank() }.joinToString(" · ")
                if (line.isNotBlank()) Text(line, color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp)
            }
            Spacer(Modifier.height(10.dp))
            val status = if (c.state == TCall.STATE_ACTIVE && c.connectTime > 0)
                formatDuration((now - c.connectTime) / 1000) else callStatusText(c.state)
            Text(status, color = Color.White.copy(alpha = 0.9f), fontSize = 18.sp)

            // שיחות נוספות: ממתינה או בהמתנה
            others.forEach { o -> OtherCallCard(o, c.state) }

            Spacer(Modifier.weight(1f))

            when (c.state) {
                TCall.STATE_SELECT_PHONE_ACCOUNT -> SimPicker()
                TCall.STATE_RINGING -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    BigRound(Icons.Filled.CallEnd, CallRed, "דחה") { CallManager.hangup() }
                    BigRound(Icons.Filled.Call, CallGreen, "ענה") { CallManager.answer() }
                }
                else -> {
                    if (showPad) InCallPad()
                    val ctx = LocalContext.current
                    val isRecording by CallRecorder.recording.collectAsState()
                    val recStart by CallRecorder.startedAt.collectAsState()
                    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                        if (granted) CallRecorder.start(ctx, c.number)?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() }
                        else Toast.makeText(ctx, "בלי הרשאת מיקרופון אי אפשר להקליט", Toast.LENGTH_LONG).show()
                    }
                    val speaker = audio.route == CallAudioState.ROUTE_SPEAKER
                    val btAvailable = audio.supported and CallAudioState.ROUTE_BLUETOOTH != 0
                    val bt = audio.route == CallAudioState.ROUTE_BLUETOOTH

                    if (isRecording) {
                        Text(
                            "● מקליט " + formatDuration((now - recStart).coerceAtLeast(0) / 1000) +
                                if (!speaker) "  ·  הפעל רמקול כדי להקליט גם את הצד השני" else "",
                            color = Color(0xFFFF8A8A), fontSize = 13.sp, textAlign = TextAlign.Center,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ToggleRound(if (audio.muted) Icons.Filled.MicOff else Icons.Filled.Mic, "השתק", audio.muted) {
                            CallManager.setMuted(!audio.muted)
                        }
                        ToggleRound(Icons.Filled.Dialpad, "מקלדת", showPad) { showPad = !showPad }
                        ToggleRound(Icons.Filled.VolumeUp, "רמקול", speaker) {
                            CallManager.setRoute(if (speaker) CallAudioState.ROUTE_WIRED_OR_EARPIECE else CallAudioState.ROUTE_SPEAKER)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ToggleRound(Icons.Filled.Bluetooth, "בלוטות'", bt, enabled = btAvailable) {
                            if (!btAvailable) Toast.makeText(ctx, "אין אוזניות או רכב בבלוטות' מחוברים", Toast.LENGTH_SHORT).show()
                            else CallManager.setRoute(if (bt) CallAudioState.ROUTE_WIRED_OR_EARPIECE else CallAudioState.ROUTE_BLUETOOTH)
                        }
                        ToggleRound(Icons.Filled.FiberManualRecord, if (isRecording) "עצור הקלטה" else "הקלט", isRecording, onColor = Color(0xFFE53935)) {
                            if (isRecording) {
                                if (CallRecorder.stop()) Toast.makeText(ctx, "ההקלטה נשמרה בתיקייה ${CallRecorder.folder}", Toast.LENGTH_LONG).show()
                            } else if (!CallRecorder.hasPermission(ctx)) micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            else CallRecorder.start(ctx, c.number)?.let { Toast.makeText(ctx, it, Toast.LENGTH_LONG).show() }
                        }
                        ToggleRound(Icons.Filled.Pause, "המתנה", c.state == TCall.STATE_HOLDING) { CallManager.toggleHold() }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        if (others.any { it.state == TCall.STATE_HOLDING }) {
                            ToggleRound(Icons.Filled.SwapCalls, "החלף שיחה", false) { CallManager.swap() }
                        }
                        if (others.isNotEmpty() && (c.canMerge || others.any { it.canMerge })) {
                            ToggleRound(Icons.Filled.CallMerge, "מזג שיחות", false) { CallManager.merge() }
                        }
                        if (others.isEmpty() && c.state == TCall.STATE_ACTIVE) {
                            ToggleRound(Icons.Filled.AddIcCall, "הוסף שיחה", false) {
                                // פותח את החייגן; השיחה הנוכחית תעבור להמתנה כשמחייגים
                                ctx.startActivity(
                                    android.content.Intent(android.content.Intent.ACTION_DIAL)
                                        .setClass(ctx, com.phonebook.app.MainActivity::class.java)
                                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                    BigRound(Icons.Filled.CallEnd, CallRed, "נתק") { CallManager.hangup() }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
}

@Composable
private fun BigRound(icon: ImageVector, color: Color, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(76.dp).clip(CircleShape).background(color).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(icon, label, tint = Color.White, modifier = Modifier.size(34.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}

@Composable
private fun ToggleRound(
    icon: ImageVector, label: String, on: Boolean,
    enabled: Boolean = true, onColor: Color = Color(0xFF5B5BD6), onClick: () -> Unit,
) {
    val alpha = if (enabled) 1f else 0.4f
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(84.dp)) {
        Box(
            Modifier
                .size(62.dp)
                .clip(CircleShape)
                .background(if (on) Color.White else Color.White.copy(alpha = 0.16f * alpha))
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) { Icon(icon, label, tint = if (on) onColor else Color.White.copy(alpha = alpha)) }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Color.White.copy(alpha = alpha), fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun InCallPad() {
    var typed by remember { mutableStateOf("") }
    Text(ltr(typed), color = Color.White, fontSize = 26.sp, modifier = Modifier.padding(bottom = 8.dp))
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.padding(bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("123", "456", "789", "*0#").forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    row.forEach { ch ->
                        Box(
                            Modifier
                                .size(58.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.14f))
                                .clickable { typed += ch; CallManager.dtmf(ch) },
                            contentAlignment = Alignment.Center
                        ) { Text(ch.toString(), color = Color.White, fontSize = 24.sp) }
                    }
                }
            }
        }
    }
}

@SuppressLint("MissingPermission")
@Composable
private fun SimPicker() {
    val ctx = LocalContext.current
    val tm = remember { ctx.getSystemService(TelecomManager::class.java) }
    val accounts = remember { try { tm.callCapablePhoneAccounts } catch (_: Exception) { emptyList() } }
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("מאיזה כרטיס SIM להתקשר?", color = Color.White, fontSize = 18.sp)
        accounts.forEach { h ->
            val label = try { tm.getPhoneAccount(h)?.label?.toString() } catch (_: Exception) { null } ?: "SIM"
            Button(
                onClick = { CallManager.selectAccount(h) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF4F6FF0)),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth(0.7f)
            ) { Text(label, fontSize = 17.sp) }
        }
        TextButton(onClick = { CallManager.hangup() }) { Text("ביטול", color = Color.White) }
    }
}

/** רקע מסך השיחה: שמי לילה עם כוכבים מנצנצים וכוכב נופל מדי פעם */
@Composable
private fun StarrySky() {
    data class Star(val x: Float, val y: Float, val r: Float, val speed: Float, val phase: Float, val warm: Boolean)
    val stars = remember {
        val rnd = java.util.Random(7)
        List(150) {
            Star(rnd.nextFloat(), rnd.nextFloat(), 0.6f + rnd.nextFloat() * rnd.nextFloat() * 2.4f,
                0.6f + rnd.nextFloat() * 1.8f, rnd.nextFloat() * 6.28f, rnd.nextFloat() < 0.15f)
        }
    }
    val t by rememberInfiniteTransition(label = "sky").animateFloat(
        initialValue = 0f, targetValue = 1000f,
        animationSpec = infiniteRepeatable(tween(1_000_000, easing = LinearEasing)), label = "t"
    )
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF070B24), Color(0xFF151A4A), Color(0xFF2B1B5C), Color(0xFF3B1F66))))
        // ערפילית רכה
        drawCircle(
            Brush.radialGradient(listOf(Color(0x335B6CFF), Color.Transparent), center = Offset(size.width * 0.8f, size.height * 0.25f), radius = size.width * 0.7f),
            radius = size.width * 0.7f, center = Offset(size.width * 0.8f, size.height * 0.25f)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0x33C06CFF), Color.Transparent), center = Offset(size.width * 0.15f, size.height * 0.7f), radius = size.width * 0.6f),
            radius = size.width * 0.6f, center = Offset(size.width * 0.15f, size.height * 0.7f)
        )
        val dp = density
        stars.forEach { st ->
            val a = 0.35f + 0.65f * ((kotlin.math.sin(t * st.speed + st.phase) + 1f) / 2f)
            drawCircle(
                if (st.warm) Color(0xFFFFE9B0).copy(alpha = a) else Color.White.copy(alpha = a),
                radius = st.r * dp, center = Offset(st.x * size.width, st.y * size.height)
            )
        }
        // כוכב נופל כל כמה שניות
        val cycle = (t % 9f) / 9f
        if (cycle < 0.12f) {
            val p = cycle / 0.12f
            val sx = size.width * (0.9f - 0.7f * p)
            val sy = size.height * (0.08f + 0.25f * p)
            drawLine(
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.9f * (1 - p)), Color.Transparent), start = Offset(sx, sy), end = Offset(sx + 90 * dp, sy - 32 * dp)),
                start = Offset(sx, sy), end = Offset(sx + 90 * dp, sy - 32 * dp), strokeWidth = 2 * dp
            )
        }
    }
}

/** טבעות אור שמתרחבות סביב התמונה בזמן צלצול */
@Composable
private fun PulseRings() {
    val p by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "p"
    )
    Canvas(Modifier.fillMaxSize()) {
        for (i in 0..2) {
            val f = (p + i / 3f) % 1f
            drawCircle(
                Color(0xFFB9A8FF).copy(alpha = 0.5f * (1 - f)),
                radius = size.minDimension / 2 * (0.6f + 0.4f * f),
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}

/** כרטיס של שיחה נוספת: ממתינה (נכנסת בזמן שיחה) או בהמתנה */
@Composable
private fun OtherCallCard(o: CallInfo, mainState: Int) {
    val ctx = LocalContext.current
    val name by produceState<String?>(null, o.number) {
        value = withContext(Dispatchers.IO) { CallerId.lookup(ctx, o.number)?.name }
    }
    val label = name ?: ltr(o.number.ifBlank { "מספר חסוי" })
    val status = when (o.state) {
        TCall.STATE_HOLDING -> "בהמתנה"
        TCall.STATE_RINGING -> "שיחה ממתינה"
        TCall.STATE_ACTIVE -> "פעילה"
        else -> callStatusText(o.state)
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 14.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(status, color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
        }
        if (o.state == TCall.STATE_HOLDING && mainState != TCall.STATE_RINGING) {
            TextButton(onClick = { CallManager.swap() }) { Text("עבור", color = Color.White) }
        }
        TextButton(onClick = { CallManager.hangupOther(o.id) }) { Text("נתק", color = Color(0xFFFF8A8A)) }
    }
}
