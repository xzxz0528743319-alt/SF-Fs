package com.phonebook.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Prefs

val Navy = Color(0xFF26235E)
val Brand = Color(0xFF5B5BD6)
val Lavender = Color(0xFF5B5BD6)
val CallGreen = Color(0xFF1FA35B)
val WhatsGreen = Color(0xFF3DDC6F)
val CallRed = Color(0xFFD9364A)

/**
 * עיצוב "שמי לילה" – באותה שפה של האייקון ומסך השיחה:
 * כותרת אינדיגו עמוק, רקע בהיר ושקט עם נגיעת לבנדר, כרטיסים לבנים, צבע אחד מוביל (אינדיגו).
 * נקי ורגוע לעין, אבל לא יבש.
 */
private val Light = lightColorScheme(
    primary = Color(0xFF5B5BD6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE9E8FB),
    onPrimaryContainer = Color(0xFF26235E),
    secondary = Color(0xFF26235E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF26235E),   // צבע הכותרת
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFF1FA35B),
    background = Color(0xFFF6F6FB),
    onBackground = Color(0xFF1B1B2F),
    surface = Color(0xFFF6F6FB),
    onSurface = Color(0xFF1B1B2F),
    onSurfaceVariant = Color(0xFF666784),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color.White,
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFEFEEF9),   // רקע כפתורי המספרים
    surfaceContainerHighest = Color(0xFFE4E3F3),
    outlineVariant = Color(0xFFE8E7F2),
    error = Color(0xFFD9364A),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF9B9BFF),
    onPrimary = Color(0xFF14123A),
    primaryContainer = Color(0xFF2E2B6E),
    onPrimaryContainer = Color(0xFFE4E3FF),
    secondary = Color(0xFFB8B6E8),
    onSecondary = Color(0xFF14123A),
    secondaryContainer = Color(0xFF17153F),
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFF3CCB78),
    background = Color(0xFF0C0C1D),
    onBackground = Color(0xFFE9E8F5),
    surface = Color(0xFF0C0C1D),
    onSurface = Color(0xFFE9E8F5),
    onSurfaceVariant = Color(0xFFA2A1BF),
    surfaceContainerLowest = Color(0xFF16162B),
    surfaceContainerLow = Color(0xFF16162B),
    surfaceContainer = Color(0xFF16162B),
    surfaceContainerHigh = Color(0xFF21213A),
    surfaceContainerHighest = Color(0xFF2B2B48),
    outlineVariant = Color(0xFF26263F),
    error = Color(0xFFFF6B7D),
)

/** רקע המסכים (אחיד) */
@Composable
fun skyBrush(): Brush = SolidColor(MaterialTheme.colorScheme.background)

/** צבע הכפתורים העגולים – מעבר עדין מאינדיגו לסגול, כמו השמיים באייקון */
val BrandGradient: Brush = Brush.linearGradient(listOf(Color(0xFF5B6CFF), Color(0xFF8B5CF6)))

@Composable
fun PhonebookTheme(content: @Composable () -> Unit) {
    val mode by Prefs.theme.collectAsState()
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(24.dp),
        ),
    ) {
        val scale by Prefs.textScale.collectAsState()
        val d = LocalDensity.current
        val factor = when (scale) { 1 -> 1.15f; 2 -> 1.3f; else -> 1f }
        CompositionLocalProvider(
            LocalLayoutDirection provides LayoutDirection.Rtl,
            LocalDensity provides Density(d.density, d.fontScale * factor),
            content = content
        )
    }
}
