package com.phonebook.app.pc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.phonebook.app.MainActivity
import com.phonebook.app.R
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.Server
import com.phonebook.app.sms.SmsSender
import com.phonebook.app.ui.Actions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant

/**
 * חיבור למחשב: הטלפון בודק כל כמה שניות אם במחשב לחצו "חייג" או "שלח SMS",
 * ומבצע את זה מהטלפון. עובד רק עם אותו חשבון בשני המכשירים (המחשב והטלפון).
 */
class PcLinkService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        if (intent?.action == ACTION_STOP || !Server.loggedIn() || !Prefs.pcLink) {
            stop(); return START_NOT_STICKY
        }
        if (!running.value) {
            running.value = true
            scope.launch { loop() }
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "חיבור למחשב", NotificationManager.IMPORTANCE_MIN))
        val open = PendingIntent.getActivity(
            this, 7, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopPi = PendingIntent.getService(
            this, 8, Intent(this, PcLinkService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_phone)
            .setContentTitle("💻 מחובר למחשב")
            .setContentText("אפשר לחייג ולשלוח הודעות מהמחשב")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "נתק", stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(ID, n)
    }

    private suspend fun loop() {
        var lastBeat = 0L
        while (scope.isActive && Prefs.pcLink && Server.loggedIn()) {
            try {
                val now = System.currentTimeMillis()
                if (now - lastBeat > 25_000) {
                    Server.rest(
                        "POST", "pc_link", JSONObject().put("seen_at", Instant.now().toString()).toString(),
                        mapOf("Prefer" to "resolution=merge-duplicates,return=minimal")
                    )
                    lastBeat = now
                }
                val arr = JSONArray(Server.rest("GET", "pc_commands?done=eq.false&order=created_at.asc&limit=5"))
                for (i in 0 until arr.length()) handle(arr.getJSONObject(i))
            } catch (_: Exception) {
            }
            delay(2_500)
        }
        running.value = false
        stop()
    }

    private suspend fun handle(o: JSONObject) {
        val id = o.optLong("id")
        Server.rest("PATCH", "pc_commands?id=eq.$id", JSONObject().put("done", true).toString(), mapOf("Prefer" to "return=minimal"))
        // פקודה ישנה (יותר מ-2 דקות) – לא מבצעים, כדי שלא יתחיל פתאום חיוג
        val created = runCatching { Instant.parse(o.optString("created_at").replace(" ", "T")).toEpochMilli() }.getOrNull()
        if (created != null && System.currentTimeMillis() - created > 120_000) return
        val number = o.optString("number").trim()
        if (number.isBlank()) return
        when (o.optString("kind")) {
            "sms" -> runCatching { SmsSender.send(this, number, o.optString("body")) }
            else -> kotlinx.coroutines.withContext(Dispatchers.Main) { Actions.call(this@PcLinkService, number) }
        }
    }

    private fun stop() {
        running.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running.value = false
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "pc_link"
        private const val ID = 4401
        private const val ACTION_STOP = "com.phonebook.app.PC_STOP"
        val running = MutableStateFlow(false)

        fun start(ctx: Context) {
            Prefs.pcLink = true
            ContextCompat.startForegroundService(ctx, Intent(ctx, PcLinkService::class.java))
        }

        fun stop(ctx: Context) {
            Prefs.pcLink = false
            ctx.startService(Intent(ctx, PcLinkService::class.java).setAction(ACTION_STOP))
        }
    }
}

/** אחרי הפעלה מחדש של הטלפון – מחזירים את החיבור למחשב אם היה דלוק */
class PcBootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.pcLink && Server.loggedIn()) {
            runCatching { ContextCompat.startForegroundService(context, Intent(context, PcLinkService::class.java)) }
        }
    }
}
