package com.phonebook.app.net

import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * הספר הכללי המשותף.
 * קריאה: מהתצוגה contacts_public (בלי אימייל).
 * כתיבה: לטבלה contacts – השרת מאפשר עריכה/מחיקה רק למי שהוסיף.
 */
object SharedBook {
    private const val COLS = "id,owner,name,phone,phone2,city,address,father,chem,shtibel,extra,deleted,updated_at"
    private const val PAGE = 500

    fun canEdit(c: Contact) = Server.loggedIn() && (Prefs.isAdmin || (c.owner.isNotBlank() && c.owner == Prefs.userId))

    /** מושך רק מה שהשתנה מאז הסנכרון האחרון. מחזיר כמה רשומות עודכנו. */
    suspend fun sync(): Int = withContext(Dispatchers.IO) {
        Server.refreshStatus()
        val since = Prefs.lastSync
        var maxTs = since
        var offset = 0
        var total = 0
        while (true) {
            val filter = if (since.isBlank()) "" else "&updated_at=gt." + URLEncoder.encode(since, "UTF-8")
            val arr = JSONArray(
                Server.rest("GET", "contacts_public?select=$COLS$filter&order=updated_at.asc,id.asc&limit=$PAGE&offset=$offset")
            )
            val live = mutableListOf<Contact>()
            val dead = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ts = o.optString("updated_at")
                if (ts > maxTs) maxTs = ts
                if (o.optBoolean("deleted")) dead += o.getString("id") else live += fromJson(o)
            }
            LocalDb.upsertAll(LocalDb.SHARED, live, dead)
            total += arr.length()
            offset += arr.length()
            if (arr.length() < PAGE) break
        }
        Prefs.lastSync = maxTs
        total
    }

    private fun fromJson(o: JSONObject) = Contact(
        id = o.getString("id"),
        name = o.optString("name"), phone = o.optString("phone"), phone2 = o.optString("phone2"),
        city = o.optString("city"), address = o.optString("address"), father = o.optString("father"),
        chem = o.optString("chem"), shtibel = o.optString("shtibel"), owner = o.optString("owner"),
        extra = if (o.isNull("extra")) "" else o.optString("extra"),
    )

    private fun toJson(c: Contact) = JSONObject()
        .put("name", c.name.trim()).put("phone", c.phone.trim()).put("phone2", c.phone2.trim())
        .put("city", c.city.trim()).put("address", c.address.trim()).put("father", c.father.trim())
        .put("chem", c.chem.trim()).put("shtibel", c.shtibel.trim()).put("email", c.email.trim()).put("extra", c.extra)

    private val minimal = mapOf("Prefer" to "return=minimal")

    suspend fun add(c: Contact) {
        withContext(Dispatchers.IO) { Server.rest("POST", "contacts", toJson(c).toString(), minimal) }
        sync()
    }

    private fun key(c: Contact): String {
        val d = c.phone.filter { it.isDigit() }.takeLast(9)
        return if (d.length >= 7) "p$d" else "n" + c.name.trim().replace(Regex("\\s+"), " ") + "|" + c.city.trim()
    }

    /** מוסיף רשימה לספר הכללי, בלי מי שכבר נמצא בו (לפי מספר). מחזיר כמה נוספו */
    suspend fun addMany(list: List<Contact>): Int {
        val fresh = withContext(Dispatchers.IO) {
            val have = LocalDb.all(LocalDb.SHARED).map { key(it) }.toHashSet()
            list.filter { have.add(key(it)) }
        }
        withContext(Dispatchers.IO) {
            fresh.chunked(500).forEach { chunk ->
                val arr = JSONArray()
                chunk.forEach { arr.put(toJson(it)) }
                Server.rest("POST", "contacts", arr.toString(), minimal)
            }
        }
        sync()
        return fresh.size
    }

    /** מעתיק לספר הכללי את כל אנשי הקשר מהספר האישי שעוד לא נמצאים בו. הספר האישי לא משתנה. */
    suspend fun uploadPersonal(onProgress: (done: Int, total: Int) -> Unit): Int {
        val list = withContext(Dispatchers.IO) {
            val have = LocalDb.all(LocalDb.SHARED).map { key(it) }.toHashSet()
            LocalDb.all(LocalDb.PERSONAL)
                .filter { it.name.isNotBlank() || it.phone.isNotBlank() }
                .filter { have.add(key(it)) }
        }
        var done = 0
        onProgress(0, list.size)
        withContext(Dispatchers.IO) {
            list.chunked(500).forEach { chunk ->
                val arr = JSONArray()
                chunk.forEach { arr.put(toJson(it)) }
                Server.rest("POST", "contacts", arr.toString(), minimal)
                done += chunk.size
                onProgress(done, list.size)
            }
        }
        sync()
        return list.size
    }

    suspend fun update(c: Contact) {
        withContext(Dispatchers.IO) { Server.rest("PATCH", "contacts?id=eq.${c.id}", toJson(c).toString(), minimal) }
        sync()
    }

    suspend fun delete(id: String) {
        withContext(Dispatchers.IO) {
            Server.rest("PATCH", "contacts?id=eq.$id", JSONObject().put("deleted", true).toString(), minimal)
        }
        sync()
    }

    /** דיווח על רשומה שגויה */
    suspend fun report(contactId: String, reason: String) = withContext(Dispatchers.IO) {
        Server.rest(
            "POST", "reports",
            JSONObject().put("contact_id", contactId).put("reason", reason.take(500)).put("reporter", Prefs.userId).toString(),
            minimal
        )
    }

    // ---------------- כלי מנהל ----------------

    // ---------------- משוב ----------------
    data class Feedback(val id: Long, val email: String, val message: String, val created: String)

    /** כתובת המייל שאליה נשלח משוב (המנהל קובע). ריק אם לא נקבעה */
    suspend fun feedbackEmail(): String = withContext(Dispatchers.IO) {
        val arr = JSONArray(Server.rest("GET", "app_config?key=eq.feedback_email&select=value"))
        if (arr.length() == 0) "" else arr.getJSONObject(0).optString("value")
    }

    suspend fun setFeedbackEmail(email: String) = withContext(Dispatchers.IO) {
        Server.rest(
            "POST", "app_config", JSONObject().put("key", "feedback_email").put("value", email.trim()).toString(),
            mapOf("Prefer" to "resolution=merge-duplicates,return=minimal")
        )
    }

    suspend fun sendFeedback(message: String, replyTo: String) = withContext(Dispatchers.IO) {
        Server.rest("POST", "feedback", JSONObject().put("message", message.take(5000)).put("email", replyTo.trim()).toString(), minimal)
    }

    suspend fun feedbackList(): List<Feedback> = withContext(Dispatchers.IO) {
        val arr = JSONArray(Server.rest("GET", "feedback?select=id,email,message,created_at&order=created_at.desc&limit=200"))
        (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            Feedback(it.optLong("id"), it.optString("email"), it.optString("message"), it.optString("created_at").take(16).replace('T', ' '))
        }
    }

    suspend fun deleteFeedback(id: Long) = withContext(Dispatchers.IO) { Server.rest("DELETE", "feedback?id=eq.$id") }

    data class Pending(val id: String, val name: String, val phone: String, val city: String, val created: String)
    data class Report(val id: Long, val contactId: String, val name: String, val phone: String, val reason: String, val created: String)
    data class User(val id: String, val email: String, val approved: Boolean, val isAdmin: Boolean)

    suspend fun pending(): List<Pending> = withContext(Dispatchers.IO) {
        val arr = JSONArray(Server.rest("GET", "contacts?select=id,name,phone,city,created_at&approved=eq.false&deleted=eq.false&order=created_at.asc&limit=500"))
        (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            Pending(it.getString("id"), it.optString("name"), it.optString("phone"), it.optString("city"), it.optString("created_at"))
        }
    }

    suspend fun approve(ids: List<String>) {
        if (ids.isEmpty()) return
        withContext(Dispatchers.IO) {
            ids.chunked(100).forEach { chunk ->
                Server.rest("PATCH", "contacts?id=in.(${chunk.joinToString(",")})", JSONObject().put("approved", true).toString(), minimal)
            }
        }
        sync()
    }

    suspend fun reports(): List<Report> = withContext(Dispatchers.IO) {
        val arr = JSONArray(Server.rest("GET", "reports?select=id,contact_id,reason,created_at,contacts(name,phone)&handled=eq.false&order=created_at.desc&limit=300"))
        (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            val c = it.optJSONObject("contacts")
            Report(it.getLong("id"), it.optString("contact_id"), c?.optString("name") ?: "", c?.optString("phone") ?: "",
                it.optString("reason"), it.optString("created_at"))
        }
    }

    suspend fun closeReport(id: Long) = withContext(Dispatchers.IO) {
        Server.rest("PATCH", "reports?id=eq.$id", JSONObject().put("handled", true).toString(), minimal)
    }

    suspend fun users(): List<User> = withContext(Dispatchers.IO) {
        val arr = JSONArray(Server.rest("GET", "app_users?select=id,email,approved,is_admin&order=created_at.asc"))
        (0 until arr.length()).map { arr.getJSONObject(it) }.map {
            User(it.getString("id"), it.optString("email"), it.optBoolean("approved", true), it.optBoolean("is_admin"))
        }
    }

    suspend fun setUser(id: String, approved: Boolean? = null, admin: Boolean? = null) = withContext(Dispatchers.IO) {
        val o = JSONObject()
        approved?.let { o.put("approved", it) }
        admin?.let { o.put("is_admin", it) }
        Server.rest("PATCH", "app_users?id=eq.$id", o.toString(), minimal)
    }
}
