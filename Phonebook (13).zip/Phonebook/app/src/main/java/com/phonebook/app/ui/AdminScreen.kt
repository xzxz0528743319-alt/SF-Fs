@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.phonebook.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.SharedBook
import kotlinx.coroutines.launch

/** ניהול הספר הכללי – רק למנהלים */
@Composable
fun AdminScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var reload by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<List<SharedBook.Pending>>(emptyList()) }
    var reports by remember { mutableStateOf<List<SharedBook.Report>>(emptyList()) }
    var users by remember { mutableStateOf<List<SharedBook.User>>(emptyList()) }
    var feedback by remember { mutableStateOf<List<SharedBook.Feedback>>(emptyList()) }
    var fbEmail by remember { mutableStateOf(Prefs.feedbackEmail) }
    var confirmDelete by remember { mutableStateOf<Pair<String, String>?>(null) }

    LaunchedEffect(tab, reload) {
        busy = true; error = null
        runCatching {
            when (tab) {
                0 -> pending = SharedBook.pending()
                1 -> reports = SharedBook.reports()
                2 -> users = SharedBook.users()
                else -> {
                    fbEmail = SharedBook.feedbackEmail().also { Prefs.feedbackEmail = it }
                    feedback = SharedBook.feedbackList()
                }
            }
        }.onFailure { error = it.message ?: "שגיאה" }
        busy = false
    }

    fun act(done: String, block: suspend () -> Unit) {
        scope.launch {
            runCatching { block() }
                .onSuccess { toast(ctx, done); reload++ }
                .onFailure { toast(ctx, "נכשל: ${it.message}") }
        }
    }

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar("ניהול הספר הכללי", onClose)
        TabRow(selectedTabIndex = tab) {
            listOf("ממתינים", "דיווחים", "משתמשים", "משוב").forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        if (!Prefs.isAdmin) {
            EmptyState("אין לך הרשאת מנהל")
            return@Column
        }
        when {
            busy -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            error != null -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoCard("לא הצלחתי לטעון: $error\nאם השרת הוקם לפני העדכון – צריך להריץ שוב את קובץ schema.sql.")
                Button(onClick = { reload++ }) { Text("נסה שוב") }
            }
            tab == 0 -> if (pending.isEmpty()) EmptyState("אין רשומות שממתינות לאישור") else Column {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${pending.size} רשומות ממתינות", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Button(onClick = { act("אושרו ${pending.size} רשומות") { SharedBook.approve(pending.map { it.id }) } }) {
                        Text("✅ אשר הכל")
                    }
                }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(pending, key = { it.id }) { p ->
                        AppCard {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.SemiBold)
                                    Text(ltr(p.phone) + if (p.city.isNotBlank()) " · ${p.city}" else "",
                                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = { act("אושר") { SharedBook.approve(listOf(p.id)) } }) { Text("אשר") }
                                TextButton(onClick = { confirmDelete = p.id to p.name }) { Text("מחק", color = CallRed) }
                            }
                        }
                    }
                }
            }
            tab == 1 -> if (reports.isEmpty()) EmptyState("אין דיווחים פתוחים") else
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(reports, key = { it.id }) { r ->
                        AppCard {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(r.name.ifBlank { "(רשומה שנמחקה)" }, fontWeight = FontWeight.SemiBold)
                                if (r.phone.isNotBlank()) Text(ltr(r.phone), style = MaterialTheme.typography.bodySmall)
                                Text("סיבה: ${r.reason}", style = MaterialTheme.typography.bodyMedium)
                                Row {
                                    TextButton(onClick = { act("הדיווח נסגר") { SharedBook.closeReport(r.id) } }) { Text("סגור דיווח") }
                                    if (r.contactId.isNotBlank() && r.name.isNotBlank())
                                        TextButton(onClick = { confirmDelete = r.contactId to r.name }) { Text("מחק את הרשומה", color = CallRed) }
                                }
                            }
                        }
                    }
                }
            tab == 3 -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    AppCard {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("לאיזה מייל לשלוח את המשוב?", fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(
                                fbEmail, { fbEmail = it }, singleLine = true, placeholder = { Text("name@gmail.com") },
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Email),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(onClick = {
                                act("נשמר – המשוב יישלח ל-${fbEmail.trim()}") { SharedBook.setFeedbackEmail(fbEmail); Prefs.feedbackEmail = fbEmail }
                            }) { Text("שמור") }
                            Text("כל משוב נשמר גם כאן למטה.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                if (feedback.isEmpty()) item { Text("עוד לא התקבל משוב", Modifier.padding(8.dp)) }
                items(feedback, key = { it.id }) { f ->
                    AppCard {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(f.message)
                            Text(ltr(f.created) + if (f.email.isNotBlank()) " · " + ltr(f.email) else "",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            TextButton(onClick = { act("נמחק") { SharedBook.deleteFeedback(f.id) } }) { Text("מחק", color = CallRed) }
                        }
                    }
                }
            }
            else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(users, key = { it.id }) { u ->
                    AppCard {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(ltr(u.email.ifBlank { u.id.take(8) }), fontWeight = FontWeight.SemiBold)
                                Text(
                                    (if (u.isAdmin) "🛡️ מנהל · " else "") + (if (u.approved) "פעיל" else "⛔ חסום"),
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (u.id != Prefs.userId) {
                                TextButton(onClick = {
                                    act(if (u.approved) "המשתמש נחסם" else "המשתמש אושר") { SharedBook.setUser(u.id, approved = !u.approved) }
                                }) { Text(if (u.approved) "חסום" else "אשר") }
                                TextButton(onClick = {
                                    act(if (u.isAdmin) "הוסר ממנהלים" else "נוסף כמנהל") { SharedBook.setUser(u.id, admin = !u.isAdmin) }
                                }) { Text(if (u.isAdmin) "הסר ניהול" else "הפוך למנהל") }
                            } else Text("זה אתה", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    confirmDelete?.let { (id, name) ->
        ConfirmDialog("למחוק את \"$name\"?", "הרשומה תוסר מהספר הכללי אצל כולם.", "מחק", onDismiss = { confirmDelete = null }) {
            confirmDelete = null
            act("נמחק") { SharedBook.delete(id) }
        }
    }
}
