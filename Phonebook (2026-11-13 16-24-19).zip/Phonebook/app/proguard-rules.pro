# הקוד של האפליקציה נשמר כמו שהוא (רכיבים שאנדרואיד מפעיל לפי שם)
-keep class com.phonebook.app.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# OkHttp / Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn javax.annotation.**
-dontwarn kotlin.Unit
