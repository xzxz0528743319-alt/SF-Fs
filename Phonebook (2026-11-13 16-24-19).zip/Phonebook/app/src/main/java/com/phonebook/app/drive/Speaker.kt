package com.phonebook.app.drive

import android.content.Context
import android.media.AudioAttributes
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.phonebook.app.ui.I18n

/** קול אחד לכל האפליקציה (הקראת מתקשר, הודעות בנהיגה). עובד גם כשהאפליקציה סגורה */
object Speaker {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var failed = false
    private val pending = mutableListOf<() -> Unit>()
    private val callbacks = HashMap<String, () -> Unit>()
    private val main = Handler(Looper.getMainLooper())

    private fun init(ctx: Context) {
        if (tts != null) return
        var engine: TextToSpeech? = null
        engine = TextToSpeech(ctx.applicationContext) { st ->
            main.post {
                if (st == TextToSpeech.SUCCESS) {
                    ready = true
                    runCatching { engine?.language = I18n.locale() }
                    runCatching {
                        engine?.setAudioAttributes(
                            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                        )
                    }
                    engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { finish(id) }
                        @Deprecated("") override fun onError(id: String?) { finish(id) }
                        override fun onError(id: String?, errorCode: Int) { finish(id) }
                    })
                } else failed = true
                val list = pending.toList(); pending.clear(); list.forEach { it() }
            }
        }
        tts = engine
    }

    private fun finish(id: String?) {
        val cb = synchronized(callbacks) { callbacks.remove(id ?: "") } ?: return
        main.post(cb)
    }

    /** מקריא את הטקסט; done נקרא כשההקראה מסתיימת (או מיד אם אין מנוע קול) */
    fun speak(ctx: Context, text: String, done: (() -> Unit)? = null) {
        init(ctx)
        val clean = text.replace(Regex("[*_#`>]"), "").take(800)
        val run = run@{
            val e = tts
            if (failed || e == null || clean.isBlank()) { done?.let { main.post(it) }; return@run }
            runCatching { e.language = I18n.locale() }
            val id = "s" + System.nanoTime()
            done?.let { synchronized(callbacks) { callbacks[id] = it } }
            if (e.speak(clean, TextToSpeech.QUEUE_FLUSH, Bundle(), id) != TextToSpeech.SUCCESS) finish(id)
        }
        if (ready || failed) run() else pending += run
    }

    fun stop() {
        synchronized(callbacks) { callbacks.clear() }
        runCatching { tts?.stop() }
    }
}
