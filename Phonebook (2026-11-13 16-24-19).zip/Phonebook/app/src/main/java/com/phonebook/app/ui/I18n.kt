package com.phonebook.app.ui

import android.content.Context
import androidx.compose.runtime.mutableStateOf
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.Assistant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * שפות האפליקציה.
 * עברית – השפה המקורית. אנגלית – מתורגמת מראש ומגיעה עם האפליקציה.
 * כל שפה אחרת – מתורגמת פעם אחת ע"י העוזרת (דרך השרת) ונשמרת בטלפון.
 */
object I18n {
    data class Lang(val code: String, val name: String, val english: String, val rtl: Boolean = false)

    val LANGS = listOf(
        Lang("he", "עברית", "Hebrew", true),
        Lang("en", "English", "English"),
        Lang("ar", "العربية", "Arabic", true),
        Lang("yi", "ייִדיש", "Yiddish", true),
        Lang("ru", "Русский", "Russian"),
        Lang("fr", "Français", "French"),
        Lang("es", "Español", "Spanish"),
        Lang("am", "አማርኛ", "Amharic"),
        Lang("de", "Deutsch", "German"),
        Lang("pt", "Português", "Portuguese"),
        Lang("it", "Italiano", "Italian"),
        Lang("uk", "Українська", "Ukrainian"),
        Lang("ro", "Română", "Romanian"),
        Lang("hu", "Magyar", "Hungarian"),
        Lang("pl", "Polski", "Polish"),
        Lang("nl", "Nederlands", "Dutch"),
        Lang("tr", "Türkçe", "Turkish"),
        Lang("fa", "فارسی", "Persian", true),
        Lang("ur", "اردو", "Urdu", true),
        Lang("hi", "हिन्दी", "Hindi"),
        Lang("bn", "বাংলা", "Bengali"),
        Lang("zh", "中文", "Chinese (Simplified)"),
        Lang("ja", "日本語", "Japanese"),
        Lang("ko", "한국어", "Korean"),
        Lang("th", "ไทย", "Thai"),
        Lang("vi", "Tiếng Việt", "Vietnamese"),
        Lang("id", "Bahasa Indonesia", "Indonesian"),
        Lang("ms", "Bahasa Melayu", "Malay"),
        Lang("tl", "Filipino", "Filipino"),
        Lang("el", "Ελληνικά", "Greek"),
        Lang("cs", "Čeština", "Czech"),
        Lang("sk", "Slovenčina", "Slovak"),
        Lang("bg", "Български", "Bulgarian"),
        Lang("sr", "Српски", "Serbian"),
        Lang("hr", "Hrvatski", "Croatian"),
        Lang("sv", "Svenska", "Swedish"),
        Lang("no", "Norsk", "Norwegian"),
        Lang("da", "Dansk", "Danish"),
        Lang("fi", "Suomi", "Finnish"),
        Lang("ka", "ქართული", "Georgian"),
        Lang("hy", "Հայերեն", "Armenian"),
        Lang("az", "Azərbaycanca", "Azerbaijani"),
        Lang("uz", "Oʻzbekcha", "Uzbek"),
        Lang("kk", "Қазақша", "Kazakh"),
        Lang("ti", "ትግርኛ", "Tigrinya"),
        Lang("sw", "Kiswahili", "Swahili"),
        Lang("ha", "Hausa", "Hausa"),
        Lang("yo", "Yorùbá", "Yoruba"),
        Lang("ta", "தமிழ்", "Tamil"),
        Lang("te", "తెలుగు", "Telugu"),
        Lang("mr", "मराठी", "Marathi"),
        Lang("pa", "ਪੰਜਾਬੀ", "Punjabi"),
        Lang("ku", "Kurdî", "Kurdish"),
        Lang("lad", "Ladino", "Ladino (Judeo-Spanish)"),
    )

    val code = mutableStateOf("he")
    private val map = mutableStateOf<Map<String, String>>(emptyMap())
    private var customName = ""

    val current: Lang
        get() = LANGS.firstOrNull { it.code == code.value }
            ?: Lang(code.value, customName.ifBlank { code.value.removePrefix("x-") }, customName.ifBlank { code.value.removePrefix("x-") },
                rtl = Prefs.langRtl)

    val rtl: Boolean get() = current.rtl

    fun locale(): Locale = when {
        code.value == "he" -> Locale("he")
        code.value.startsWith("x-") -> Locale.ENGLISH
        else -> Locale(code.value)
    }

    fun init(ctx: Context) {
        customName = Prefs.langName
        if (!load(ctx, Prefs.lang)) { code.value = "he"; map.value = emptyMap() }
    }

    fun tr(he: String): String = if (code.value == "he") he else map.value[he] ?: he

    private fun file(ctx: Context, c: String) = File(ctx.filesDir, "i18n/$c.json")

    private fun parse(text: String): Map<String, String> {
        val o = JSONObject(text)
        return o.keys().asSequence().associateWith { o.optString(it) }
    }

    /** טוען שפה שכבר קיימת בטלפון. false = צריך לתרגם קודם */
    fun load(ctx: Context, c: String): Boolean {
        val m: Map<String, String> = when {
            c == "he" -> emptyMap()
            c == "en" -> runCatching { parse(ctx.assets.open("i18n/en.json").bufferedReader().readText()) }.getOrNull() ?: return false
            // שפה שתורגמה ע"י העוזרת: טקסטים חדשים שעוד לא תורגמו יופיעו באנגלית (ולא בעברית)
            else -> file(ctx, c).takeIf { it.exists() }?.let { f ->
                runCatching {
                    val en = runCatching { parse(ctx.assets.open("i18n/en.json").bufferedReader().readText()) }.getOrDefault(emptyMap())
                    en + parse(f.readText())
                }.getOrNull()
            } ?: return false
        }
        map.value = m
        code.value = c
        return true
    }

    fun isReady(ctx: Context, c: String) = c == "he" || c == "en" || file(ctx, c).exists()

    fun apply(ctx: Context, lang: Lang): Boolean {
        if (!load(ctx, lang.code)) return false
        Prefs.lang = lang.code
        Prefs.langRtl = lang.rtl
        if (lang.code.startsWith("x-")) { customName = lang.name; Prefs.langName = lang.name }
        return true
    }

    /** כל הטקסטים של האפליקציה (המפתחות של קובץ האנגלית) */
    private fun allKeys(ctx: Context): List<String> =
        parse(ctx.assets.open("i18n/en.json").bufferedReader().readText()).keys
            .filter { !it.contains("MMMM") && !it.contains("%,d") }

    /** מתרגם את כל האפליקציה לשפה חדשה בעזרת העוזרת, ושומר בטלפון */
    suspend fun translate(ctx: Context, lang: Lang, progress: (done: Int, total: Int) -> Unit) = withContext(Dispatchers.IO) {
        val keys = allKeys(ctx)
        val en = parse(ctx.assets.open("i18n/en.json").bufferedReader().readText())
        val out = JSONObject()
        val chunks = keys.chunked(70)
        var done = 0
        progress(0, keys.size)
        for (chunk in chunks) {
            val src = JSONObject()
            chunk.forEachIndexed { i, k -> src.put("$i", JSONObject().put("he", k).put("en", en[k] ?: "")) }
            val prompt = """
                Translate the user-interface texts of an Android phone app (dialer, SMS, contacts) into ${lang.english}.
                Each item has the Hebrew original ("he") and an English version ("en"). Translate the meaning naturally and briefly, as a native app would.
                Rules: keep placeholders like {0} {1} exactly; keep emojis, symbols (→ ← • ·), line breaks (\n) and quotes; keep brand names (WhatsApp, Google, SMS, CSV, Excel, Android, Claude).
                Keep the word "מחק" untranslated when it appears inside quotes as something the user must type.
                Return ONLY a JSON object mapping each item number to its translation, e.g. {"0":"...","1":"..."}. No explanations.

                ${src}
            """.trimIndent()
            var parsed: JSONObject? = null
            repeat(2) {
                if (parsed == null) parsed = runCatching {
                    val t = Assistant.complete(prompt)
                    val start = t.indexOf('{'); val end = t.lastIndexOf('}')
                    JSONObject(t.substring(start, end + 1))
                }.getOrNull()
            }
            val p = parsed ?: throw IllegalStateException(tr("התרגום נכשל – נסה שוב"))
            chunk.forEachIndexed { i, k -> p.optString("$i").takeIf { it.isNotBlank() }?.let { out.put(k, it) } }
            done += chunk.size
            progress(done, keys.size)
        }
        val f = file(ctx, lang.code)
        f.parentFile?.mkdirs()
        f.writeText(out.toString())
    }
}

/** תרגום טקסט לשפה שנבחרה. {0}, {1}… מוחלפים בערכים */
fun tr(he: String, vararg args: Any?): String {
    var s = I18n.tr(he)
    args.forEachIndexed { i, v -> s = s.replace("{$i}", v?.toString() ?: "") }
    return s
}
