package com.phonebook.app.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

data class CallerInfo(val name: String, val detail: String, val source: String)

/** זיהוי מספר: ספר אישי ← ספר כללי ← אנשי הקשר של הטלפון */
object CallerId {
    // זיכרון קצר של תוצאות – כדי שרשימות (הודעות, שיחות) ייטענו מיד. מתאפס בכל שינוי באלפון
    private val cache = HashMap<String, CallerInfo?>()
    private var cacheVer = -1

    fun lookup(ctx: Context, number: String): CallerInfo? {
        if (number.isBlank()) return null
        val key = Phone.tail(number).ifEmpty { number.trim() }
        var hit = false
        var cached: CallerInfo? = null
        synchronized(cache) {
            val v = LocalDb.changes.value
            if (v != cacheVer) { cache.clear(); cacheVer = v }
            if (cache.containsKey(key)) { hit = true; cached = cache[key] }
        }
        if (hit) return cached
        val r = lookupNow(ctx, number)
        synchronized(cache) { if (cache.size > 3000) cache.clear(); cache[key] = r }
        return r
    }

    private fun lookupNow(ctx: Context, number: String): CallerInfo? {
        try {
            LocalDb.findByPhone(LocalDb.PERSONAL, number)?.let {
                return CallerInfo(it.name, it.subtitle, "ספר אישי")
            }
            LocalDb.findByPhone(LocalDb.SHARED, number)?.let {
                return CallerInfo(it.name, it.subtitle, "ספר כללי")
            }
        } catch (_: Exception) {
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            try {
                val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
                ctx.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) return CallerInfo(c.getString(0) ?: number, "", "אנשי קשר בטלפון") }
            } catch (_: Exception) {
            }
        }
        return null
    }
}
