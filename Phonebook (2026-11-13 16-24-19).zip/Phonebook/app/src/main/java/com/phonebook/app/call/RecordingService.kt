package com.phonebook.app.call

import com.phonebook.app.ui.tr
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.phonebook.app.App
import com.phonebook.app.R

/**
 * שירות קדמי בזמן הקלטה: בלעדיו אנדרואיד מנתק את המיקרופון כשהמסך כבה
 * (למשל כשמצמידים את הטלפון לאוזן), וההקלטה יוצאת שקטה.
 */
class RecordingService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = NotificationCompat.Builder(this, App.CH_RECORDING)
            .setSmallIcon(R.drawable.ic_stat_phone)
            .setContentTitle(tr("מקליט שיחה"))
            .setContentText(tr("ההקלטה תישמר בסיום השיחה"))
            .setOngoing(true)
            .setContentIntent(
                android.app.PendingIntent.getActivity(
                    this, 7, InCallActivity.intent(this),
                    android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            .build()
        try {
            ServiceCompat.startForeground(
                this, 2001, n,
                if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            )
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    companion object {
        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, RecordingService::class.java))
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, RecordingService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
