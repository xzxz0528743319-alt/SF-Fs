package com.phonebook.app.net

import com.phonebook.app.data.Phone
import com.phonebook.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * זיהוי ספאם בעזרת כל המשתמשים: כל אחד יכול לדווח על מספר מטריד,
 * וכשמספר שדווח ע"י כמה אנשים מתקשר – מוצגת אזהרה (וגם מוקראת בנהיגה).
 */
object SpamCloud {
    /** מכמה דיווחים מציגים אזהרה */
    const val WARN_AT = 2

    private val cache = HashMap<String, Pair<Int, Long>>()

    suspend fun report(number: String, on: Boolean = true) = withContext(Dispatchers.IO) {
        val t = Phone.tail(number)
        if (t.isEmpty()) return@withContext
        if (on) Server.rest(
            "POST", "spam_reports", JSONObject().put("tail", t).toString(),
            mapOf("Prefer" to "resolution=ignore-duplicates,return=minimal")
        ) else Server.rest("DELETE", "spam_reports?tail=eq.$t&reporter=eq.${Prefs.userId}", null, mapOf("Prefer" to "return=minimal"))
        synchronized(cache) { cache.remove(t) }
    }

    /** כמה משתמשים דיווחו על המספר (0 אם אין חיבור). נשמר בזיכרון 10 דקות */
    fun countBlocking(number: String): Int {
        val t = Phone.tail(number)
        if (t.length < 7 || !Prefs.crowdSpam || !Server.loggedIn()) return 0
        synchronized(cache) { cache[t]?.let { (n, at) -> if (System.currentTimeMillis() - at < 600_000) return n } }
        val n = runCatching {
            Server.rest("POST", "rpc/spam_count", JSONObject().put("t", t).toString()).trim().toIntOrNull() ?: 0
        }.getOrDefault(0)
        synchronized(cache) { cache[t] = n to System.currentTimeMillis() }
        return n
    }

    suspend fun count(number: String): Int = withContext(Dispatchers.IO) { countBlocking(number) }
}
