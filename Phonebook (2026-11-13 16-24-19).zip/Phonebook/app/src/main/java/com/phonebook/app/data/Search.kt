package com.phonebook.app.data

/** כלי חיפוש: נרמול עברית וחיפוש לפי מקשים (T9) */
object Search {
    private val finals = mapOf('ך' to 'כ', 'ם' to 'מ', 'ן' to 'נ', 'ף' to 'פ', 'ץ' to 'צ')

    /** נרמול לחיפוש: אותיות סופיות → רגילות, בלי ניקוד, בלי גרשיים, אותיות קטנות */
    fun norm(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s.lowercase()) {
            when {
                ch in '֑'..'ׇ' -> {} // ניקוד וטעמים
                ch == '"' || ch == '\'' || ch == '״' || ch == '׳' || ch == '`' -> {}
                ch == '-' || ch == '_' || ch == ',' || ch == '.' -> sb.append(' ')
                else -> sb.append(finals[ch] ?: ch)
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /** מקלדת טלפון בעברית ובאנגלית */
    private val keys: Map<Char, Char> = buildMap<Char, Char> {
        fun map(d: Char, letters: String) = letters.forEach { put(it, d) }
        map('2', "abcדהו"); map('3', "defאבג"); map('4', "ghiמםנן"); map('5', "jklיכךל")
        map('6', "mnoזחט"); map('7', "pqrsרשת"); map('8', "tuvצץק"); map('9', "wxyzסעפף")
    }

    /** שם ← רצפי מקשים לכל מילה, למשל "כהן משה" ← ["546", "473"] */
    fun t9Words(name: String): List<String> = name.lowercase().split(Regex("\\s+")).mapNotNull { w ->
        val t = w.mapNotNull { keys[it] }.joinToString("")
        t.ifEmpty { null }
    }

    /** האם רצף הספרות מתאים לתחילת אחת המילים בשם */
    fun t9Match(name: String, digits: String): Boolean =
        digits.isNotEmpty() && t9Words(name).any { it.startsWith(digits) }

    /** אותיות לתצוגה מתחת לכל מקש */
    val keyLetters = mapOf(
        '2' to "דהו", '3' to "אבג", '4' to "מנ", '5' to "יכל", '6' to "זחט",
        '7' to "רשת", '8' to "צק", '9' to "סעפ",
    )
}
