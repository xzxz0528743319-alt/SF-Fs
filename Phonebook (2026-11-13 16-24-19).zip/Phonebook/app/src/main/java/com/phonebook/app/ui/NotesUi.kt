package com.phonebook.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Notes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** חלון הערות על מספר: רשימת ההערות (מהחדשה לישנה) + הוספת הערה */
@Composable
fun NotesDialog(number: String, title: String, onDismiss: () -> Unit) {
    var notes by remember { mutableStateOf(Notes.forNumber(number)) }
    var text by remember { mutableStateOf("") }
    val fmt = remember { SimpleDateFormat("d.M.yy HH:mm", Locale.US) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tr("📝 הערות – {0}", title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text, onValueChange = { text = it },
                    placeholder = { Text(tr("מה סיכמתם? מה צריך לעשות?")) },
                    modifier = Modifier.fillMaxWidth(), minLines = 2
                )
                if (notes.isEmpty()) Text(
                    tr("עוד אין הערות. הערה שתכתוב תופיע במסך השיחה בפעם הבאה שהוא יתקשר."),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                notes.forEach { n ->
                    Surface(shape = MaterialTheme.shapes.medium, color = MaterialTheme.colorScheme.surfaceContainerHigh) {
                        Row(Modifier.padding(start = 12.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(n.text)
                                Text(fmt.format(Date(n.at)), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            IconButton(onClick = { Notes.delete(n.id); notes = Notes.forNumber(number) }) {
                                Icon(Icons.Filled.Delete, tr("מחק"), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank(), onClick = { Notes.add(number, text); text = ""; notes = Notes.forNumber(number) }) { Text(tr("שמור הערה")) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("סגור")) } },
    )
}
