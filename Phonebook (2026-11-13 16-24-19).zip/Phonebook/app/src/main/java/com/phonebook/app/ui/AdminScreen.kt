@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.phonebook.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.SharedBook
import kotlinx.coroutines.launch

/** ניהול הספר הכללי – רק למנהלים */
@Composable
fun AdminScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var reload by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<List<SharedBook.Pending>>(emptyList()) }
    var reports by remember { mutableStateOf<List<SharedBook.Report>>(emptyList()) }
    var users by remember { mutableStateOf<List<SharedBook.User>>(emptyList()) }
    var feedback by remember { mutableStateOf<List<SharedBook.Feedback>>(emptyList()) }
    var fbEmail by remember { mutableStateOf(Prefs.feedbackEmail) }
    var confirmDelete by remember { mutableStateOf<Pair<String, String>?>(null) }
    var wipe by remember { mutableIntStateOf(0) }

    LaunchedEffect(tab, reload) {
        busy = true; error = null
        runCatching {
            when (tab) {
                0 -> pending = SharedBook.pending()
                1 -> reports = SharedBook.reports()
                2 -> users = SharedBook.users()
                4 -> {}
                else -> {
                    fbEmail = SharedBook.feedbackEmail().also { Prefs.feedbackEmail = it }
                    feedback = SharedBook.feedbackList()
                }
            }
        }.onFailure { error = it.message ?: tr("שגיאה") }
        busy = false
    }

    fun act(done: String, block: suspend () -> Unit) {
        scope.launch {
            runCatching { block() }
                .onSuccess { toast(ctx, done); reload++ }
                .onFailure { toast(ctx, tr("נכשל: {0}", it.message)) }
        }
    }

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar(tr("ניהול הספר הכללי"), onClose)
        TabRow(selectedTabIndex = tab) {
            listOf(tr("ממתינים"), tr("דיווחים"), tr("משתמשים"), tr("משוב"), tr("ניקוי")).forEachIndexed { i, t ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
            }
        }
        if (!Prefs.isAdmin) {
            EmptyState(tr("אין לך הרשאת מנהל"))
            return@Column
        }
        when {
            busy -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            error != null -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoCard(tr("לא הצלחתי לטעון: {0}\nאם השרת הוקם לפני העדכון – צריך להריץ שוב את קובץ schema.sql.", error))
                Button(onClick = { reload++ }) { Text(tr("נסה שוב")) }
            }
            tab == 0 -> if (pending.isEmpty()) EmptyState(tr("אין רשומות שממתינות לאישור")) else Column {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("{0} רשומות ממתינות", pending.size), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Button(onClick = { act(tr("אושרו {0} רשומות", pending.size)) { SharedBook.approve(pending.map { it.id }) } }) {
                        Text(tr("✅ אשר הכל"))
                    }
                }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(pending, key = { it.id }) { p ->
                        AppCard {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.SemiBold)
                                    Text(ltr(p.phone) + if (p.city.isNotBlank()) " · ${p.city}" else "",
                                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = { act(tr("אושר")) { SharedBook.approve(listOf(p.id)) } }) { Text(tr("אשר")) }
                                TextButton(onClick = { confirmDelete = p.id to p.name }) { Text(tr("מחק"), color = CallRed) }
                            }
                        }
                    }
                }
            }
            tab == 1 -> if (reports.isEmpty()) EmptyState(tr("אין דיווחים פתוחים")) else
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(reports, key = { it.id }) { r ->
                        AppCard {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(r.name.ifBlank { tr("(רשומה שנמחקה)") }, fontWeight = FontWeight.SemiBold)
                                if (r.phone.isNotBlank()) Text(ltr(r.phone), style = MaterialTheme.typography.bodySmall)
                                Text(tr("סיבה: {0}", r.reason), style = MaterialTheme.typography.bodyMedium)
                                Row {
                                    TextButton(onClick = { act(tr("הדיווח נסגר")) { SharedBook.closeReport(r.id) } }) { Text(tr("סגור דיווח")) }
                                    if (r.contactId.isNotBlank() && r.name.isNotBlank())
                                        TextButton(onClick = { confirmDelete = r.contactId to r.name }) { Text(tr("מחק את הרשומה"), color = CallRed) }
                                }
                            }
                        }
                    }
                }
            tab == 4 -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoCard(tr("כאן מוחקים רשומות מהספר הכללי – למשל אם העלית קובץ לא נכון. אחרי המחיקה אפשר לטעון קובץ חדש: ") +
                    tr("בלשונית \"ספר כללי\" לוחצים \"📂 טעינת קובץ\" – והכל נכנס לספר הכללי."))
                OutlinedButton(onClick = { wipe = 1 }, modifier = Modifier.fillMaxWidth()) {
                    Text(tr("🗑️ מחק את כל הרשומות שאני הוספתי"), color = CallRed)
                }
                OutlinedButton(onClick = { wipe = 2 }, modifier = Modifier.fillMaxWidth()) {
                    Text(tr("⚠️ מחק את כל הספר הכללי (של כולם)"), color = CallRed)
                }
                Text(tr("הספר האישי בטלפון לא נפגע."), style = MaterialTheme.typography.bodySmall)
            }
            tab == 3 -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    AppCard {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(tr("לאיזה מייל לשלוח את המשוב?"), fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(
                                fbEmail, { fbEmail = it }, singleLine = true, placeholder = { Text("name@gmail.com") },
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Email),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Button(onClick = {
                                act(tr("נשמר – המשוב יישלח ל-{0}", fbEmail.trim())) { SharedBook.setFeedbackEmail(fbEmail); Prefs.feedbackEmail = fbEmail }
                            }) { Text(tr("שמור")) }
                            Text(tr("כל משוב נשמר גם כאן למטה."), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                if (feedback.isEmpty()) item { Text(tr("עוד לא התקבל משוב"), Modifier.padding(8.dp)) }
                items(feedback, key = { it.id }) { f ->
                    AppCard {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(f.message)
                            Text(ltr(f.created) + if (f.email.isNotBlank()) " · " + ltr(f.email) else "",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            TextButton(onClick = { act(tr("נמחק")) { SharedBook.deleteFeedback(f.id) } }) { Text(tr("מחק"), color = CallRed) }
                        }
                    }
                }
            }
            else -> LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(users, key = { it.id }) { u ->
                    AppCard {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(ltr(u.email.ifBlank { u.id.take(8) }), fontWeight = FontWeight.SemiBold)
                                Text(
                                    (if (u.isAdmin) tr("🛡️ מנהל · ") else "") + (if (u.approved) tr("פעיל") else tr("⛔ חסום")),
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (u.id != Prefs.userId) {
                                TextButton(onClick = {
                                    act(if (u.approved) tr("המשתמש נחסם") else tr("המשתמש אושר")) { SharedBook.setUser(u.id, approved = !u.approved) }
                                }) { Text(if (u.approved) tr("חסום") else tr("אשר")) }
                                TextButton(onClick = {
                                    act(if (u.isAdmin) tr("הוסר ממנהלים") else tr("נוסף כמנהל")) { SharedBook.setUser(u.id, admin = !u.isAdmin) }
                                }) { Text(if (u.isAdmin) tr("הסר ניהול") else tr("הפוך למנהל")) }
                            } else Text(tr("זה אתה"), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    if (wipe != 0) {
        var typed by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { wipe = 0 },
            title = { Text(if (wipe == 1) tr("למחוק את כל מה שהוספת?") else tr("למחוק את כל הספר הכללי?")) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (wipe == 1) tr("כל הרשומות שאתה הוספת לספר הכללי יימחקו אצל כל המשתמשים.")
                        else tr("כל הרשומות בספר הכללי יימחקו אצל כל המשתמשים. אי אפשר לבטל.")
                    )
                    Text(tr("כדי לאשר, כתוב: מחק"))
                    OutlinedTextField(typed, { typed = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                TextButton(enabled = typed.trim() == "מחק", onClick = {
                    val all = wipe == 2
                    wipe = 0
                    act(tr("נמחק")) {
                        val n = if (all) SharedBook.deleteAll() else SharedBook.deleteMine()
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { toast(ctx, tr("נמחקו {0} רשומות מהספר הכללי", n)) }
                    }
                }) { Text(tr("מחק"), color = CallRed) }
            },
            dismissButton = { TextButton(onClick = { wipe = 0 }) { Text(tr("ביטול")) } },
        )
    }

    confirmDelete?.let { (id, name) ->
        ConfirmDialog(tr("למחוק את \"{0}\"?", name), tr("הרשומה תוסר מהספר הכללי אצל כולם."), tr("מחק"), onDismiss = { confirmDelete = null }) {
            confirmDelete = null
            act(tr("נמחק")) { SharedBook.delete(id) }
        }
    }
}
