package com.phonebook.app.data

/**
 * זיהוי הודעות ספאם והונאה – בטלפון בלבד, בלי לשלוח הודעות לשום מקום.
 * הודעה ממי שנמצא באלפון לא נחשבת ספאם (אלא אם המשתמש סימן אותו).
 * המשתמש יכול לסמן "ספאם" / "לא ספאם", והסימון גובר על הזיהוי האוטומטי.
 */
object Spam {
    enum class Kind { NONE, SPAM, SCAM }

    private val AD = listOf("פרסומת", "פירסומת")
    private val REMOVE = listOf("להסרה", "הסרה", "הסר ", "להסיר", "השב הסר", "לביטול קבלת", "stop", "unsubscribe")
    private val MONEY = listOf(
        "זכית", "זכייה", "זכיה", "הגרלה", "פרס", "מתנה", "הלוואה", "הלוואות", "אשראי", "ללא ריבית", "משכנתא",
        "השקעה", "השקעות", "ביטקוין", "קריפטו", "מבצע", "הנחה", "% הנחה", "בלעדי", "הצעה מיוחדת", "קזינו", "הימור",
        "חינם", "רק היום", "ממתין לך", "ממתינה לך", "קופון", "שובר",
    )
    private val SCAM = listOf(
        "חביל", "משלוח", "דואר ישראל", "מכס", "עדכן פרטים", "עדכני פרטים", "עדכון פרטים", "אמת את", "אימות חשבון",
        "החשבון שלך", "חשבונך", "נחסם", "הושעה", "תשלום נכשל", "קנס", "כרטיס האשראי", "פרטי אשראי",
        "דמי משלוח", "ביטוח לאומי", "רשות המסים", "החזר מס",
    )
    private val OTP = listOf("קוד אימות", "קוד האימות", "הקוד שלך", "קוד הכניסה", "קוד לכניסה", "קוד חד פעמי", "קוד הזיהוי", "סיסמה חד", "verification code", "your code", "קוד:")
    private val LINK = Regex("(https?://|www\\.|\\b[a-z0-9-]+\\.(ly|co|cc|me|link|site|top|xyz|info|shop|click|icu|online)\\b/?)", RegexOption.IGNORE_CASE)
    private val SHORT = Regex("(bit\\.ly|tinyurl|t\\.co/|goo\\.gl|cutt\\.ly|rb\\.gy|is\\.gd|ow\\.ly|tiny\\.cc|shorturl)", RegexOption.IGNORE_CASE)

    /** מפתח לשולח: 9 ספרות אחרונות למספר, או השם (שולח עם אותיות) */
    fun key(address: String): String = Phone.tail(address).ifEmpty { address.trim().lowercase() }

    fun isMarked(address: String) = key(address) in Prefs.spamMarked()
    fun isTrusted(address: String) = key(address) in Prefs.spamTrusted()

    fun mark(address: String, spam: Boolean) = Prefs.setSpamMark(key(address), spam)

    /** בודק הודעה. known = השולח נמצא באלפון */
    fun check(address: String, body: String, known: Boolean): Kind {
        if (!Prefs.spamFilter) return if (isMarked(address)) Kind.SPAM else Kind.NONE
        if (isMarked(address)) return Kind.SPAM
        if (known || isTrusted(address)) return Kind.NONE
        val b = body.lowercase()
        val link = LINK.containsMatchIn(b)
        // קוד אימות בלי קישור – הודעה חשובה, לא ספאם
        if (!link && OTP.any { b.contains(it) }) return Kind.NONE

        var score = 0
        if (AD.any { b.contains(it) }) score += 3
        if (REMOVE.any { b.contains(it) }) score += 2
        if (link) score += 1
        if (SHORT.containsMatchIn(b)) score += 2
        score += minOf(3, MONEY.count { b.contains(it) })
        val scamWords = SCAM.count { b.contains(it) }
        val numeric = Phone.digits(address).length >= 7
        if (link && numeric) score += 1

        // קישור + מילים של חבילה / חשבון / תשלום ממספר לא מוכר = חשד להונאה
        if (link && scamWords > 0 && (numeric || SHORT.containsMatchIn(b))) return Kind.SCAM
        return if (score >= 3) Kind.SPAM else Kind.NONE
    }
}
