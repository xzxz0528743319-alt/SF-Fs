package com.phonebook.app.data

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/**
 * קורא קבצי אקסל (xlsx) בלי ספריות חיצוניות.
 * מחזיר את הגיליון הראשון כטבלה של שורות ותאים (טקסט), או null אם זה לא קובץ אקסל.
 */
object Xlsx {
    fun read(bytes: ByteArray): List<List<String>>? {
        val files = HashMap<String, String>()
        try {
            ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val n = e.name
                    if (n == "xl/sharedStrings.xml" || n == "xl/workbook.xml" || n == "xl/_rels/workbook.xml.rels" ||
                        (n.startsWith("xl/worksheets/") && n.endsWith(".xml"))
                    ) files[n] = z.readBytes().toString(Charsets.UTF_8)
                    e = z.nextEntry
                }
            }
        } catch (_: Exception) {
            return null
        }
        val sheets = files.keys.filter { it.startsWith("xl/worksheets/") && !it.contains("_rels") }
        if (sheets.isEmpty()) return null

        // הגיליון הראשון לפי סדר החוברת
        val sheetPath = firstSheetPath(files) ?: sheets.minWith(compareBy({ it.length }, { it }))
        val sheet = files[sheetPath] ?: return null

        val shared = files["xl/sharedStrings.xml"]?.let { xml ->
            Regex("<si>(.*?)</si>", RegexOption.DOT_MATCHES_ALL).findAll(xml).map { si ->
                Regex("<t[^>]*>(.*?)</t>", RegexOption.DOT_MATCHES_ALL).findAll(si.groupValues[1])
                    .joinToString("") { unescape(it.groupValues[1]) }
            }.toList()
        } ?: emptyList()

        val rows = mutableListOf<List<String>>()
        Regex("<row\\b[^>]*>(.*?)</row>", RegexOption.DOT_MATCHES_ALL).findAll(sheet).forEach { row ->
            val cells = sortedMapOf<Int, String>()
            var next = 0
            Regex("<c\\b([^>]*?)(?:/>|>(.*?)</c>)", RegexOption.DOT_MATCHES_ALL).findAll(row.groupValues[1]).forEach { c ->
                val attrs = c.groupValues[1]
                val inner = c.groupValues[2]
                val ref = Regex("\\br=\"([A-Z]+)\\d+\"").find(attrs)?.groupValues?.get(1)
                val col = ref?.let { colIndex(it) } ?: next
                next = col + 1
                val type = Regex("\\bt=\"(\\w+)\"").find(attrs)?.groupValues?.get(1)
                val v = Regex("<v>(.*?)</v>", RegexOption.DOT_MATCHES_ALL).find(inner)?.groupValues?.get(1)
                val text = when (type) {
                    "s" -> v?.trim()?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                    "inlineStr" -> Regex("<t[^>]*>(.*?)</t>", RegexOption.DOT_MATCHES_ALL).findAll(inner)
                        .joinToString("") { unescape(it.groupValues[1]) }
                    else -> unescape(v ?: "")
                }
                cells[col] = text
            }
            if (cells.isNotEmpty()) {
                val max = cells.lastKey()
                rows += (0..max).map { cells[it] ?: "" }
            }
        }
        return rows
    }

    private fun firstSheetPath(files: Map<String, String>): String? {
        val wb = files["xl/workbook.xml"] ?: return null
        val rels = files["xl/_rels/workbook.xml.rels"] ?: return null
        val rid = Regex("<sheet\\b[^>]*r:id=\"([^\"]+)\"").find(wb)?.groupValues?.get(1) ?: return null
        val target = Regex("<Relationship\\b[^>]*Id=\"$rid\"[^>]*Target=\"([^\"]+)\"").find(rels)?.groupValues?.get(1)
            ?: Regex("<Relationship\\b[^>]*Target=\"([^\"]+)\"[^>]*Id=\"$rid\"").find(rels)?.groupValues?.get(1)
            ?: return null
        val path = if (target.startsWith("/")) target.removePrefix("/") else "xl/" + target.removePrefix("./")
        return path.takeIf { it in files }
    }

    private fun colIndex(letters: String): Int {
        var n = 0
        for (ch in letters) n = n * 26 + (ch - 'A' + 1)
        return n - 1
    }

    private fun unescape(s: String): String = s
        .replace(Regex("&#(\\d+);")) { it.groupValues[1].toIntOrNull()?.let { c -> String(Character.toChars(c)) } ?: it.value }
        .replace(Regex("&#x([0-9a-fA-F]+);")) { it.groupValues[1].toIntOrNull(16)?.let { c -> String(Character.toChars(c)) } ?: it.value }
        .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
}
