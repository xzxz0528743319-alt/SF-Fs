package com.phonebook.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import com.phonebook.app.MainActivity
import com.phonebook.app.R
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.LogKind
import com.phonebook.app.data.LogRepo
import com.phonebook.app.data.Phone
import com.phonebook.app.data.Prefs
import com.phonebook.app.ui.tr

/**
 * ווידג'ט למסך הבית: 4 אנשים בלחיצה אחת.
 * קודם המועדפים (⭐), ואם אין מספיק – מי שהכי הרבה מדברים איתו לאחרונה (מתמלא לבד, בלי הגדרות).
 * למעלה: חייגן ועוזרת בדיבור.
 */
class FavoritesWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val app = ctx.applicationContext
        val pending = goAsync()
        Thread {
            try { draw(app, mgr, ids) } catch (_: Exception) { } finally { pending.finish() }
        }.start()
    }

    companion object {
        private val IDS = intArrayOf(R.id.fav1, R.id.fav2, R.id.fav3, R.id.fav4)

        /** מרענן את כל הווידג'טים (נקרא כשיוצאים מהאפליקציה) */
        fun refresh(ctx: Context) {
            val app = ctx.applicationContext
            Thread {
                runCatching {
                    val mgr = AppWidgetManager.getInstance(app)
                    val ids = mgr.getAppWidgetIds(ComponentName(app, FavoritesWidget::class.java))
                    if (ids.isNotEmpty()) draw(app, mgr, ids)
                }
            }.start()
        }

        /** (שם, מספר) – עד 4 */
        private fun people(ctx: Context): List<Pair<String, String>> {
            val out = mutableListOf<Pair<String, String>>()
            val seen = HashSet<String>()
            Prefs.favoriteTails().mapNotNull { LocalDb.findAny(it) }.sortedBy { it.name }.forEach { c ->
                val t = Phone.tail(c.phone)
                if (t.isNotEmpty() && seen.add(t) && out.size < 4) out += c.name to c.phone
            }
            if (out.size < 4) {
                // הכי הרבה שיחות (שנענו או יוצאות) בחודש האחרון
                val since = System.currentTimeMillis() - 30L * 24 * 3600 * 1000
                runCatching { LogRepo.load(ctx, 0) }.getOrDefault(emptyList())
                    .filter { it.date > since && it.number.isNotBlank() && (it.kind == LogKind.OUT || (it.kind == LogKind.IN && it.duration > 0)) }
                    .groupBy { Phone.tail(it.number) }
                    .filterKeys { it.isNotEmpty() && it !in seen }
                    .entries.sortedByDescending { it.value.size }
                    .forEach { (t, list) ->
                        if (out.size < 4 && seen.add(t)) {
                            val first = list.first()
                            out += (first.name ?: LocalDb.findAny(first.number)?.name ?: first.number) to first.number
                        }
                    }
            }
            return out
        }

        private fun draw(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
            val list = people(ctx)
            val v = RemoteViews(ctx.packageName, R.layout.widget_favorites)
            v.setTextViewText(R.id.w_title, tr("⭐ חיוג מהיר"))
            v.setOnClickPendingIntent(
                R.id.w_dial, PendingIntent.getActivity(
                    ctx, 7101, Intent(Intent.ACTION_DIAL).setClass(ctx, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            v.setOnClickPendingIntent(
                R.id.w_mic, PendingIntent.getActivity(
                    ctx, 7102, Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_ASSISTANT_TALK, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            IDS.forEachIndexed { i, id ->
                val p = list.getOrNull(i)
                if (p == null) {
                    if (i == 0) {
                        v.setViewVisibility(id, View.VISIBLE)
                        v.setTextViewText(id, tr("סמן ⭐ אנשי קשר באפליקציה – והם יופיעו כאן"))
                    } else v.setViewVisibility(id, View.INVISIBLE)
                    return@forEachIndexed
                }
                v.setViewVisibility(id, View.VISIBLE)
                v.setTextViewText(id, "📞 " + p.first)
                v.setOnClickPendingIntent(
                    id, PendingIntent.getActivity(
                        ctx, 7110 + i,
                        Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", p.second, null)).setClass(ctx, MainActivity::class.java)
                            .putExtra(MainActivity.EXTRA_CALL_NOW, true)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                )
            }
            mgr.updateAppWidget(ids, v)
        }
    }
}
