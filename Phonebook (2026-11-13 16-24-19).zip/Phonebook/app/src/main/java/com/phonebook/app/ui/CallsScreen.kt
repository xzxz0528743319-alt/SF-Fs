@file:OptIn(ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import android.provider.CallLog
import android.provider.Telephony
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import kotlinx.coroutines.launch
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.phonebook.app.data.Blocking
import com.phonebook.app.data.CallLogEdit
import com.phonebook.app.data.CallerId
import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.LogItem
import com.phonebook.app.data.LogKind
import com.phonebook.app.data.LogRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------------- יומן שיחות ----------------

@Composable
fun CallsScreen(onCall: (String) -> Unit, onSms: (String) -> Unit, onAddContact: (String) -> Unit) {
    val ctx = LocalContext.current
    val version = rememberProviderVersion(CallLog.Calls.CONTENT_URI)
    val dbv by LocalDb.changes.collectAsState()
    val items by produceState<List<LogItem>?>(null, version, dbv) {
        value = withContext(Dispatchers.IO) { LogRepo.load(ctx, 0) }
    }
    var chosen by remember { mutableStateOf<LogItem?>(null) }
    var query by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(Unit) { com.phonebook.app.call.MissedCalls.cancel(ctx) }
    val flags by com.phonebook.app.data.Prefs.flags.collectAsState()
    val favorites by produceState(emptyList<com.phonebook.app.data.Contact>(), dbv, flags) {
        value = withContext(Dispatchers.IO) {
            com.phonebook.app.data.Prefs.favoriteTails().mapNotNull { LocalDb.findAny(it) }.sortedBy { it.name }
        }
    }

    // אזהרה כשהאפליקציה לא מוגדרת כאפליקציית הטלפון – אז מסך השיחה של סמסונג פועל במקום שלנו
    val rm = remember { ctx.getSystemService(android.app.role.RoleManager::class.java) }
    var roleTick by remember { mutableIntStateOf(0) }
    val isDialer = remember(roleTick, version) { rm.isRoleHeld(android.app.role.RoleManager.ROLE_DIALER) }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { roleTick++ }

    val list = items?.let { all ->
        val q = query.trim()
        if (q.isEmpty()) all else {
            val qd = com.phonebook.app.data.Phone.digits(q)
            val qn = com.phonebook.app.data.Search.norm(q)
            all.filter { (qd.length >= 2 && com.phonebook.app.data.Phone.digits(it.number).contains(qd)) || (it.name != null && com.phonebook.app.data.Search.norm(it.name).contains(qn)) }
        }
    }
    Column(Modifier.fillMaxSize()) {
    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        placeholder = { Text(tr("חיפוש ביומן לפי שם או מספר")) },
        leadingIcon = { Icon(Icons.Filled.Search, null) },
        trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, tr("נקה")) } },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
        ),
        modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp)
    )
    if (query.isBlank() && favorites.isNotEmpty()) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            favorites.forEach { c ->
                Column(
                    Modifier.width(68.dp).clip(RoundedCornerShape(14.dp)).clickable { onCall(c.phone) }.padding(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box {
                        Avatar(c.name, 50.dp)
                        Text("⭐", fontSize = 12.sp, modifier = Modifier.align(Alignment.BottomEnd))
                    }
                    Text(c.name.split(" ").take(2).joinToString(" "), fontSize = 12.sp, maxLines = 2, lineHeight = 14.sp, textAlign = TextAlign.Center)
                }
            }
        }
    }
    if (!isDialer) {
        Surface(color = CallRed.copy(alpha = 0.12f), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().padding(12.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("האפליקציה לא מוגדרת כאפליקציית הטלפון, ולכן מסך השיחה שלה לא מופיע."), fontWeight = FontWeight.SemiBold)
                Button(onClick = { roleLauncher.launch(rm.createRequestRoleIntent(android.app.role.RoleManager.ROLE_DIALER)) }) {
                    Text(tr("הגדר כאפליקציית הטלפון"))
                }
            }
        }
    }
    when {
        list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        list.isEmpty() -> EmptyState(if (query.isBlank()) tr("אין שיחות") else tr("לא נמצאו שיחות"))
        else -> LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp)) {
            list.groupBy { dayLabel(it.date) }.forEach { (day, group) ->
                item(key = "h_$day") { SectionHeader(day) }
                item(key = "g_$day") {
                    AppCard {
                        group.forEachIndexed { idx, it ->
                            LogRow(it, onCall, onSms) { chosen = it }
                            if (idx < group.lastIndex) HorizontalDivider(
                                Modifier.padding(start = 68.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                        }
                    }
                }
            }
        }
    }
    }

    val clipboard = LocalClipboardManager.current
    var confirmDelete by remember { mutableStateOf<LogItem?>(null) }
    var notesFor by remember { mutableStateOf<LogItem?>(null) }
    val spamScope = rememberCoroutineScope()
    notesFor?.let { item -> NotesDialog(item.number, item.name ?: ltr(item.number)) { notesFor = null } }
    chosen?.let { item ->
        val known = item.name != null
        val blocked = remember(item.number) { Blocking.isBlocked(ctx, item.number) }
        NumberActions(
            item,
            onDismiss = { chosen = null },
            onCall = { chosen = null; onCall(item.number) },
            onSms = { chosen = null; onSms(item.number) },
            onWhatsapp = { chosen = null; Actions.whatsapp(ctx, item.number) },
        ) {
            if (!known) ActionLine(Icons.Filled.PersonAdd, tr("הוסף לספר האישי"), Brand) { chosen = null; onAddContact(item.number) }
            ActionLine(Icons.Filled.ContentCopy, tr("העתק מספר"), MaterialTheme.colorScheme.onSurfaceVariant) {
                clipboard.setText(AnnotatedString(item.number)); toast(ctx, tr("המספר הועתק")); chosen = null
            }
            val lastNote = remember(item.number) { com.phonebook.app.data.Notes.last(item.number) }
            ActionLine(Icons.Filled.EditNote, lastNote?.let { tr("📝 הערות ({0})", it.text.take(40)) } ?: tr("📝 הוסף הערה"), Brand) {
                notesFor = item; chosen = null
            }
            ActionLine(Icons.Filled.Alarm, tr("⏰ הזכר לי להתקשר בעוד שעה"), Brand) {
                com.phonebook.app.drive.Reminders.schedule(ctx, item.number, 60)
                toast(ctx, tr("אזכיר לך להתקשר בעוד {0} דקות", 60)); chosen = null
            }
            if (!known) ActionLine(Icons.Filled.Report, tr("🚩 דווח כספאם (עוזר לכל המשתמשים)"), CallRed) {
                chosen = null
                spamScope.launch {
                    runCatching { com.phonebook.app.net.SpamCloud.report(item.number) }
                        .onSuccess { toast(ctx, tr("תודה! הדיווח עוזר להזהיר את כולם")) }
                        .onFailure { toast(ctx, tr("כדי לדווח צריך להתחבר בהגדרות")) }
                }
            }
            ActionLine(Icons.Filled.Block, if (blocked) tr("בטל חסימה") else tr("חסום מספר"), CallRed) {
                val ok = if (blocked) Blocking.unblock(ctx, item.number) else Blocking.block(ctx, item.number)
                toast(ctx, if (!ok) tr("לא ניתן לחסום – צריך להגדיר את האפליקציה כברירת מחדל") else if (blocked) tr("החסימה בוטלה") else tr("המספר נחסם"))
                chosen = null
            }
            ActionLine(Icons.Filled.Delete, tr("מחק מיומן השיחות"), CallRed) { confirmDelete = item; chosen = null }
        }
    }
    confirmDelete?.let { item ->
        ConfirmDialog(tr("למחוק מהיומן?"), tr("כל השיחות עם המספר הזה יימחקו מיומן השיחות."), tr("מחק"), onDismiss = { confirmDelete = null }) {
            confirmDelete = null
            toast(ctx, if (CallLogEdit.deleteNumber(ctx, item.number)) tr("נמחק מהיומן") else tr("לא ניתן למחוק – אשר את ההרשאות בהגדרות"))
        }
    }
}

/** חלון קטן שנפתח בלחיצה על מספר ביומן: חיוג, הודעות עם המספר, וואטסאפ */
@Composable
private fun NumberActions(
    item: LogItem, onDismiss: () -> Unit, onCall: () -> Unit, onSms: () -> Unit, onWhatsapp: () -> Unit,
    more: @Composable ColumnScope.() -> Unit = {},
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text(tr("סגור")) } },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(item.name ?: item.number, 48.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(item.name ?: ltr(item.number), fontWeight = FontWeight.Bold)
                    if (item.name != null) Text(
                        ltr(item.number), style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                ActionLine(Icons.Filled.Call, tr("התקשר"), CallGreen, onCall)
                ActionLine(Icons.Filled.Sms, tr("הודעות עם המספר הזה"), Brand, onSms)
                ActionLine(Icons.Filled.Chat, tr("וואטסאפ"), Color(0xFF25D366), onWhatsapp)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                more()
            }
        },
        shape = MaterialTheme.shapes.large,
    )
}

@Composable
private fun ActionLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(color.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = color) }
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun LogRow(it: LogItem, onCall: (String) -> Unit, onSms: (String) -> Unit, onOpen: () -> Unit) {
    val isSms = it.kind == LogKind.SMS_IN || it.kind == LogKind.SMS_OUT
    val title = it.name ?: if (it.number.isBlank()) tr("מספר חסוי") else ltr(it.number)
    val missed = it.kind == LogKind.MISSED
    val (icon, tint, what) = when (it.kind) {
        LogKind.IN -> Triple(Icons.Filled.CallReceived, CallGreen, tr("נכנסת"))
        LogKind.OUT -> Triple(Icons.Filled.CallMade, Brand, tr("יוצאת"))
        LogKind.MISSED -> Triple(Icons.Filled.CallMissed, CallRed, tr("שיחה שלא נענתה"))
        LogKind.REJECTED -> Triple(Icons.Filled.Block, CallRed, tr("נדחתה"))
        LogKind.SMS_IN -> Triple(Icons.Filled.Sms, Brand, "")
        LogKind.SMS_OUT -> Triple(Icons.Filled.Sms, MaterialTheme.colorScheme.onSurfaceVariant, tr("נשלחה: "))
    }
    val subtitle = when {
        isSms -> what + (it.snippet ?: "").replace('\n', ' ')
        it.duration > 0 -> "$what · ${formatDuration(it.duration)}"
        else -> what
    } + (it.sim?.let { s -> " · $s" } ?: "")
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = it.number.isNotBlank(), onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(it.name ?: it.number)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (missed) CallRed else MaterialTheme.colorScheme.onSurface
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = tint, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Text(timeLabel(it.date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(end = 2.dp))
        if (it.number.isNotBlank()) {
            IconButton(onClick = { onSms(it.number) }) {
                Icon(Icons.Filled.Sms, tr("הודעות"), tint = Lavender)
            }
            IconButton(onClick = { onCall(it.number) }) {
                Icon(Icons.Filled.Call, tr("התקשר"), tint = CallGreen)
            }
        }
    }
}

// ---------------- חייגן ----------------

@Composable
fun DialerScreen(initial: String, onClose: () -> Unit, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    var number by rememberSaveable { mutableStateOf(initial) }
    val dbv by LocalDb.changes.collectAsState()
    // כל אנשי הקשר בזיכרון – לחיפוש לפי אותיות במקשים (T9)
    val everyone by produceState(emptyList<Contact>(), dbv) {
        value = withContext(Dispatchers.IO) { LocalDb.all(LocalDb.PERSONAL) + LocalDb.all(LocalDb.SHARED) }
    }
    val matches by produceState(emptyList<Contact>(), number, everyone) {
        value = if (number.length < 2) emptyList() else withContext(Dispatchers.IO) {
            val byNumber = LocalDb.search(LocalDb.PERSONAL, number, 0, null, 5) + LocalDb.search(LocalDb.SHARED, number, 0, null, 10)
            val digits = number.filter { it.isDigit() }
            val byName = if (digits.length == number.length) everyone.asSequence()
                .filter { com.phonebook.app.data.Search.t9Match(it.name, digits) }.take(15).toList() else emptyList()
            (byName + byNumber).distinctBy { it.phone }.take(15)
        }
    }
    val sims = remember { com.phonebook.app.call.Sims.list(ctx) }
    val known by produceState<String?>(null, number, dbv) {
        value = if (number.length < 7) null else withContext(Dispatchers.IO) { CallerId.lookup(ctx, number)?.name }
    }

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar(tr("חייגן"), onClose)
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            items(matches, key = { it.id }) { c ->
                Row(
                    Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).clickable { number = c.phone }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(c.name, 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(ltr(c.phone), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { onCall(c.phone) }) { Icon(Icons.Filled.Call, tr("התקשר"), tint = CallGreen) }
                }
            }
        }
        Text(
            ltr(number), fontSize = 34.sp, textAlign = TextAlign.Center, maxLines = 1,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        Text(
            known ?: " ", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        )
        Keypad(onKey = { number += it }, onPlus = { number += "+" })
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.size(56.dp))
            if (sims.size >= 2) {
                // שני כרטיסי SIM – כפתור חיוג לכל אחד
                sims.take(2).forEach { sim ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.size(64.dp).clip(CircleShape).background(CallGreen).clickable(enabled = number.isNotBlank()) {
                                onClose(); Actions.call(ctx, number, sim.handle)
                            },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Call, tr("חייג"), tint = Color.White, modifier = Modifier.size(24.dp))
                                Text("${sim.slot}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            }
                        }
                        Text(sim.carrier.ifBlank { "SIM ${sim.slot}" }, fontSize = 11.sp, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else Box(
                Modifier.size(72.dp).clip(CircleShape).background(CallGreen).clickable(enabled = number.isNotBlank()) { onCall(number) },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Call, tr("חייג"), tint = Color.White, modifier = Modifier.size(32.dp)) }
            Box(
                Modifier.size(56.dp).clip(CircleShape).pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { number = number.dropLast(1) },
                        onLongPress = { number = "" },
                    )
                },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Backspace, tr("מחק"), tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun Keypad(onKey: (String) -> Unit, onPlus: () -> Unit) {
    val keys = listOf(
        "1" to "", "2" to tr("דהו ABC"), "3" to tr("אבג DEF"),
        "4" to tr("מנ GHI"), "5" to tr("יכל JKL"), "6" to tr("זחט MNO"),
        "7" to tr("רשת PQRS"), "8" to tr("צק TUV"), "9" to tr("סעפ WXYZ"),
        "*" to "", "0" to "+", "#" to "",
    )
    val key by rememberUpdatedState(onKey)
    val plus by rememberUpdatedState(onPlus)
    // מקלדת מספרים תמיד משמאל לימין
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            keys.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    row.forEach { (d, sub) ->
                        Box(
                            Modifier
                                .size(74.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                .pointerInput(d) {
                                    detectTapGestures(
                                        onTap = { key(d) },
                                        onLongPress = { if (d == "0") plus() else key(d) },
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(d, fontSize = 28.sp)
                                if (sub.isNotEmpty()) Text(sub, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
