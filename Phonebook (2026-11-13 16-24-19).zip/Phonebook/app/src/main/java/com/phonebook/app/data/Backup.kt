package com.phonebook.app.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.time.LocalDate

/**
 * גיבוי אוטומטי של הספר האישי לקובץ CSV בתיקיית ההורדות (Download/ספר טלפונים).
 * נשמרים 5 הגיבויים האחרונים. בנוסף, אנדרואיד מגבה את נתוני האפליקציה לחשבון גוגל.
 */
object Backup {
    private const val KEEP = 5
    private const val WEEK = 7L * 24 * 3600 * 1000
    val folder = Environment.DIRECTORY_DOWNLOADS + "/ספר טלפונים"

    /** גיבוי עכשיו. מחזיר את מספר אנשי הקשר שגובו */
    fun backupNow(ctx: Context): Int {
        val (text, n) = ImportExport.csvText(includeShared = false)
        if (n == 0) return 0
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "גיבוי ספר טלפונים ${LocalDate.now()}.csv")
            put(MediaStore.Downloads.MIME_TYPE, "text/csv")
            put(MediaStore.Downloads.RELATIVE_PATH, folder)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: error(com.phonebook.app.ui.tr("לא ניתן ליצור קובץ גיבוי"))
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
        Prefs.lastBackup = System.currentTimeMillis()
        pruneOld(ctx)
        return n
    }

    /** גיבוי אוטומטי אם עבר שבוע מהגיבוי הקודם */
    fun autoIfDue(ctx: Context) {
        if (!Prefs.autoBackup) return
        if (System.currentTimeMillis() - Prefs.lastBackup < WEEK) return
        try {
            if (LocalDb.count(LocalDb.PERSONAL) > 0) backupNow(ctx)
        } catch (_: Exception) {
        }
    }

    private fun pruneOld(ctx: Context) {
        try {
            val files = mutableListOf<Pair<Long, Long>>() // id, date
            ctx.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DATE_ADDED),
                "${MediaStore.Downloads.RELATIVE_PATH} LIKE ? AND ${MediaStore.Downloads.DISPLAY_NAME} LIKE ?",
                arrayOf("%ספר טלפונים%", "גיבוי ספר טלפונים%"), null
            )?.use { c -> while (c.moveToNext()) files += c.getLong(0) to c.getLong(1) }
            files.sortedByDescending { it.second }.drop(KEEP).forEach { (id, _) ->
                ctx.contentResolver.delete(ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id), null, null)
            }
        } catch (_: Exception) {
        }
    }
}
