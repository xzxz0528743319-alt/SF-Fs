@file:OptIn(ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.phonebook.app.MainActivity
import com.phonebook.app.data.Contact
import com.phonebook.app.data.Prefs
import com.phonebook.app.data.ImportExport
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

enum class HomeTab(val label: String, val title: String, val icon: ImageVector) {
    Calls("שיחות", "שיחות", Icons.Filled.Call),
    Messages("הודעות", "הודעות", Icons.Filled.Chat),
    General("ספר כללי", "📒 ספר כללי", Icons.Filled.Contacts),
    Personal("ספר אישי", "📒 ספר אישי", Icons.Filled.Person),
    Assistant("עוזרת", "עוזרת AI", Icons.Filled.AutoAwesome),
}

sealed interface Overlay {
    data class Dialer(val number: String = "") : Overlay
    data class Conversation(val address: String, val draft: String = "") : Overlay
    data class NewMessage(val draft: String = "") : Overlay
    data object Settings : Overlay
    data object Trash : Overlay
    data object Admin : Overlay
    data class EditContact(val contact: Contact?, val shared: Boolean) : Overlay
}

private fun overlayFor(i: Intent): Overlay? {
    i.getStringExtra(MainActivity.EXTRA_OPEN_SMS)?.let { return Overlay.Conversation(it) }
    val data = i.data
    val scheme = data?.scheme?.lowercase()
    return when {
        (i.action == Intent.ACTION_DIAL || i.action == Intent.ACTION_VIEW) && scheme == "tel" ->
            Overlay.Dialer(Uri.decode(data.schemeSpecificPart ?: ""))
        i.action == Intent.ACTION_DIAL -> Overlay.Dialer()
        (i.action == Intent.ACTION_SENDTO || i.action == Intent.ACTION_SEND) && scheme in listOf("sms", "smsto", "mms", "mmsto") -> {
            val to = Uri.decode(data?.schemeSpecificPart?.substringBefore('?') ?: "").split(',', ';').first().trim()
            val body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            if (to.isBlank()) Overlay.NewMessage(body) else Overlay.Conversation(to, body)
        }
        else -> null
    }
}

@Composable
fun AppRoot(launch: Intent?, onConsumed: () -> Unit) {
    var setupDone by remember { mutableStateOf(Prefs.setupDone) }
    if (!setupDone) {
        SetupScreen(onDone = { Prefs.setupDone = true; setupDone = true })
        return
    }

    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableStateOf(HomeTab.Calls) }
    var overlay by remember { mutableStateOf<Overlay?>(null) }

    LaunchedEffect(launch) {
        val i = launch ?: return@LaunchedEffect
        if (i.getBooleanExtra(MainActivity.EXTRA_OPEN_CALLS, false)) tab = HomeTab.Calls
        if (i.getBooleanExtra(MainActivity.EXTRA_ASSISTANT_VOICE, false)) {
            overlay = null
            tab = HomeTab.Assistant
            AssistantBus.voice.value = AssistantBus.voice.value + 1
            onConsumed()
            return@LaunchedEffect
        }
        if (i.getBooleanExtra(MainActivity.EXTRA_ASSISTANT_TALK, false)) {
            overlay = null
            tab = HomeTab.Assistant
            AssistantBus.talk.value = AssistantBus.talk.value + 1
            onConsumed()
            return@LaunchedEffect
        }
        if (i.getBooleanExtra(MainActivity.EXTRA_CALL_NOW, false) && i.data?.scheme == "tel") {
            Actions.call(ctx, Uri.decode(i.data?.schemeSpecificPart ?: ""))
            onConsumed()
            return@LaunchedEffect
        }
        overlayFor(i)?.let {
            overlay = it
            if (it is Overlay.Conversation) tab = HomeTab.Messages
        }
        onConsumed()
    }

    val scope = rememberCoroutineScope()
    var importing by remember { mutableStateOf(false) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            importing = true
            runCatching { ImportExport.import(ctx, uri, toShared = tab == HomeTab.General) }
                .onSuccess { r ->
                    val parts = mutableListOf(tr("נוספו {0} לספר האישי", r.personal))
                    if (r.shared > 0) parts += tr("{0} לספר הכללי", r.shared)
                    if (r.duplicates > 0) parts += tr("{0} כפולים דולגו", r.duplicates)
                    if (r.skippedShared > 0) parts += tr("{0} רשומות 'כללי' דולגו – צריך להתחבר בהגדרות", r.skippedShared)
                    toast(ctx, parts.joinToString(", "))
                }
                .onFailure { toast(ctx, tr("הטעינה נכשלה: {0}", it.message)) }
            importing = false
        }
    }

    // גיבוי אוטומטי של הספר האישי לשרת (פעם ב-3 ימים)
    LaunchedEffect(Unit) { com.phonebook.app.net.CloudBackup.autoIfDue() }

    // הכפתור הצף לנהיגה – חוזר אם היה דלוק
    LaunchedEffect(Unit) {
        if (Prefs.bubble && com.phonebook.app.pc.DrivingBubbleService.canShow(ctx)) runCatching { com.phonebook.app.pc.DrivingBubbleService.start(ctx) }
    }

    // סנכרון שקט: אנשי קשר חדשים מהטלפון (מכל האפליקציות) נכנסים לספר האישי
    LaunchedEffect(Unit) {
        if (Prefs.autoPhoneSync && com.phonebook.app.data.SystemContacts.hasPermission(ctx)) {
            withContext(Dispatchers.IO) {
                runCatching { com.phonebook.app.data.SystemContacts.sync(ctx, toApp = true, toPhone = false, auto = true) }
            }
        }
    }

    // בדיקת עדכונים פעם ביום
    var update by remember { mutableStateOf<com.phonebook.app.net.Updater.Update?>(null) }
    LaunchedEffect(Unit) {
        if (System.currentTimeMillis() - Prefs.lastUpdateCheck > 24 * 3600 * 1000L) {
            runCatching { com.phonebook.app.net.Updater.check(ctx) }.onSuccess {
                Prefs.lastUpdateCheck = System.currentTimeMillis()
                update = it
            }
        }
    }
    update?.let { u -> UpdateDialog(u, onDismiss = { update = null }) }

    val call: (String) -> Unit = { Actions.call(ctx, it) }
    val sms: (String) -> Unit = { overlay = Overlay.Conversation(it) }

    val drivingUi by AssistantBus.driving.collectAsState()
    val clean = drivingUi && tab == HomeTab.Assistant   // מצב נהיגה: מסך נקי, בלי תפריטים
    Box(Modifier.fillMaxSize().background(skyBrush())) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (clean) tr("🚗 עוזרת") else tr(tab.title), fontWeight = FontWeight.Bold) },
                    actions = {
                        if (clean) return@TopAppBar
                        if (tab == HomeTab.General || tab == HomeTab.Personal) {
                            Surface(
                                onClick = { importer.launch(arrayOf("*/*")) },
                                shape = RoundedCornerShape(14.dp),
                                color = Color.White.copy(alpha = 0.14f),
                                contentColor = Color.White,
                            ) {
                                Text(
                                    if (importing) tr("טוען…") else tr("📂 טעינת קובץ"),
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                        IconButton(onClick = { overlay = Overlay.Settings }) { Icon(Icons.Filled.Settings, tr("הגדרות")) }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer,
                        titleContentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                        actionIconContentColor = MaterialTheme.colorScheme.onSecondaryContainer,
                    ),
                )
            },
            bottomBar = {
                if (!clean) NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                    tonalElevation = 0.dp,
                    modifier = Modifier.shadow(12.dp, RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp))
                        .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp)),
                ) {
                    HomeTab.entries.forEach { t ->
                        NavigationBarItem(
                            selected = t == tab,
                            onClick = { tab = t },
                            icon = { Icon(t.icon, null) },
                            label = { Text(tr(t.label), fontSize = 11.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            ),
                        )
                    }
                }
            },
            floatingActionButton = {
                when (tab) {
                    HomeTab.Calls -> SkyFab(Icons.Filled.Dialpad, tr("חייגן")) { overlay = Overlay.Dialer() }
                    HomeTab.Messages -> SkyFab(Icons.Filled.Edit, tr("הודעה חדשה")) { overlay = Overlay.NewMessage() }
                    HomeTab.General, HomeTab.Personal ->
                        SkyFab(Icons.Filled.PersonAdd, tr("איש קשר חדש")) { overlay = Overlay.EditContact(null, tab == HomeTab.General) }
                    else -> {}
                }
            },
            containerColor = Color.Transparent,
        ) { pad ->
            // המקלדת לא מסתירה את שדה הכתיבה (בעוזרת, בחיפוש ועוד)
            Column(Modifier.padding(pad).consumeWindowInsets(pad).imePadding().fillMaxSize()) {
                val activeCall by com.phonebook.app.call.CallManager.call.collectAsState()
                if (activeCall != null) {
                    Surface(
                        onClick = { ctx.startActivity(com.phonebook.app.call.InCallActivity.intent(ctx)) },
                        color = CallGreen,
                        contentColor = Color.White,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Call, null)
                            Spacer(Modifier.width(10.dp))
                            Text(tr("בשיחה – לחץ כדי לחזור למסך השיחה"), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    HomeTab.Calls -> CallsScreen(
                        onCall = call, onSms = sms,
                        onAddContact = { n -> overlay = Overlay.EditContact(Contact(id = java.util.UUID.randomUUID().toString(), name = "", phone = n), false) }
                    )
                    HomeTab.Messages -> ThreadsScreen(onOpen = sms)
                    HomeTab.General -> ContactsScreen(shared = true, onCall = call, onSms = sms,
                        onEdit = { overlay = Overlay.EditContact(it, true) }, onSettings = { overlay = Overlay.Settings })
                    HomeTab.Personal -> ContactsScreen(shared = false, onCall = call, onSms = sms,
                        onEdit = { overlay = Overlay.EditContact(it, false) }, onSettings = { overlay = Overlay.Settings })
                    HomeTab.Assistant -> AssistantScreen(onSettings = { overlay = Overlay.Settings }, onSms = { a, t -> overlay = Overlay.Conversation(a, t) })
                }
            }
            }
        }

        overlay?.let { o ->
            BackHandler { overlay = null }
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(Modifier.fillMaxSize()) {
                Box(
                    Modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars)
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                )
                Box(Modifier.fillMaxSize().navigationBarsPadding().imePadding()) {
                    val close = { overlay = null }
                    when (o) {
                        is Overlay.Dialer -> DialerScreen(o.number, onClose = close, onCall = { close(); call(it) })
                        is Overlay.Conversation -> ConversationScreen(
                            o.address, o.draft, onClose = close, onCall = call,
                            onForward = { overlay = Overlay.NewMessage(it) }
                        )
                        is Overlay.NewMessage -> NewMessageScreen(onClose = close, onStart = { overlay = Overlay.Conversation(it, o.draft) })
                        Overlay.Settings -> SettingsScreen(
                            onClose = close,
                            onTrash = { overlay = Overlay.Trash },
                            onAdmin = { overlay = Overlay.Admin },
                        )
                        Overlay.Trash -> TrashScreen(onClose = { overlay = Overlay.Settings })
                        Overlay.Admin -> AdminScreen(onClose = { overlay = Overlay.Settings })
                        is Overlay.EditContact -> ContactEditor(o.contact, o.shared, onClose = close)
                    }
                }
                }
            }
        }
    }
}

/** כפתור עגול צף בצבעי שמיים */
@Composable
private fun SkyFab(icon: ImageVector, label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(64.dp)
            .shadow(14.dp, CircleShape)
            .clip(CircleShape)
            .background(BrandGradient)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(icon, label, tint = Color.White, modifier = Modifier.size(28.dp)) }
}

// ---------------- הגדרה ראשונית ----------------

val REQUIRED_PERMISSIONS: Array<String> = buildList {
    add(Manifest.permission.CALL_PHONE)
    add(Manifest.permission.READ_CALL_LOG)
    add(Manifest.permission.WRITE_CALL_LOG)
    add(Manifest.permission.READ_PHONE_STATE)
    add(Manifest.permission.READ_CONTACTS)
    add(Manifest.permission.READ_SMS)
    add(Manifest.permission.SEND_SMS)
    add(Manifest.permission.RECEIVE_SMS)
    if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
}.toTypedArray()

@Composable
fun SetupScreen(onDone: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().windowInsetsTopHeight(WindowInsets.statusBars)
            .background(MaterialTheme.colorScheme.secondaryContainer)
    )
    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text(tr("ספר טלפונים"), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Text(
            tr("כדי שהאפליקציה תוכל לחייג, לקבל שיחות ולקבל הודעות, צריך להגדיר אותה כאפליקציית ברירת המחדל ולאשר הרשאות. אפשר גם לדלג ולעשות את זה אחר כך בהגדרות."),
            style = MaterialTheme.typography.bodyLarge
        )
        DefaultsSection()
        Spacer(Modifier.height(8.dp))
        Button(onClick = onDone, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(tr("המשך"), fontSize = 17.sp) }
    }
}

/** כפתורים להגדרת ברירת מחדל (טלפון / SMS) והרשאות – משמש גם במסך ההגדרות */
@Composable
fun DefaultsSection() {
    val ctx = LocalContext.current
    val rm = remember { ctx.getSystemService(RoleManager::class.java) }
    var tick by remember { mutableIntStateOf(0) }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick++ }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }

    val isDialer = remember(tick) { rm.isRoleHeld(RoleManager.ROLE_DIALER) }
    val isSms = remember(tick) { rm.isRoleHeld(RoleManager.ROLE_SMS) }
    val permsOk = remember(tick) {
        REQUIRED_PERMISSIONS.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }
    }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SetupStep(tr("אפליקציית טלפון ברירת מחדל"), tr("חיוג, קבלת שיחות וזיהוי מתקשר"), isDialer) {
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
        }
        SetupStep(tr("אפליקציית SMS ברירת מחדל"), tr("קבלה ושליחה של הודעות"), isSms) {
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
        }
        SetupStep(tr("הרשאות"), tr("יומן שיחות, אנשי קשר, הודעות והתראות"), permsOk) {
            permLauncher.launch(REQUIRED_PERMISSIONS)
        }
        if (!isDialer || !isSms || !permsOk) {
            Text(
                tr("אם מופיעה הודעה שההגדרה נחסמה: פתח את הגדרות האפליקציה, לחץ על ⋮ למעלה ובחר \"אפשר הגדרות מוגבלות\". אחר כך חזור ולחץ שוב \"הגדר\"."),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = {
                ctx.startActivity(
                    Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))
                )
            }) { Text(tr("פתח את הגדרות האפליקציה")) }
        }
    }
}

@Composable
private fun SetupStep(title: String, subtitle: String, done: Boolean, onClick: () -> Unit) {
    AppCard {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (done) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked, null,
                tint = if (done) CallGreen else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!done) FilledTonalButton(onClick = onClick) { Text(tr("הגדר")) }
        }
    }
}
