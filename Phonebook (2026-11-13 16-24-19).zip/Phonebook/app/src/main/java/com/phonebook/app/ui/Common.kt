@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.phonebook.app.data.Phone
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** מספר טלפון בתוך טקסט עברי – כדי שה-+ והמקפים לא יתהפכו */
fun ltr(s: String) = "⁦$s⁩"

private val he = Locale("he")

fun dayLabel(ms: Long): String {
    val d = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
    val today = LocalDate.now()
    return when {
        d == today -> tr("היום")
        d == today.minusDays(1) -> tr("אתמול")
        I18n.code.value == "he" && d.year == today.year -> d.format(DateTimeFormatter.ofPattern("EEEE, d בMMMM", he))
        I18n.code.value == "he" -> d.format(DateTimeFormatter.ofPattern("d בMMMM yyyy", he))
        I18n.code.value == "en" && d.year == today.year -> d.format(DateTimeFormatter.ofPattern("EEEE, MMMM d", I18n.locale()))
        I18n.code.value == "en" -> d.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", I18n.locale()))
        d.year == today.year -> d.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", I18n.locale()))
        else -> d.format(DateTimeFormatter.ofPattern("d MMMM yyyy", I18n.locale()))
    }
}

fun timeLabel(ms: Long): String =
    Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalTime().format(DateTimeFormatter.ofPattern("HH:mm"))

fun shortDate(ms: Long): String {
    val d = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
    return if (d == LocalDate.now()) timeLabel(ms) else d.format(DateTimeFormatter.ofPattern("d.M"))
}

fun formatDuration(sec: Long): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

fun toast(ctx: Context, text: String) = Toast.makeText(ctx, text, Toast.LENGTH_LONG).show()

object Actions {
    fun call(ctx: Context, number: String, sim: android.telecom.PhoneAccountHandle? = null) {
        if (number.isBlank()) return
        val uri = Uri.fromParts("tel", number.trim(), null)
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            try {
                val extras = Bundle()
                if (sim != null) extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, sim)
                ctx.getSystemService(TelecomManager::class.java).placeCall(uri, extras)
                return
            } catch (_: Exception) {
            }
        }
        toast(ctx, tr("אין הרשאת חיוג – אשר אותה בהגדרות ← ברירת מחדל והרשאות"))
    }

    fun whatsapp(ctx: Context, number: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${Phone.international(number)}")))
        } catch (_: ActivityNotFoundException) {
            toast(ctx, tr("וואטסאפ לא מותקן"))
        }
    }
}

private val avatarColors = listOf(
    Color(0xFF3B82F6), Color(0xFF8B7CF6), Color(0xFF14B8C4), Color(0xFFF59E5B),
    Color(0xFFEC6FA1), Color(0xFF22C07A), Color(0xFF38BDF8),
)

@Composable
fun Avatar(name: String, size: Dp = 44.dp) {
    val label = name.trim().firstOrNull { it.isLetter() }?.toString() ?: "#"
    val color = avatarColors[(name.hashCode() and 0x7FFFFFFF) % avatarColors.size]
    Box(
        Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(color.copy(alpha = 0.16f), color.copy(alpha = 0.30f)))),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.42f).sp)
    }
}

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) { Column(content = content) }
}

@Composable
fun SectionHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 6.dp, top = 16.dp, bottom = 8.dp)
    )
}

@Composable
fun EmptyState(text: String, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
fun InfoCard(text: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Info, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
            Spacer(Modifier.width(10.dp))
            Text(text, color = MaterialTheme.colorScheme.onPrimaryContainer, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

/** כותרת למסכים שנפתחים מעל המסך הראשי – באותו כחול כהה של הכותרת הראשית */
@Composable
fun OverlayTopBar(title: String, onBack: () -> Unit, actions: @Composable RowScope.() -> Unit = {}) {
    val on = MaterialTheme.colorScheme.onSecondaryContainer
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.secondaryContainer).padding(horizontal = 4.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, tr("חזרה"), tint = on) }
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = on, modifier = Modifier.weight(1f), maxLines = 1)
        CompositionLocalProvider(LocalContentColor provides on) { actions() }
    }
}

/** מספר שעולה כשמשהו משתנה ביומן השיחות / ב-SMS או כשחוזרים לאפליקציה */
@Composable
fun rememberProviderVersion(vararg uris: Uri): Int {
    val ctx = LocalContext.current
    var v by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                v++
            }
        }
        uris.forEach {
            try {
                ctx.contentResolver.registerContentObserver(it, true, obs)
            } catch (_: Exception) {
            }
        }
        onDispose { ctx.contentResolver.unregisterContentObserver(obs) }
    }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) v++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    return v
}
