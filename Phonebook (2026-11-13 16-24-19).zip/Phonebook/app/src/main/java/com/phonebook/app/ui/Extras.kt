@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.phonebook.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.Updater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

// ---------------- מסך נעילה ----------------

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    LaunchedEffect(Unit) { onUnlock() }
    Box(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.secondaryContainer).systemBarsPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Icon(Icons.Filled.Lock, null, tint = Color.White, modifier = Modifier.size(64.dp))
            Text(tr("ספר טלפונים נעול"), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Button(
                onClick = onUnlock,
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Navy),
                shape = RoundedCornerShape(16.dp)
            ) { Text(tr("פתח"), fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp)) }
        }
    }
}

// ---------------- סל מחזור ----------------

@Composable
fun TrashScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val dbv by LocalDb.changes.collectAsState()
    val items by produceState<List<Pair<Contact, Long>>?>(null, dbv) { value = withContext(Dispatchers.IO) { LocalDb.trash() } }
    var confirmEmpty by remember { mutableStateOf(false) }
    val fmt = remember { DateTimeFormatter.ofPattern("d.M.yyyy HH:mm") }

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar(tr("סל מחזור"), onClose) {
            if (!items.isNullOrEmpty()) TextButton(
                onClick = { confirmEmpty = true },
                colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
            ) { Text(tr("רוקן")) }
        }
        Text(
            tr("אנשי קשר שנמחקו מהספר האישי נשמרים כאן 30 יום ואז נמחקים לצמיתות."),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(16.dp)
        )
        val list = items
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> EmptyState(tr("סל המחזור ריק"))
            else -> {
                Row(Modifier.padding(horizontal = 16.dp)) {
                    Button(onClick = { LocalDb.restore(list.map { it.first.id }); toast(ctx, tr("שוחזרו {0} אנשי קשר", list.size)) }) {
                        Text(tr("↩️ שחזר הכל ({0})", list.size))
                    }
                }
                LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(list, key = { it.first.id }) { (c, at) ->
                        AppCard {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        ltr(c.phone) + tr(" · נמחק ") + Instant.ofEpochMilli(at).atZone(ZoneId.systemDefault()).format(fmt),
                                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                TextButton(onClick = { LocalDb.restore(listOf(c.id)); toast(ctx, tr("שוחזר")) }) { Text(tr("שחזר")) }
                            }
                        }
                    }
                }
            }
        }
    }
    if (confirmEmpty) ConfirmDialog(tr("לרוקן את סל המחזור?"), tr("אנשי הקשר שבסל יימחקו לצמיתות."), tr("רוקן"), onDismiss = { confirmEmpty = false }) {
        confirmEmpty = false
        LocalDb.deleteForever(null)
    }
}

// ---------------- עדכון גרסה ----------------

@Composable
fun UpdateDialog(update: Updater.Update, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var progress by remember { mutableStateOf<Float?>(null) }
    val uri = LocalUriHandler.current
    val confirm by Updater.confirm.collectAsState()
    val failure by Updater.failure.collectAsState()
    LaunchedEffect(confirm) {
        val i = confirm ?: return@LaunchedEffect
        Updater.confirm.value = null
        try { ctx.startActivity(i) } catch (e: Exception) { Updater.failure.value = e.message ?: tr("לא ניתן לפתוח את מסך ההתקנה") }
    }
    LaunchedEffect(Unit) { Updater.failure.value = null }
    LaunchedEffect(failure) { if (failure != null) progress = null }
    AlertDialog(
        onDismissRequest = { if (progress == null) onDismiss() },
        title = { Text(tr("יש גרסה חדשה 🎉")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(tr("גרסה 1.0.{0} מוכנה להתקנה. ההתקנה שומרת את כל אנשי הקשר וההגדרות.", update.versionCode))
                progress?.let {
                    LinearProgressIndicator(progress = { it }, modifier = Modifier.fillMaxWidth())
                    Text(if (it >= 1f) tr("מתקין… אשר את ההתקנה בחלון שנפתח") else tr("מוריד… {0}%", (it * 100).toInt()), textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                }
                failure?.let {
                    Text(tr("העדכון האוטומטי לא הצליח. אפשר להוריד ולהתקין ידנית – לוחצים על \"הורדה ידנית\", פותחים את הקובץ שירד ולוחצים \"עדכן\"."),
                        color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = { uri.openUri(Updater.DIRECT_URL) }) { Text(tr("⬇️ הורדה ידנית")) }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = progress == null, onClick = {
                progress = 0f
                scope.launch {
                    runCatching { Updater.install(ctx, update) { p -> progress = p } }
                        .onFailure { Updater.failure.value = it.message ?: tr("שגיאה"); progress = null }
                }
            }) { Text(tr("עדכן עכשיו")) }
        },
        dismissButton = { if (progress == null) TextButton(onClick = onDismiss) { Text(tr("אחר כך")) } },
    )
}
