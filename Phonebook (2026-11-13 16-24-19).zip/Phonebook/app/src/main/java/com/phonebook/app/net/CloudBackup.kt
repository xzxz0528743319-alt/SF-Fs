package com.phonebook.app.net

import android.util.Base64
import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Phone
import com.phonebook.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.time.Instant
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * גיבוי של הספר האישי לשרת – רק המשתמש עצמו יכול לראות אותו (לא מופיע בספר הכללי).
 * כדי שלא ילכו לאיבוד אנשי הקשר אם הטלפון נאבד או מוחלף.
 */
object CloudBackup {
    data class Info(val count: Int, val at: String)

    private fun gz(s: String): String {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(s.toByteArray(Charsets.UTF_8)) }
        return Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
    }

    private fun ungz(b64: String): String =
        GZIPInputStream(ByteArrayInputStream(Base64.decode(b64, Base64.DEFAULT))).use { it.readBytes().toString(Charsets.UTF_8) }

    private fun toJson(c: Contact) = JSONObject()
        .put("id", c.id).put("name", c.name).put("phone", c.phone).put("phone2", c.phone2)
        .put("city", c.city).put("address", c.address).put("father", c.father).put("chem", c.chem)
        .put("shtibel", c.shtibel).put("email", c.email).put("extra", c.extra)

    private fun fromJson(o: JSONObject) = Contact(
        id = o.optString("id"), name = o.optString("name"), phone = o.optString("phone"), phone2 = o.optString("phone2"),
        city = o.optString("city"), address = o.optString("address"), father = o.optString("father"), chem = o.optString("chem"),
        shtibel = o.optString("shtibel"), email = o.optString("email"), extra = o.optString("extra"),
    )

    /** מגבה את כל הספר האישי לשרת. מחזיר כמה אנשי קשר גובו */
    suspend fun backup(): Int = withContext(Dispatchers.IO) {
        val list = LocalDb.all(LocalDb.PERSONAL)
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        Server.rest(
            "POST", "personal_backup",
            JSONObject().put("data", gz(arr.toString())).put("count", list.size).put("updated_at", Instant.now().toString()).toString(),
            mapOf("Prefer" to "resolution=merge-duplicates,return=minimal")
        )
        Prefs.cloudBackupAt = System.currentTimeMillis()
        list.size
    }

    suspend fun info(): Info? = withContext(Dispatchers.IO) {
        val a = JSONArray(Server.rest("GET", "personal_backup?select=count,updated_at"))
        if (a.length() == 0) null else a.getJSONObject(0).let { Info(it.optInt("count"), it.optString("updated_at").take(16).replace('T', ' ')) }
    }

    /** משחזר מהשרת: מוסיף לספר האישי רק את מי שחסר (לפי מספר טלפון). מחזיר כמה נוספו */
    suspend fun restore(): Int = withContext(Dispatchers.IO) {
        val a = JSONArray(Server.rest("GET", "personal_backup?select=data"))
        if (a.length() == 0) return@withContext 0
        val arr = JSONArray(ungz(a.getJSONObject(0).optString("data")))
        val have = HashSet<String>()
        LocalDb.all(LocalDb.PERSONAL).forEach { c ->
            Phone.tail(c.phone).takeIf { it.isNotEmpty() }?.let { have += it }
        }
        val fresh = (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }.filter { c ->
            val t = Phone.tail(c.phone)
            t.isEmpty() || have.add(t)
        }
        if (fresh.isNotEmpty()) {
            val batch = "cloud-" + java.util.UUID.randomUUID().toString()
            LocalDb.upsertAll(LocalDb.PERSONAL, fresh, batch = batch)
            Prefs.lastBatch = batch
            Prefs.lastBatchCount = fresh.size
        }
        fresh.size
    }

    /** גיבוי אוטומטי: פעם ב-3 ימים, אם מחוברים */
    suspend fun autoIfDue() {
        if (!Prefs.cloudBackup || !Server.loggedIn()) return
        if (System.currentTimeMillis() - Prefs.cloudBackupAt < 3L * 24 * 3600 * 1000) return
        if (LocalDb.count(LocalDb.PERSONAL) == 0) return
        runCatching { backup() }
    }
}
