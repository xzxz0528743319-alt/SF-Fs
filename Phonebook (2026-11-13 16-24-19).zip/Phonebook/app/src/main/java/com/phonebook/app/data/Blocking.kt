package com.phonebook.app.data

import android.content.ContentValues
import android.content.Context
import android.provider.BlockedNumberContract
import android.provider.CallLog

/** חסימת מספרים – משתמש ברשימת החסומים של המערכת, כך שהחסימה תקפה לשיחות ול-SMS */
object Blocking {
    fun canBlock(ctx: Context) = try {
        BlockedNumberContract.canCurrentUserBlockNumbers(ctx)
    } catch (_: Exception) {
        false
    }

    fun isBlocked(ctx: Context, number: String) = try {
        BlockedNumberContract.isBlocked(ctx, number)
    } catch (_: Exception) {
        false
    }

    fun block(ctx: Context, number: String): Boolean = try {
        ctx.contentResolver.insert(
            BlockedNumberContract.BlockedNumbers.CONTENT_URI,
            ContentValues().apply { put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, number) }
        ) != null
    } catch (_: Exception) {
        false
    }

    fun unblock(ctx: Context, number: String): Boolean = try {
        BlockedNumberContract.unblock(ctx, number) > 0
    } catch (_: Exception) {
        false
    }

    fun list(ctx: Context): List<String> = try {
        ctx.contentResolver.query(
            BlockedNumberContract.BlockedNumbers.CONTENT_URI,
            arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER), null, null, null
        )?.use { c -> buildList { while (c.moveToNext()) add(c.getString(0) ?: "") } }?.filter { it.isNotBlank() } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }
}

object CallLogEdit {
    /** מוחק מהיומן את כל השיחות עם המספר */
    fun deleteNumber(ctx: Context, number: String): Boolean = try {
        ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, "${CallLog.Calls.NUMBER}=?", arrayOf(number)) > 0
    } catch (_: Exception) {
        false
    }

    fun clearAll(ctx: Context): Boolean = try {
        ctx.contentResolver.delete(CallLog.Calls.CONTENT_URI, null, null) >= 0
    } catch (_: Exception) {
        false
    }
}
