package com.phonebook.app.drive

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import androidx.core.content.ContextCompat
import com.phonebook.app.App
import com.phonebook.app.MainActivity
import com.phonebook.app.R
import com.phonebook.app.data.CallerId
import com.phonebook.app.data.Notes
import com.phonebook.app.ui.tr

/**
 * תזכורות "להתקשר אחר כך" והערות אחרי שיחה – הכל מתוך ההתראה, בלי לפתוח את האפליקציה.
 */
object Reminders {
    const val ACTION_REMIND = "com.phonebook.app.REMIND"      // הגיע הזמן – מציגים תזכורת
    const val ACTION_LATER = "com.phonebook.app.REMIND_LATER" // המשתמש ביקש "הזכר לי בעוד שעה"
    const val ACTION_NOTE = "com.phonebook.app.NOTE"          // נכתבה הערה בהתראה
    const val ACTION_DISMISS = "com.phonebook.app.NOTE_DISMISS"
    const val EXTRA_NUMBER = "number"
    const val EXTRA_MIN = "minutes"
    const val EXTRA_NOTIF = "notif"
    const val KEY_TEXT = "note_text"

    private fun nid(number: String) = 5000 + (number.filter { it.isDigit() }.takeLast(7).toIntOrNull() ?: 0) % 100000

    private fun name(ctx: Context, number: String) = runCatching { CallerId.lookup(ctx, number)?.name }.getOrNull() ?: number

    fun broadcast(ctx: Context, action: String, number: String, minutes: Int = 60, notif: Int = 0): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, (action + number + minutes).hashCode(),
            Intent(ctx, ReminderReceiver::class.java).setAction(action)
                .putExtra(EXTRA_NUMBER, number).putExtra(EXTRA_MIN, minutes).putExtra(EXTRA_NOTIF, notif),
            PendingIntent.FLAG_UPDATE_CURRENT or if (action == ACTION_NOTE) PendingIntent.FLAG_MUTABLE else PendingIntent.FLAG_IMMUTABLE
        )

    private fun callIntent(ctx: Context, number: String) = PendingIntent.getActivity(
        ctx, ("call" + number).hashCode(),
        Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)).setClass(ctx, MainActivity::class.java)
            .putExtra(MainActivity.EXTRA_CALL_NOW, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** תזכורת להתקשר בעוד X דקות */
    fun schedule(ctx: Context, number: String, minutes: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val at = System.currentTimeMillis() + minutes * 60_000L
        runCatching { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, broadcast(ctx, ACTION_REMIND, number, minutes)) }
    }

    private fun canNotify(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun showReminder(ctx: Context, number: String) {
        if (!canNotify(ctx)) return
        val id = nid(number)
        val who = name(ctx, number)
        val last = Notes.last(number)
        val n = NotificationCompat.Builder(ctx, App.CH_NOTES)
            .setSmallIcon(R.drawable.ic_stat_phone)
            .setContentTitle(tr("⏰ תזכורת: להתקשר ל{0}", who))
            .setContentText(last?.let { tr("📝 {0}", it.text) } ?: tr("ביקשת שאזכיר לך"))
            .setContentIntent(callIntent(ctx, number))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, tr("📞 התקשר עכשיו"), callIntent(ctx, number))
            .addAction(0, tr("⏰ שוב בעוד שעה"), broadcast(ctx, ACTION_LATER, number, 60, id))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(id, n) }
    }

    /** אחרי שיחה: "להוסיף הערה?" – כותבים ישר בהתראה */
    @SuppressLint("MissingPermission")
    fun askNote(ctx: Context, number: String) {
        if (!canNotify(ctx)) return
        val id = nid(number) + 200000
        val who = name(ctx, number)
        val n = NotificationCompat.Builder(ctx, App.CH_NOTES)
            .setSmallIcon(R.drawable.ic_stat_phone)
            .setContentTitle(tr("📝 הערה על השיחה עם {0}?", who))
            .setContentText(tr("למשל: מה סיכמתם, מה צריך לעשות. ההערה תופיע בפעם הבאה שהוא יתקשר."))
            .setSilent(true)
            .setAutoCancel(true)
            .setTimeoutAfter(15 * 60_000L)
            .addAction(
                NotificationCompat.Action.Builder(0, tr("✍️ כתוב הערה"), broadcast(ctx, ACTION_NOTE, number, 0, id))
                    .addRemoteInput(RemoteInput.Builder(KEY_TEXT).setLabel(tr("הערה")).build())
                    .build()
            )
            .addAction(0, tr("⏰ הזכר להתקשר בעוד שעה"), broadcast(ctx, ACTION_LATER, number, 60, id))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(id, n) }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val number = intent.getStringExtra(Reminders.EXTRA_NUMBER) ?: return
        val notif = intent.getIntExtra(Reminders.EXTRA_NOTIF, 0)
        when (intent.action) {
            Reminders.ACTION_REMIND -> Reminders.showReminder(ctx, number)
            Reminders.ACTION_LATER -> {
                val min = intent.getIntExtra(Reminders.EXTRA_MIN, 60)
                Reminders.schedule(ctx, number, min)
                if (notif != 0) NotificationManagerCompat.from(ctx).cancel(notif)
                Toast.makeText(ctx, tr("אזכיר לך להתקשר בעוד {0} דקות", min), Toast.LENGTH_SHORT).show()
            }
            Reminders.ACTION_NOTE -> {
                val text = RemoteInput.getResultsFromIntent(intent)?.getCharSequence(Reminders.KEY_TEXT)?.toString().orEmpty()
                if (text.isNotBlank()) {
                    Notes.add(number, text)
                    Toast.makeText(ctx, tr("ההערה נשמרה ✓"), Toast.LENGTH_SHORT).show()
                }
                if (notif != 0) NotificationManagerCompat.from(ctx).cancel(notif)
            }
        }
    }
}
