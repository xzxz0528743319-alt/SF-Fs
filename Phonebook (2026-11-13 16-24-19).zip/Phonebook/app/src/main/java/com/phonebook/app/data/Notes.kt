package com.phonebook.app.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * הערות על אנשים / מספרים ("הבטחתי לשלוח מחר את ההצעה").
 * נשמרות רק בטלפון, לפי סוף המספר – כך הן מופיעות גם ביומן, גם במסך השיחה וגם אצל העוזרת.
 */
object Notes {
    data class Note(val id: Long, val tail: String, val at: Long, val text: String)

    private lateinit var helper: SQLiteOpenHelper

    fun init(ctx: Context) {
        helper = object : SQLiteOpenHelper(ctx, "notes.db", null, 1) {
            override fun onCreate(db: SQLiteDatabase) {
                db.execSQL("CREATE TABLE notes (id INTEGER PRIMARY KEY AUTOINCREMENT, tail TEXT NOT NULL, at INTEGER NOT NULL, text TEXT NOT NULL)")
                db.execSQL("CREATE INDEX notes_tail ON notes(tail)")
            }

            override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
        }
    }

    private fun ready() = ::helper.isInitialized

    fun add(number: String, text: String) {
        val t = Phone.tail(number)
        if (!ready() || t.isEmpty() || text.isBlank()) return
        runCatching {
            helper.writableDatabase.insert("notes", null, ContentValues().apply {
                put("tail", t); put("at", System.currentTimeMillis()); put("text", text.trim())
            })
            LocalDb.changes.value++
        }
    }

    fun forNumber(number: String, limit: Int = 20): List<Note> {
        val t = Phone.tail(number)
        if (!ready() || t.isEmpty()) return emptyList()
        return runCatching {
            helper.readableDatabase.rawQuery(
                "SELECT id, tail, at, text FROM notes WHERE tail=? ORDER BY at DESC LIMIT $limit", arrayOf(t)
            ).use { c ->
                buildList { while (c.moveToNext()) add(Note(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3))) }
            }
        }.getOrDefault(emptyList())
    }

    fun last(number: String): Note? = forNumber(number, 1).firstOrNull()

    fun delete(id: Long) {
        if (!ready()) return
        runCatching { helper.writableDatabase.delete("notes", "id=?", arrayOf(id.toString())); LocalDb.changes.value++ }
    }
}
