package com.phonebook.app.sms

import java.nio.charset.Charset

/**
 * מפענח הודעות MMS בפורמט WAP/MMS (PDU בינארי):
 *  - הודעת "יש לך MMS" (m-notification-ind) – כדי לדעת מאיפה להוריד
 *  - ההודעה עצמה אחרי ההורדה (m-retrieve-conf) – טקסט ותמונות
 */
object MmsPdu {
    const val TYPE_NOTIFICATION_IND = 0x82
    const val TYPE_RETRIEVE_CONF = 0x84

    class Part(val contentType: String, val name: String?, val charset: Int, val data: ByteArray) {
        val isText get() = contentType.startsWith("text/plain")
        val isSmil get() = contentType.contains("smil")
        fun text(): String = decode(data, charset)
    }

    class Message(
        val type: Int,
        val from: String?,
        val to: List<String>,
        val subject: String?,
        val date: Long,          // שניות
        val transactionId: String?,
        val messageId: String?,
        val contentLocation: String?,
        val parts: List<Part>,
    )

    private class Reader(val b: ByteArray, var pos: Int = 0) {
        val hasMore get() = pos < b.size
        fun peek(): Int = b[pos].toInt() and 0xFF
        fun next(): Int = b[pos++].toInt() and 0xFF

        fun uintvar(): Int {
            var v = 0
            while (true) {
                val x = next()
                v = (v shl 7) or (x and 0x7F)
                if (x and 0x80 == 0) return v
            }
        }

        fun valueLength(): Int {
            val x = next()
            return when {
                x <= 30 -> x
                x == 31 -> uintvar()
                else -> throw IllegalStateException("bad value-length")
            }
        }

        fun textString(): String {
            if (hasMore && peek() == 0x7F) pos++ // quote
            val start = pos
            while (pos < b.size && b[pos].toInt() != 0) pos++
            val s = String(b, start, pos - start, Charsets.UTF_8)
            if (pos < b.size) pos++ // NUL
            return s
        }

        fun longInteger(): Long {
            val len = next()
            var v = 0L
            repeat(len) { v = (v shl 8) or next().toLong() }
            return v
        }

        fun integerValue(): Long = if (peek() >= 0x80) (next() and 0x7F).toLong() else longInteger()

        /** encoded-string-value: טקסט רגיל, או אורך + קידוד + טקסט */
        fun encodedString(): String {
            if (peek() <= 31) {
                val len = valueLength()
                val end = pos + len
                val cs = integerValue().toInt()
                var stop = pos
                while (stop < end && b[stop].toInt() != 0) stop++
                if (pos < end && b[pos].toInt() and 0xFF == 0x7F) pos++
                val s = decode(b.copyOfRange(pos, stop), cs)
                pos = end
                return s
            }
            return textString()
        }

        /** דילוג על ערך כותרת לא מוכר לפי כללי WSP */
        fun skipValue() {
            val x = peek()
            when {
                x >= 0x80 -> pos++
                x <= 31 -> { val len = valueLength(); pos += len }
                else -> textString()
            }
        }
    }

    private val WELL_KNOWN_TYPES = mapOf(
        0x00 to "*/*", 0x01 to "text/*", 0x02 to "text/html", 0x03 to "text/plain",
        0x08 to "text/x-vCard", 0x1C to "image/*", 0x1D to "image/gif", 0x1E to "image/jpeg", 0x1F to "image/tiff",
        0x20 to "image/png", 0x21 to "image/vnd.wap.wbmp", 0x22 to "application/vnd.wap.multipart.*",
        0x23 to "application/vnd.wap.multipart.mixed", 0x33 to "application/vnd.wap.multipart.related",
        0x3E to "application/smil"
    )

    /** Content-Type עם פרמטרים. מחזיר (סוג, שם, קידוד) */
    private fun contentType(r: Reader): Triple<String, String?, Int> {
        val x = r.peek()
        if (x >= 0x80) return Triple(WELL_KNOWN_TYPES[r.next() and 0x7F] ?: "application/octet-stream", null, 0)
        if (x > 31) return Triple(r.textString().lowercase(), null, 0)
        val len = r.valueLength()
        val end = r.pos + len
        val media = if (r.peek() >= 0x80) WELL_KNOWN_TYPES[r.next() and 0x7F] ?: "application/octet-stream" else r.textString().lowercase()
        var name: String? = null
        var charset = 0
        while (r.pos < end) {
            val p = r.peek()
            if (p >= 0x80) {
                when (r.next() and 0x7F) {
                    0x01 -> charset = r.integerValue().toInt()                       // charset
                    0x05, 0x06, 0x17, 0x18 -> name = r.textString()                  // name / filename
                    else -> r.skipValue()
                }
            } else {
                r.textString() // שם פרמטר לא מוכר
                if (r.pos < end) r.skipValue()
            }
        }
        r.pos = end
        return Triple(media, name, charset)
    }

    fun parse(bytes: ByteArray): Message? = try {
        val r = Reader(bytes)
        var type = 0
        var from: String? = null
        val to = mutableListOf<String>()
        var subject: String? = null
        var date = System.currentTimeMillis() / 1000
        var tid: String? = null
        var mid: String? = null
        var location: String? = null
        var parts: List<Part> = emptyList()
        loop@ while (r.hasMore) {
            val h = r.next()
            if (h < 0x80) { // כותרת לא תקנית: שם טקסט + ערך
                r.pos--
                r.textString(); if (r.hasMore) r.textString()
                continue
            }
            when (h and 0x7F) {
                0x0C -> type = r.next()                                        // Message-Type
                0x18 -> tid = r.textString()                                   // Transaction-Id
                0x0B -> mid = r.textString()                                   // Message-ID
                0x03 -> location = r.textString()                              // Content-Location
                0x05 -> date = r.longInteger()                                 // Date
                0x16 -> subject = r.encodedString()                            // Subject
                0x17 -> to += cleanAddress(r.encodedString())                  // To
                0x09 -> {                                                      // From
                    val len = r.valueLength()
                    val end = r.pos + len
                    if (r.peek() == 0x80) { r.pos++; from = cleanAddress(r.encodedString()) }
                    r.pos = end
                }
                0x04 -> {                                                      // Content-Type – אחריו מגיע גוף ההודעה
                    contentType(r)
                    parts = multipart(r)
                    break@loop
                }
                else -> r.skipValue()
            }
        }
        Message(type, from, to, subject, date, tid, mid, location, parts)
    } catch (_: Exception) {
        null
    }

    private fun multipart(r: Reader): List<Part> {
        val out = mutableListOf<Part>()
        if (!r.hasMore) return out
        val n = r.uintvar()
        repeat(n) {
            val headersLen = r.uintvar()
            val dataLen = r.uintvar()
            val headersEnd = r.pos + headersLen
            val (ct, name, cs) = contentType(r)
            r.pos = headersEnd
            val data = r.b.copyOfRange(r.pos, minOf(r.pos + dataLen, r.b.size))
            r.pos += dataLen
            out += Part(ct, name, cs, data)
        }
        return out
    }

    /** "+972501234567/TYPE=PLMN" ← "+972501234567" */
    fun cleanAddress(a: String): String = a.substringBefore("/TYPE").trim()

    fun decode(data: ByteArray, mib: Int): String {
        val cs = when (mib) {
            3 -> Charsets.US_ASCII
            4 -> Charsets.ISO_8859_1
            1013 -> Charsets.UTF_16BE
            1014 -> Charsets.UTF_16LE
            1015 -> Charsets.UTF_16
            2255 -> try { Charset.forName("windows-1255") } catch (_: Exception) { Charsets.UTF_8 }
            else -> Charsets.UTF_8
        }
        return String(data, cs).trimEnd('\u0000')
    }
}
