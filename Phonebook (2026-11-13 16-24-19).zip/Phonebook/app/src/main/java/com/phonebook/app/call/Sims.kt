package com.phonebook.app.call

import android.annotation.SuppressLint
import android.content.Context
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager

/** כרטיסי SIM: לבחירת SIM בחיוג ולהצגה ביומן השיחות */
object Sims {
    data class Sim(val handle: PhoneAccountHandle, val slot: Int, val carrier: String)

    @SuppressLint("MissingPermission")
    fun list(ctx: Context): List<Sim> = try {
        val tm = ctx.getSystemService(TelecomManager::class.java)
        tm.callCapablePhoneAccounts.mapIndexed { i, h ->
            Sim(h, i + 1, try { tm.getPhoneAccount(h)?.label?.toString() ?: "" } catch (_: Exception) { "" })
        }
    } catch (_: Exception) {
        emptyList()
    }

    /** מפה ממזהה החשבון ביומן לתווית "SIM 1" / "SIM 2" (רק כשיש יותר מכרטיס אחד) */
    fun labels(ctx: Context): Map<String, String> {
        val l = list(ctx)
        if (l.size < 2) return emptyMap()
        return l.associate { it.handle.id to "SIM ${it.slot}" }
    }
}
