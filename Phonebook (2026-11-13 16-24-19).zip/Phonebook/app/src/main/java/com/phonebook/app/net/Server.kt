package com.phonebook.app.net

import com.phonebook.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ApiError(message: String) : Exception(com.phonebook.app.ui.tr(message))   // ההודעה מתורגמת לשפת האפליקציה

object Net {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    val JSON = "application/json; charset=utf-8".toMediaType()

    fun execute(req: Request): String {
        Net.client.newCall(req).execute().use { r ->
            val body = r.body?.string() ?: ""
            if (!r.isSuccessful) throw ApiError(errorText(r.code, body))
            return body
        }
    }

    private fun errorText(code: Int, body: String): String {
        val msg = try {
            val o = JSONObject(body)
            o.optString("msg").ifBlank { o.optString("message") }.ifBlank { o.optString("error_description") }
                .ifBlank { o.optJSONObject("error")?.optString("message") ?: "" }.ifBlank { o.optString("error") }
        } catch (_: Exception) {
            ""
        }
        return when {
            msg.contains("Invalid login", true) -> "מייל או סיסמה שגויים"
            msg.contains("already registered", true) -> "המייל כבר רשום – נסה להתחבר"
            msg.contains("Email not confirmed", true) -> "צריך לאשר את המייל לפני ההתחברות"
            code == 401 || code == 403 -> com.phonebook.app.ui.tr("אין הרשאה ({0}) {1}", code, msg.take(120))
            else -> com.phonebook.app.ui.tr("שגיאת שרת {0} {1}", code, msg.take(160))
        }
    }
}

/** חיבור לשרת Supabase: הרשמה, התחברות ושליחת בקשות */
object Server {
    fun configured() = Prefs.serverUrl.isNotBlank() && Prefs.serverKey.isNotBlank()
    fun loggedIn() = Prefs.refreshToken.isNotBlank()

    private fun requireConfigured() {
        if (!configured()) throw ApiError("יש למלא בהגדרות את כתובת השרת והמפתח")
    }

    private fun auth(path: String, json: JSONObject): JSONObject {
        requireConfigured()
        val req = Request.Builder()
            .url("${Prefs.serverUrl}/auth/v1/$path")
            .header("apikey", Prefs.serverKey)
            .post(json.toString().toRequestBody(Net.JSON))
            .build()
        return JSONObject(Net.execute(req))
    }

    private fun saveSession(o: JSONObject) {
        Prefs.accessToken = o.getString("access_token")
        Prefs.refreshToken = o.getString("refresh_token")
        Prefs.tokenExpiry = System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000 - 60_000
        val user = o.optJSONObject("user")
        if (user != null) {
            Prefs.userId = user.optString("id")
            Prefs.email = user.optString("email")
        }
        Prefs.session.value = Prefs.email
    }

    suspend fun signIn(email: String, password: String) = withContext(Dispatchers.IO) {
        saveSession(auth("token?grant_type=password", JSONObject().put("email", email.trim()).put("password", password)))
        refreshStatus()
    }

    /** מחזיר true אם המשתמש מחובר מיד, false אם צריך לאשר מייל קודם */
    suspend fun signUp(email: String, password: String): Boolean = withContext(Dispatchers.IO) {
        val o = auth("signup", JSONObject().put("email", email.trim()).put("password", password))
        if (o.has("access_token")) {
            saveSession(o); refreshStatus(); true
        } else false
    }

    fun logout() = Prefs.clearSession()

    /** מעדכן אם המשתמש מנהל ואם הוא מאושר (שרת ישן בלי הפונקציה – לא נוגעים) */
    fun refreshStatus() {
        if (!configured() || !loggedIn()) return
        try {
            val o = JSONObject(rest("POST", "rpc/my_status", "{}"))
            Prefs.isAdmin = o.optBoolean("is_admin", false)
            Prefs.approved = o.optBoolean("approved", true)
        } catch (_: Exception) {
        }
    }

    /** מחיקת החשבון וכל הרשומות שהמשתמש הוסיף לספר הכללי */
    suspend fun deleteAccount() = withContext(Dispatchers.IO) {
        rest("POST", "rpc/delete_my_account", "{}")
        Prefs.clearSession()
    }

    /** דיווח על תשובה לא תקינה של העוזרת */
    suspend fun reportAi(question: String, answer: String) = withContext(Dispatchers.IO) {
        rest(
            "POST", "ai_reports",
            JSONObject().put("question", question.take(2000)).put("answer", answer.take(4000)).toString(),
            mapOf("Prefer" to "return=minimal")
        )
    }

    @Synchronized
    private fun token(): String {
        if (!loggedIn()) throw ApiError("יש להתחבר בהגדרות")
        if (System.currentTimeMillis() < Prefs.tokenExpiry && Prefs.accessToken.isNotBlank()) return Prefs.accessToken
        try {
            saveSession(auth("token?grant_type=refresh_token", JSONObject().put("refresh_token", Prefs.refreshToken)))
        } catch (e: ApiError) {
            if (e.message?.contains("(401)") == true || e.message?.contains("(403)") == true || e.message?.contains("400") == true) {
                Prefs.clearSession()
                throw ApiError("פג תוקף ההתחברות – התחבר שוב")
            }
            throw e
        }
        return Prefs.accessToken
    }

    /** קריאה לפונקציה בשרת (Edge Function) */
    fun function(name: String, body: String): String {
        requireConfigured()
        val req = Request.Builder()
            .url("${Prefs.serverUrl}/functions/v1/$name")
            .header("apikey", Prefs.serverKey)
            .header("Authorization", "Bearer ${token()}")
            .post(body.toRequestBody(Net.JSON))
            .build()
        Net.client.newCall(req).execute().use { r ->
            val text = r.body?.string() ?: ""
            if (r.isSuccessful) return text
            val msg = try {
                JSONObject(text).let { o -> o.optJSONObject("error")?.optString("message") ?: o.optString("msg").ifBlank { o.optString("message") } }
            } catch (_: Exception) { "" }
            throw ApiError(
                when {
                    r.code == 404 -> "העוזרת עוד לא הותקנה בשרת. המנהל צריך להתקין אותה (הוראות בדף ההורדה)."
                    msg.isNotBlank() -> msg
                    else -> com.phonebook.app.ui.tr("שגיאת שרת {0}", r.code)
                }
            )
        }
    }

    /** בקשה ל-REST של בסיס הנתונים */
    fun rest(method: String, path: String, body: String? = null, headers: Map<String, String> = emptyMap()): String {
        requireConfigured()
        val b = Request.Builder()
            .url("${Prefs.serverUrl}/rest/v1/$path")
            .header("apikey", Prefs.serverKey)
            .header("Authorization", "Bearer ${token()}")
        headers.forEach { (k, v) -> b.header(k, v) }
        b.method(method, body?.toRequestBody(Net.JSON))
        return Net.execute(b.build())
    }
}
