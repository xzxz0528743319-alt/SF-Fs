# העלאה ל-Google Play – מדריך מלא

## א. פתיחת חשבון מפתח (פעם אחת)
1. play.google.com/console ← נרשמים עם חשבון Google.
2. סוג חשבון: **אישי**. תשלום חד-פעמי $25 ואימות זהות (תעודה מזהה).
3. בחשבון אישי חדש Google בדרך כלל דורשת **בדיקה סגורה**: כ-12 בודקים שמתקינים את האפליקציה במשך 14 יום לפני פרסום לכולם. מוסיפים את המיילים שלהם ב-Testing ← Closed testing.

## ב. יצירת האפליקציה
Create app ← שם: **ספר טלפונים** ← שפה: עברית ← App ← Free.

## ג. העלאת הגרסה
1. מורידים את `phonebook.aab` מכאן:
   https://github.com/xzxz0528743319-alt/SF-Fs/releases/latest/download/phonebook.aab
2. Testing ← Closed testing (או Production) ← Create new release ← מעלים את הקובץ.
3. כשנשאלים על **Play App Signing** – מאשרים (Google שומרת את מפתח החתימה הסופי).

## ד. טקסטים לדף בחנות (Store listing)

**שם:** ספר טלפונים

**תיאור קצר (עד 80 תווים):**
חייגן, הודעות וספר טלפונים כללי ואישי – בעברית, בלי פרסומות ובלי מעקב.

**תיאור מלא:**
ספר טלפונים הוא אפליקציית טלפון מלאה בעברית: חייגן, קבלת שיחות, הודעות SMS וספר טלפונים – בלי פרסומות ובלי מעקב.

• חייגן ויומן שיחות מקובץ לפי ימים
• מסך שיחה עם השתקה, רמקול, המתנה ובחירת כרטיס SIM
• זיהוי מתקשר לפי הספר הכללי והספר האישי
• הודעות SMS – קבלה, שליחה ושיחות
• ספר כללי משותף: חיפוש לפי שם, עיר, חם, שטיבל או מספר, וסינון ארץ / חו"ל / עיר
• ספר אישי פרטי – נשמר רק בטלפון שלך
• כרטיס איש קשר עם חיוג, וואטסאפ ו-SMS בלחיצה
• ייבוא מקבצי VCF ו-CSV וגיבוי ל-CSV
• סיסמת מחיקה ומצב כהה
• עוזרת AI אופציונלית לניסוח הודעות ומציאת אנשי קשר

רק מי שהוסיף רשומה לספר הכללי יכול לערוך או למחוק אותה. כתובות מייל לא מתפרסמות.

**קטגוריה:** Communication (תקשורת)
**מדיניות פרטיות (Privacy policy):**
https://github.com/xzxz0528743319-alt/SF-Fs/blob/main/PRIVACY.md

**תמונות נדרשות:** אייקון 512×512, תמונה ראשית 1024×500, ולפחות 2 צילומי מסך מהטלפון. (אפשר לבקש ממני להכין את האייקון והתמונה הראשית.)

## ה. הצהרת הרשאות (Permissions declaration) – חשוב
ב-App content ← **Sensitive permissions** Google תשאל על SMS ויומן שיחות. עונים:
- **Core functionality:** Default Phone handler + Default SMS handler
- **הסבר:** "The app is a full replacement dialer and SMS app. It must be the default phone and SMS handler to place and receive calls, show the call log, and send and receive SMS."
- **סרטון:** Google מבקשת סרטון קצר (YouTube, לא רשום) שמראה: הגדרת האפליקציה כברירת מחדל, חיוג, קבלת שיחה, שליחה וקבלה של SMS. מצלמים מסך בטלפון (הקלטת מסך).

**Full screen intent:** כשנשאלים – "Calling app: shows incoming calls on the lock screen".

## ו. Data safety (בטיחות נתונים)
- **Data collected:** Email address (Account management) · Name, Phone number, Address – רק מה שהמשתמש מוסיף לספר הכללי (App functionality) · Other user-generated content – דיווחים על העוזרת (App functionality).
- **Shared with third parties:** כן – כשמשתמשים בעוזרת: הודעות ותוכן אנשי קשר מהספר הכללי נשלחים ל-Anthropic (App functionality). אם לא רוצים לסמן את זה – אפשר לבקש ממני להוריד את העוזרת מגרסת החנות.
- **Encrypted in transit:** Yes
- **Users can request deletion:** Yes – בתוך האפליקציה
- **Delete account URL:** https://github.com/xzxz0528743319-alt/SF-Fs/blob/main/PRIVACY.md

## ז. שאר השאלות ב-App content
- Ads: **No ads**
- Target audience: **18+** (או 13+)
- Content rating: ממלאים את השאלון – Communication app, משתמשים יכולים לתקשר זה עם זה (כן), אין אלימות וכו'.
- Government app: No · Financial features: None · Health: No
- AI-generated content: Yes – העוזרת יוצרת טקסט; יש כפתור "דווח" על תשובות.
- App access: האפליקציה עובדת בלי התחברות. לספר הכללי – לתת לבודקים של Google משתמש לדוגמה (מייל+סיסמה) שפתחת בשרת.

## ח. עדכונים
בכל פעם שמעלים Phonebook.zip חדש ל-GitHub נבנה קובץ `phonebook.aab` חדש עם מספר גרסה גבוה יותר. מעלים אותו ב-Play Console ← Create new release.
