package com.phonebook.app.call

import com.phonebook.app.ui.tr
import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.telecom.TelecomManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.phonebook.app.App
import com.phonebook.app.MainActivity
import com.phonebook.app.R
import com.phonebook.app.data.CallerId

/**
 * כשהאפליקציה היא אפליקציית הטלפון, המערכת מבקשת ממנה להציג את ההתראה על שיחות שלא נענו.
 */
class MissedCallReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelecomManager.ACTION_SHOW_MISSED_CALLS_NOTIFICATION) return
        val count = intent.getIntExtra(TelecomManager.EXTRA_NOTIFICATION_COUNT, 0)
        val claimed = intent.getStringExtra(TelecomManager.EXTRA_NOTIFICATION_PHONE_NUMBER) ?: ""
        if (count <= 0) { MissedCalls.cancel(context); return }
        // אבטחה: אפליקציה אחרת יכולה לשלוח "שיחה שלא נענתה" מזויפת עם מספר משלה (למשל 1900…),
        // כדי שנלחץ "חזור". לכן מציגים מספר רק אם הוא באמת ביומן השיחות כשיחה שלא נענתה מהיום האחרון
        val pending = goAsync()
        Thread {
            try {
                // המערכת שולחת את זה שוב אחרי כל הדלקה של הטלפון – גם על שיחות ישנות שכבר הודענו עליהן.
                // לכן מודיעים רק על שיחות שלא נענו שעוד לא הודענו עליהן, ומהיומיים האחרונים בלבד.
                // (המספר נלקח מיומן השיחות עצמו – לא מההודעה, שאפליקציה אחרת יכולה לזייף)
                fun fresh() = MissedCalls.unseen(context)
                val list = fresh().ifEmpty { Thread.sleep(1500); fresh() }   // היומן לפעמים נכתב רגע אחרי ההודעה
                if (list.isEmpty()) return@Thread
                val latest = list.maxBy { it.date }
                val premium = latest.number.filter { it.isDigit() }.removePrefix("972").trimStart('0').startsWith("19")
                // כמה בסך הכול מאז שפתחת את היומן בפעם האחרונה (כולל כאלה שכבר הודענו עליהן)
                val total = MissedCalls.unseen(context, com.phonebook.app.data.Prefs.missedClearedAt).size.coerceAtLeast(list.size)
                MissedCalls.show(context, total, if (premium) "" else latest.number)
                com.phonebook.app.data.Prefs.missedSeenAt = latest.date
            } finally { pending.finish() }
        }.start()
    }
}

object MissedCalls {
    private const val ID = 3001

    /** שיחות שלא נענו מהיומיים האחרונים שעוד לא הודענו עליהן */
    internal fun unseen(ctx: Context, after: Long = com.phonebook.app.data.Prefs.missedSeenAt): List<com.phonebook.app.data.LogItem> {
        val since = maxOf(System.currentTimeMillis() - 48 * 3600_000L, after)
        return runCatching {
            com.phonebook.app.data.LogRepo.load(ctx, 1).filter { it.date > since && it.kind == com.phonebook.app.data.LogKind.MISSED }
        }.getOrDefault(emptyList())
    }

    /** מסמן את כל השיחות שלא נענו כ"נראו" – כדי שהמערכת לא תציג אותן שוב אחרי הדלקה */
    private fun markRead(ctx: Context) {
        val now = System.currentTimeMillis()
        com.phonebook.app.data.Prefs.missedSeenAt = maxOf(com.phonebook.app.data.Prefs.missedSeenAt, now)
        com.phonebook.app.data.Prefs.missedClearedAt = now
        Thread {
            runCatching {
                val v = android.content.ContentValues().apply {
                    put(android.provider.CallLog.Calls.NEW, 0)
                    put(android.provider.CallLog.Calls.IS_READ, 1)
                }
                ctx.contentResolver.update(
                    android.provider.CallLog.Calls.CONTENT_URI, v,
                    "${android.provider.CallLog.Calls.TYPE} = ? AND (${android.provider.CallLog.Calls.NEW} = 1 OR ${android.provider.CallLog.Calls.IS_READ} = 0)",
                    arrayOf(android.provider.CallLog.Calls.MISSED_TYPE.toString())
                )
            }
        }.start()
    }

    @SuppressLint("MissingPermission")
    fun show(ctx: Context, count: Int, number: String) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val name = if (number.isNotBlank()) CallerId.lookup(ctx, number)?.name ?: number else ""
        val open = PendingIntent.getActivity(
            ctx, 31, Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_CALLS, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val b = NotificationCompat.Builder(ctx, App.CH_MISSED)
            .setSmallIcon(R.drawable.ic_stat_phone)
            .setContentTitle(if (count == 1) tr("שיחה שלא נענתה") else tr("{0} שיחות שלא נענו", count))
            .setContentText(if (name.isNotBlank()) name else tr("לחץ כדי לראות ביומן"))
            .setCategory(NotificationCompat.CATEGORY_MISSED_CALL)
            .setContentIntent(open)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setDeleteIntent(PendingIntent.getBroadcast(ctx, 34, Intent(ctx, MissedSeenReceiver::class.java), PendingIntent.FLAG_IMMUTABLE))
        if (number.isNotBlank()) {
            b.addAction(
                0, tr("התקשר חזרה"),
                PendingIntent.getActivity(
                    ctx, 32,
                    Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)).setClass(ctx, MainActivity::class.java)
                        .putExtra(MainActivity.EXTRA_CALL_NOW, true).also { MainActivity.sign(it) }
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            b.addAction(0, tr("⏰ בעוד שעה"), com.phonebook.app.drive.Reminders.broadcast(ctx, com.phonebook.app.drive.Reminders.ACTION_LATER, number, 60, ID))
            b.addAction(
                0, tr("הודעה"),
                PendingIntent.getActivity(
                    ctx, 33,
                    Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_SMS, number)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
        }
        try {
            NotificationManagerCompat.from(ctx).notify(ID, b.build())
        } catch (_: Exception) {
        }
    }

    /** נקרא כשהמשתמש פותח את יומן השיחות */
    fun cancel(ctx: Context) {
        NotificationManagerCompat.from(ctx).cancel(ID)
        markRead(ctx)
        try {
            ctx.getSystemService(TelecomManager::class.java).cancelMissedCallsNotification()
        } catch (_: Exception) {
        }
    }
}

/** כשמחליקים את ההתראה הצידה – מסמנים שראית, כדי שלא תחזור אחרי הדלקה */
class MissedSeenReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { MissedCalls.cancel(context) }
}
