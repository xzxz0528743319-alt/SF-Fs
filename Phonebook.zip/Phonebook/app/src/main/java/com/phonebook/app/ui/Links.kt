package com.phonebook.app.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration

/** הופך קישורים ומספרי טלפון בתוך הודעה ללחיצים: קישור נפתח בדפדפן, מספר נפתח בחייגן */
internal fun linkify(text: String, linkColor: Color): AnnotatedString {
    data class Hit(val start: Int, val end: Int, val url: String?, val phone: String?)
    val hits = mutableListOf<Hit>()
    for (m in URL.findAll(text)) {
        var v = m.value.trimEnd('.', ',', '!', '?', ')', ']', '"', '\'', ':', ';', '״')
        if (v.isEmpty()) continue
        val url = if (v.startsWith("http://", true) || v.startsWith("https://", true)) v else "https://$v"
        hits += Hit(m.range.first, m.range.first + v.length, url, null)
    }
    for (m in PHONE.findAll(text)) {
        if (hits.any { m.range.first < it.end && m.range.last >= it.start }) continue
        val n = m.value.filter { it.isDigit() || it == '+' }
        if (n.count { it.isDigit() } in 7..15) hits += Hit(m.range.first, m.range.last + 1, null, n)
    }
    if (hits.isEmpty()) return AnnotatedString(text)
    hits.sortBy { it.start }
    val span = SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)
    return buildAnnotatedString {
        append(text)
        var pos = 0
        for (h in hits) {
            if (h.start < pos) continue
            addStyle(span, h.start, h.end)
            if (h.url != null) addStringAnnotation("url", h.url, h.start, h.end)
            else addStringAnnotation("tel", h.phone ?: "", h.start, h.end)
            pos = h.end
        }
    }
}

/** קישור/מספר שנלחץ בתוך טקסט */
internal data class LinkHit(val kind: String, val value: String, val shown: String)

internal fun linkAt(text: AnnotatedString, offset: Int): LinkHit? {
    val a = text.getStringAnnotations(offset, offset).firstOrNull { it.tag == "url" || it.tag == "tel" } ?: return null
    return LinkHit(a.tag, a.item, text.text.substring(a.start, a.end))
}

private val URL = Regex(
    "(?i)(?<![@\\w.-])(?:https?://[^\\s<>\"]+|www\\.[^\\s<>\"]+|[a-z0-9][a-z0-9-]*(?:\\.[a-z0-9-]+)*\\.(?:com|net|org|il|ly|me|io|app|co|info|biz|gov|edu|link|site|online|shop|tv|to|gl|gle|ai|dev)(?:/[^\\s<>\"]*)?)(?![\\w.-]*@)"
)
private val PHONE = Regex("(?<![\\d/.:])\\+?\\d[\\d\\- ()]{5,20}\\d(?![\\d/.:])")
