-- ספר טלפונים – הקמת בסיס הנתונים של הספר הכללי ב-Supabase
-- מריצים פעם אחת: Supabase → SQL Editor → מדביקים את כל הקובץ → Run

create table if not exists public.contacts (
  id          uuid primary key default gen_random_uuid(),
  owner       uuid default auth.uid() references auth.users(id) on delete set null,
  name        text not null,
  phone       text not null default '',
  phone2      text not null default '',
  city        text not null default '',
  address     text not null default '',
  father      text not null default '',
  chem        text not null default '',
  shtibel     text not null default '',
  email       text not null default '',   -- נשמר אבל לעולם לא מתפרסם
  deleted     boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists contacts_updated_idx on public.contacts (updated_at, id);

-- עדכון אוטומטי של זמן השינוי (לסנכרון)
create or replace function public.contacts_touch() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  -- אי אפשר להעביר בעלות (מותר רק לרוקן אותה כשחשבון נמחק)
  if new.owner is not null then new.owner = old.owner; end if;
  return new;
end $$;

drop trigger if exists contacts_touch on public.contacts;
create trigger contacts_touch before update on public.contacts
  for each row execute function public.contacts_touch();

-- הרשאות: כל משתמש רואה ומשנה ישירות רק את הרשומות שהוא הוסיף
alter table public.contacts enable row level security;

drop policy if exists "read own"   on public.contacts;
drop policy if exists "insert own" on public.contacts;
drop policy if exists "update own" on public.contacts;

create policy "read own"   on public.contacts for select using (owner = auth.uid());
create policy "insert own" on public.contacts for insert with check (owner = auth.uid());
create policy "update own" on public.contacts for update using (owner = auth.uid()) with check (owner = auth.uid());
-- אין הרשאת DELETE: מחיקה = סימון deleted, כדי שכל הטלפונים יידעו להסיר את הרשומה

-- תצוגה ציבורית לכל המשתמשים המחוברים – בלי עמודת האימייל
create or replace view public.contacts_public as
  select id, owner, name, phone, phone2, city, address, father, chem, shtibel, deleted, updated_at
  from public.contacts;

revoke all on public.contacts_public from anon, public;
grant select on public.contacts_public to authenticated;
revoke all on public.contacts from anon;

-- מחיקת חשבון: הרשומות של המשתמש מסומנות כמחוקות ומרוקנות (כדי שכל הטלפונים יסירו אותן), ואז החשבון נמחק
create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  update public.contacts
     set deleted = true, name = '', phone = '', phone2 = '', city = '', address = '',
         father = '', chem = '', shtibel = '', email = ''
   where owner = auth.uid();
  delete from auth.users where id = auth.uid();
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- דיווחים על תשובות של העוזרת (נדרש במדיניות התוכן של Google Play)
create table if not exists public.ai_reports (
  id          bigserial primary key,
  reporter    uuid default auth.uid() references auth.users(id) on delete set null,
  question    text not null default '',
  answer      text not null default '',
  created_at  timestamptz not null default now()
);
alter table public.ai_reports enable row level security;
drop policy if exists "insert reports" on public.ai_reports;
create policy "insert reports" on public.ai_reports for insert to authenticated with check (true);
