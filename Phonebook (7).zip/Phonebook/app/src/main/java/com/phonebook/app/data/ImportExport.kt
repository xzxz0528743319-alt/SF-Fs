package com.phonebook.app.data

import android.content.Context
import android.net.Uri
import com.phonebook.app.net.Server
import com.phonebook.app.net.SharedBook
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.UUID

data class ImportResult(val personal: Int, val shared: Int, val skippedShared: Int, val duplicates: Int)

/** ייבוא קבצי VCF / CSV וגיבוי לקובץ CSV */
object ImportExport {

    private val HEADERS = mapOf(
        "name" to listOf("שם", "שם מלא", "name", "full name"),
        "phone" to listOf("טלפון", "טלפון 1", "נייד", "phone", "mobile"),
        "phone2" to listOf("טלפון 2", "טלפון2", "phone 2", "phone2"),
        "city" to listOf("עיר", "city"),
        "address" to listOf("כתובת", "address"),
        "father" to listOf("שם האב", "father"),
        "chem" to listOf("חם", "חותן"),
        "shtibel" to listOf("שטיבל", "בית כנסת"),
        "email" to listOf("אימייל", "מייל", "דואל", "email", "e-mail"),
        "book" to listOf("ספר", "book"),
    )
    private val ORDER = listOf("name", "phone", "phone2", "city", "address", "father", "chem", "shtibel", "email", "book")
    private val HEB_HEADER = listOf("שם", "טלפון", "טלפון 2", "עיר", "כתובת", "שם האב", "חם", "שטיבל", "אימייל", "ספר")

    suspend fun import(ctx: Context, uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("לא ניתן לקרוא את הקובץ")
        val text = decode(bytes).removePrefix("﻿")

        val personal = mutableListOf<Contact>()
        val shared = mutableListOf<Contact>()
        if (text.trimStart().startsWith("BEGIN:VCARD", ignoreCase = true)) {
            personal += parseVcf(text)
        } else {
            parseCsvContacts(text).forEach { (c, isShared) -> if (isShared) shared += c else personal += c }
        }

        // לא מכפילים מספר שכבר קיים בספר האישי
        val seen = HashSet<String>()
        val fresh = personal.filter { c ->
            val t = Phone.tail(c.phone)
            t.isNotEmpty() && seen.add(t) && LocalDb.findByPhone(LocalDb.PERSONAL, c.phone) == null
        }
        LocalDb.upsertAll(LocalDb.PERSONAL, fresh)

        var sharedCount = 0
        var skipped = 0
        if (shared.isNotEmpty()) {
            if (Server.loggedIn()) {
                SharedBook.addMany(shared)
                sharedCount = shared.size
            } else skipped = shared.size
        }
        ImportResult(fresh.size, sharedCount, skipped, personal.size - fresh.size)
    }

    /** קבצי CSV מאקסל בעברית שמורים לרוב ב-windows-1255 */
    private fun decode(bytes: ByteArray): String = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes)).toString()
    } catch (_: CharacterCodingException) {
        String(bytes, Charset.forName("windows-1255"))
    }

    // ---------------- CSV ----------------

    private fun parseCsvContacts(text: String): List<Pair<Contact, Boolean>> {
        val firstLine = text.lineSequence().firstOrNull() ?: return emptyList()
        val delim = listOf(',', ';', '\t').maxBy { d -> firstLine.count { it == d } }
        val rows = parseCsv(text, delim)
        if (rows.isEmpty()) return emptyList()

        val header = rows[0].map { it.trim().lowercase().replace(Regex("\\s+"), " ") }
        val idx = HashMap<String, Int>()
        HEADERS.forEach { (field, names) ->
            val i = header.indexOfFirst { h -> names.any { it.lowercase() == h } }
            if (i >= 0) idx[field] = i
        }
        val dataRows = if (idx.containsKey("name")) rows.drop(1) else {
            ORDER.forEachIndexed { i, f -> idx[f] = i }
            rows
        }
        return dataRows.mapNotNull { r ->
            fun f(k: String) = idx[k]?.let { r.getOrNull(it) }?.trim() ?: ""
            val name = f("name")
            val phone = f("phone").ifBlank { f("phone2") }
            if (name.isBlank() || phone.isBlank()) return@mapNotNull null
            val c = Contact(
                id = UUID.randomUUID().toString(), name = name, phone = phone,
                phone2 = if (f("phone").isBlank()) "" else f("phone2"),
                city = f("city"), address = f("address"), father = f("father"),
                chem = f("chem"), shtibel = f("shtibel"), email = f("email"),
            )
            c to f("book").contains("כלל")
        }
    }

    fun parseCsv(text: String, delim: Char): List<List<String>> {
        val rows = mutableListOf<List<String>>()
        var row = mutableListOf<String>()
        val sb = StringBuilder()
        var inQ = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (inQ) {
                if (ch == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        sb.append('"'); i++
                    } else inQ = false
                } else sb.append(ch)
            } else when (ch) {
                '"' -> inQ = true
                delim -> { row.add(sb.toString()); sb.clear() }
                '\r' -> {}
                '\n' -> { row.add(sb.toString()); sb.clear(); rows.add(row); row = mutableListOf() }
                else -> sb.append(ch)
            }
            i++
        }
        if (sb.isNotEmpty() || row.isNotEmpty()) {
            row.add(sb.toString()); rows.add(row)
        }
        return rows.filter { r -> r.any { it.isNotBlank() } }
    }

    // ---------------- VCF ----------------

    fun parseVcf(raw: String): List<Contact> {
        val lines = raw.replace("\r\n", "\n").replace("\r", "\n").replace(Regex("\n[ \t]"), "").split("\n")
        // איחוד שורות quoted-printable שנחתכו ב-'='
        val joined = mutableListOf<String>()
        var i = 0
        while (i < lines.size) {
            var l = lines[i]
            if (l.uppercase().contains("QUOTED-PRINTABLE")) {
                while (l.endsWith("=") && i + 1 < lines.size) {
                    l = l.dropLast(1) + lines[++i]
                }
            }
            joined += l
            i++
        }

        val out = mutableListOf<Contact>()
        var fn = ""; var n = ""; var email = ""; var city = ""; var addr = ""
        var phones = mutableListOf<String>()
        for (line in joined) {
            val l = line.trim()
            when {
                l.equals("BEGIN:VCARD", true) -> {
                    fn = ""; n = ""; email = ""; city = ""; addr = ""; phones = mutableListOf()
                }
                l.equals("END:VCARD", true) -> {
                    val name = fn.ifBlank { n }
                    if (name.isNotBlank() && phones.isNotEmpty()) out += Contact(
                        id = UUID.randomUUID().toString(), name = name, phone = phones[0],
                        phone2 = phones.getOrElse(1) { "" }, city = city, address = addr, email = email,
                    )
                }
                else -> {
                    val c = l.indexOf(':')
                    if (c <= 0) continue
                    val key = l.substring(0, c).uppercase()
                    var value = l.substring(c + 1)
                    if (key.contains("QUOTED-PRINTABLE")) value = qp(value)
                    value = value.replace("\\,", ",").replace("\\;", "\u0000").replace("\\n", " ").replace("\\N", " ")
                    val prop = key.substringBefore(';').substringAfter('.')
                    when (prop) {
                        "FN" -> fn = value.replace("\u0000", ";").trim()
                        "N" -> n = value.split(';').let { p ->
                            listOf(p.getOrElse(1) { "" }, p.getOrElse(0) { "" }).filter { it.isNotBlank() }.joinToString(" ")
                        }.replace("\u0000", ";").trim()
                        "TEL" -> if (value.isNotBlank()) phones += value.trim()
                        "EMAIL" -> if (email.isBlank()) email = value.trim()
                        "ADR" -> {
                            val p = value.split(';')
                            addr = p.getOrElse(2) { "" }.trim()
                            city = p.getOrElse(3) { "" }.trim()
                        }
                    }
                }
            }
        }
        return out
    }

    private fun qp(s: String): String {
        val out = ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '=' && i + 2 < s.length) {
                val b = s.substring(i + 1, i + 3).toIntOrNull(16)
                if (b != null) {
                    out.write(b); i += 3; continue
                }
            }
            out.write(ch.code and 0xFF)
            i++
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    // ---------------- גיבוי ----------------

    suspend fun exportCsv(ctx: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        fun esc(s: String) = if (s.any { it == ',' || it == '"' || it == '\n' }) "\"" + s.replace("\"", "\"\"") + "\"" else s
        fun row(c: Contact, book: String) = listOf(c.name, c.phone, c.phone2, c.city, c.address, c.father, c.chem, c.shtibel, c.email, book)
            .joinToString(",") { esc(it) }
        val personal = LocalDb.all(LocalDb.PERSONAL)
        val shared = LocalDb.all(LocalDb.SHARED)
        val sb = StringBuilder("﻿").append(HEB_HEADER.joinToString(",")).append("\r\n")
        personal.forEach { sb.append(row(it, "אישי")).append("\r\n") }
        shared.forEach { sb.append(row(it, "כללי")).append("\r\n") }
        ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(sb.toString().toByteArray(Charsets.UTF_8)) }
            ?: error("לא ניתן לשמור את הקובץ")
        personal.size + shared.size
    }
}
