@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.Assistant
import com.phonebook.app.net.Server
import kotlinx.coroutines.launch

private val SUGGESTIONS = listOf(
    "נסח הודעת מזל טוב לחתונה",
    "נסח הודעה קצרה שאני מאחר",
    "מצא את משפחת כהן מבני ברק",
)

@Composable
fun AssistantScreen(onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val history = remember { mutableStateListOf<Assistant.Msg>() }
    var input by rememberSaveable { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    var reportIndex by remember { mutableStateOf<Int?>(null) }

    fun send(q: String) {
        val text = q.trim()
        if (text.isEmpty() || busy) return
        history += Assistant.Msg(true, text)
        input = ""
        scope.launch {
            busy = true
            val reply = runCatching { Assistant.ask(history.toList()) }.getOrElse { "שגיאה: ${it.message}" }
            history += Assistant.Msg(false, reply)
            busy = false
        }
    }
    LaunchedEffect(history.size, busy) {
        val last = listState.layoutInfo.totalItemsCount - 1
        if (last > 0) listState.animateScrollToItem(last)
    }

    reportIndex?.let { i ->
        AlertDialog(
            onDismissRequest = { reportIndex = null },
            title = { Text("לדווח על התשובה?") },
            text = { Text("התשובה תוסתר ותישלח לבדיקה, כדי לשפר את העוזרת.") },
            confirmButton = {
                TextButton(onClick = {
                    reportIndex = null
                    val answer = history.getOrNull(i) ?: return@TextButton
                    val question = history.take(i).lastOrNull { it.user }?.text ?: ""
                    history[i] = Assistant.Msg(false, "התשובה דווחה והוסתרה.")
                    scope.launch {
                        runCatching { Server.reportAi(question, answer.text) }
                            .onSuccess { toast(ctx, "תודה, הדיווח נשלח") }
                            .onFailure { toast(ctx, "התשובה הוסתרה. כדי לשלוח את הדיווח צריך להתחבר בהגדרות.") }
                    }
                }) { Text("דווח") }
            },
            dismissButton = { TextButton(onClick = { reportIndex = null }) { Text("ביטול") } },
        )
    }

    Column(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                AppCard {
                    Column(Modifier.padding(16.dp)) {
                        Text("שלום! אני יכולה לנסח בשבילך הודעות ולמצוא אנשי קשר בספר הכללי.")
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "הספר האישי שלך לא נשלח לעוזרת.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
            if (Prefs.aiKey.isBlank()) item {
                InfoCard("כדי להפעיל את העוזרת צריך להוסיף מפתח API בהגדרות ← עוזרת AI. לחץ כאן.", Modifier.clickable { onSettings() })
            }
            itemsIndexed(history) { index, m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.Start else Arrangement.End) {
                    Column(horizontalAlignment = if (m.user) Alignment.Start else Alignment.End) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (m.user) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLowest,
                            shadowElevation = if (m.user) 0.dp else 1.dp,
                            modifier = Modifier.widthIn(max = 320.dp)
                        ) {
                            SelectionContainer {
                                Text(
                                    m.text, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    color = if (m.user) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                        if (!m.user) Row {
                            TextButton(onClick = {
                                clipboard.setText(AnnotatedString(m.text)); toast(ctx, "הועתק")
                            }) {
                                Icon(Icons.Filled.ContentCopy, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("העתק")
                            }
                            TextButton(onClick = { reportIndex = index }) {
                                Icon(Icons.Filled.Flag, null, Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("דווח")
                            }
                        }
                    }
                }
            }
            if (busy) item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                }
            }
        }
        if (history.isEmpty()) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SUGGESTIONS.forEach { s -> SuggestionChip(onClick = { send(s) }, label = { Text(s) }) }
            }
        }
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                placeholder = { Text("מה לנסח או את מי לחפש?") },
                maxLines = 4,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { send(input) }, enabled = !busy, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.Send, "שלח")
            }
        }
    }
}
