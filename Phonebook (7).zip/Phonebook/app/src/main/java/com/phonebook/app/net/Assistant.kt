package com.phonebook.app.net

import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * עוזרת AI: ניסוח הודעות ומציאת אנשי קשר.
 * לשיחה מצורפות רק רשומות מהספר הכללי שמתאימות לשאלה. הספר האישי לא נשלח.
 */
object Assistant {
    data class Msg(val user: Boolean, val text: String)

    suspend fun ask(history: List<Msg>): String = withContext(Dispatchers.IO) {
        val key = Prefs.aiKey
        if (key.isBlank()) throw ApiError("חסר מפתח API – הוסף אותו בהגדרות ← עוזרת AI")

        val question = history.last { it.user }.text
        val found = LinkedHashMap<String, Contact>()
        question.split(Regex("[\\s,.?!:;\"']+")).filter { it.length >= 2 }.forEach { w ->
            LocalDb.search(LocalDb.SHARED, w, 0, null, 6).forEach { found[it.id] = it }
        }
        val matches = found.values.take(20).joinToString("\n") {
            "- ${it.name} | טל׳ ${it.phone}${if (it.phone2.isNotBlank()) ", " + it.phone2 else ""} | עיר: ${it.city} | " +
                "כתובת: ${it.address} | שם האב: ${it.father} | חם: ${it.chem} | שטיבל: ${it.shtibel}"
        }

        val system = """
            את עוזרת בתוך אפליקציית ספר טלפונים בעברית. תפקידך:
            1. לנסח הודעות (SMS / וואטסאפ) בעברית טבעית, קצרה ומכבדת, בסגנון שהמשתמש מבקש.
            2. לעזור למצוא אנשי קשר בספר הכללי. השתמשי רק ברשומות שמופיעות למטה. אם אין התאמה – אמרי זאת בפשטות ואל תמציאי מספרים.
            ענִי תמיד בעברית, בקצרה. כשמנסחים הודעה – תני את נוסח ההודעה בלבד, בלי הקדמות.

            רשומות מהספר הכללי שמתאימות למילים בשאלה:
            ${matches.ifBlank { "(לא נמצאו רשומות מתאימות)" }}
        """.trimIndent()

        val msgs = JSONArray()
        history.takeLast(20).dropWhile { !it.user }.forEach {
            msgs.put(JSONObject().put("role", if (it.user) "user" else "assistant").put("content", it.text))
        }
        val body = JSONObject()
            .put("model", Prefs.aiModel)
            .put("max_tokens", 1024)
            .put("system", system)
            .put("messages", msgs)

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", key)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody(Net.JSON))
            .build()
        val content = JSONObject(Net.execute(req)).getJSONArray("content")
        buildString {
            for (i in 0 until content.length()) {
                val b = content.getJSONObject(i)
                if (b.optString("type") == "text") append(b.optString("text"))
            }
        }.trim()
    }
}
