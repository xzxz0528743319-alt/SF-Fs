package com.phonebook.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Prefs

val Brand = Color(0xFF3B82F6)
val Lavender = Color(0xFF8B7CF6)
val CallGreen = Color(0xFF22C07A)
val CallRed = Color(0xFFF0506E)

/** צבעי שמיים ועננים: כחול רך, לבנדר, ולבן אוורירי */
private val Light = lightColorScheme(
    primary = Color(0xFF3B82F6),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDEAFF),
    onPrimaryContainer = Color(0xFF0B3A86),
    secondary = Color(0xFF8B7CF6),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD6E6FF),
    onSecondaryContainer = Color(0xFF1E2F5C),
    tertiary = Color(0xFF38BDF8),
    background = Color(0xFFF5F9FF),
    onBackground = Color(0xFF15233D),
    surface = Color(0xFFF5F9FF),
    onSurface = Color(0xFF15233D),
    onSurfaceVariant = Color(0xFF64748B),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color.White,
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFEAF2FF),
    surfaceContainerHighest = Color(0xFFDDE8FA),
    outlineVariant = Color(0xFFE3ECF8),
)

/** מצב כהה: שמי לילה */
private val Dark = darkColorScheme(
    primary = Color(0xFF7AA8FF),
    onPrimary = Color(0xFF0A1E46),
    primaryContainer = Color(0xFF1E3A6E),
    onPrimaryContainer = Color(0xFFDDEAFF),
    secondary = Color(0xFFA99CFF),
    onSecondary = Color(0xFF1C1450),
    secondaryContainer = Color(0xFF15264A),
    onSecondaryContainer = Color(0xFFDDE6FF),
    tertiary = Color(0xFF5CCBFA),
    background = Color(0xFF0B1426),
    onBackground = Color(0xFFE6EDFA),
    surface = Color(0xFF0B1426),
    onSurface = Color(0xFFE6EDFA),
    onSurfaceVariant = Color(0xFF94A3BD),
    surfaceContainerLowest = Color(0xFF14213A),
    surfaceContainerLow = Color(0xFF14213A),
    surfaceContainer = Color(0xFF14213A),
    surfaceContainerHigh = Color(0xFF1B2B4A),
    surfaceContainerHighest = Color(0xFF233559),
    outlineVariant = Color(0xFF22324F),
)

/** רקע השמיים של המסכים: מעבר רך מתכלת למעלה ללבן למטה */
@Composable
fun skyBrush(): Brush = Brush.verticalGradient(
    listOf(MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.background)
)

/** מעבר צבע לכפתורים ולמסך השיחה */
val BrandGradient = Brush.linearGradient(listOf(Color(0xFF4F8DFF), Color(0xFF8B7CF6)))

@Composable
fun PhonebookTheme(content: @Composable () -> Unit) {
    val mode by Prefs.theme.collectAsState()
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(22.dp),
            large = RoundedCornerShape(30.dp),
        ),
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, content = content)
    }
}
