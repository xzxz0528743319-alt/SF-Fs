package com.phonebook.app.net

import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

/**
 * הספר הכללי המשותף.
 * קריאה: מהתצוגה contacts_public (בלי אימייל).
 * כתיבה: לטבלה contacts – השרת מאפשר עריכה/מחיקה רק למי שהוסיף.
 */
object SharedBook {
    private const val COLS = "id,owner,name,phone,phone2,city,address,father,chem,shtibel,deleted,updated_at"
    private const val PAGE = 1000

    fun canEdit(c: Contact) = Server.loggedIn() && c.owner.isNotBlank() && c.owner == Prefs.userId

    /** מושך רק מה שהשתנה מאז הסנכרון האחרון. מחזיר כמה רשומות עודכנו. */
    suspend fun sync(): Int = withContext(Dispatchers.IO) {
        val since = Prefs.lastSync
        var maxTs = since
        var offset = 0
        var total = 0
        while (true) {
            val filter = if (since.isBlank()) "" else "&updated_at=gt." + URLEncoder.encode(since, "UTF-8")
            val arr = JSONArray(
                Server.rest("GET", "contacts_public?select=$COLS$filter&order=updated_at.asc,id.asc&limit=$PAGE&offset=$offset")
            )
            val live = mutableListOf<Contact>()
            val dead = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ts = o.optString("updated_at")
                if (ts > maxTs) maxTs = ts
                if (o.optBoolean("deleted")) dead += o.getString("id") else live += fromJson(o)
            }
            LocalDb.upsertAll(LocalDb.SHARED, live, dead)
            total += arr.length()
            offset += arr.length()
            if (arr.length() < PAGE) break
        }
        Prefs.lastSync = maxTs
        total
    }

    private fun fromJson(o: JSONObject) = Contact(
        id = o.getString("id"),
        name = o.optString("name"), phone = o.optString("phone"), phone2 = o.optString("phone2"),
        city = o.optString("city"), address = o.optString("address"), father = o.optString("father"),
        chem = o.optString("chem"), shtibel = o.optString("shtibel"), owner = o.optString("owner"),
    )

    private fun toJson(c: Contact) = JSONObject()
        .put("name", c.name.trim()).put("phone", c.phone.trim()).put("phone2", c.phone2.trim())
        .put("city", c.city.trim()).put("address", c.address.trim()).put("father", c.father.trim())
        .put("chem", c.chem.trim()).put("shtibel", c.shtibel.trim()).put("email", c.email.trim())

    private val minimal = mapOf("Prefer" to "return=minimal")

    suspend fun add(c: Contact) {
        withContext(Dispatchers.IO) { Server.rest("POST", "contacts", toJson(c).toString(), minimal) }
        sync()
    }

    suspend fun addMany(list: List<Contact>) {
        withContext(Dispatchers.IO) {
            list.chunked(500).forEach { chunk ->
                val arr = JSONArray()
                chunk.forEach { arr.put(toJson(it)) }
                Server.rest("POST", "contacts", arr.toString(), minimal)
            }
        }
        sync()
    }

    suspend fun update(c: Contact) {
        withContext(Dispatchers.IO) { Server.rest("PATCH", "contacts?id=eq.${c.id}", toJson(c).toString(), minimal) }
        sync()
    }

    suspend fun delete(id: String) {
        withContext(Dispatchers.IO) {
            Server.rest("PATCH", "contacts?id=eq.$id", JSONObject().put("deleted", true).toString(), minimal)
        }
        sync()
    }
}
