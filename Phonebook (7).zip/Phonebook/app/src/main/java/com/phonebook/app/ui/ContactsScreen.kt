@file:OptIn(ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs
import com.phonebook.app.net.Server
import com.phonebook.app.net.SharedBook
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

private const val MAX_RESULTS = 500

@Composable
fun ContactsScreen(
    shared: Boolean,
    onCall: (String) -> Unit,
    onSms: (String) -> Unit,
    onEdit: (Contact) -> Unit,
    onSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val table = if (shared) LocalDb.SHARED else LocalDb.PERSONAL

    // מצב נפרד לכל ספר
    var query by rememberSaveable(shared) { mutableStateOf("") }
    var region by rememberSaveable(shared) { mutableIntStateOf(0) }
    var city by rememberSaveable(shared) { mutableStateOf<String?>(null) }
    var selected by remember(shared) { mutableStateOf<Contact?>(null) }
    var toDelete by remember(shared) { mutableStateOf<Contact?>(null) }
    var syncing by remember { mutableStateOf(false) }

    val dbv by LocalDb.changes.collectAsState()
    val session by Prefs.session.collectAsState()
    val result by produceState<List<Contact>?>(null, shared, query, region, city, dbv) {
        value = withContext(Dispatchers.IO) { LocalDb.search(table, query, region, city, MAX_RESULTS) }
    }
    val total by produceState(0, shared, dbv) { value = withContext(Dispatchers.IO) { LocalDb.count(table) } }
    val cities by produceState(emptyList<String>(), shared, dbv) { value = withContext(Dispatchers.IO) { LocalDb.cities(table) } }

    fun sync() {
        if (syncing || !Server.loggedIn()) return
        scope.launch {
            syncing = true
            runCatching { SharedBook.sync() }.onFailure { toast(ctx, it.message ?: "הסנכרון נכשל") }
            syncing = false
        }
    }
    if (shared) LaunchedEffect(session) { if (session != null) sync() }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("חיפוש: שם, עיר, חם, שטיבל או מספר") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "נקה") }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf("הכל", "ארץ", "חו\"ל").forEachIndexed { i, label ->
                FilterChip(selected = region == i, onClick = { region = i }, label = { Text(label) })
            }
            var menu by remember { mutableStateOf(false) }
            Box {
                FilterChip(
                    selected = city != null,
                    onClick = { menu = true },
                    label = { Text(city ?: "עיר") },
                    trailingIcon = { Icon(Icons.Filled.ArrowDropDown, null) }
                )
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("כל הערים") }, onClick = { city = null; menu = false })
                    cities.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { city = c; menu = false }) }
                }
            }
        }

        if (shared && session == null) {
            InfoCard(
                "הספר הכללי משותף לכל המשתמשים. כדי לראות אותו ולהוסיף אליו – התחבר בהגדרות.",
                Modifier.padding(horizontal = 16.dp, vertical = 6.dp).clickable { onSettings() }
            )
        }
        if (!shared) {
            Text(
                "נשמר רק בטלפון שלך ולא נשלח לשרת",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 22.dp)
            )
        }

        val list = result
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            val shown = list?.size ?: 0
            Text(
                if (shown >= MAX_RESULTS) "מוצגים $shown מתוך $total – צמצם בחיפוש" else "$shown מתוך $total",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            if (shared && session != null) {
                if (syncing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                else IconButton(onClick = { sync() }) { Icon(Icons.Filled.Refresh, "סנכרון", tint = MaterialTheme.colorScheme.primary) }
            }
        }

        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            list.isEmpty() -> EmptyState(
                when {
                    query.isNotBlank() || city != null || region != 0 -> "לא נמצאו תוצאות"
                    shared -> "הספר הכללי ריק"
                    else -> "עדיין אין אנשי קשר. לחץ + כדי להוסיף, או ייבא קובץ בהגדרות."
                }
            )
            else -> LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(list, key = { it.id }) { c -> ContactRow(c, onCall) { selected = c } }
            }
        }
    }

    selected?.let { c ->
        val canEdit = !shared || SharedBook.canEdit(c)
        ContactCardDialog(
            c, shared, canEdit,
            onDismiss = { selected = null },
            onCall = onCall,
            onSms = { selected = null; onSms(it) },
            onEdit = { selected = null; onEdit(c) },
            onDelete = { selected = null; toDelete = c },
        )
    }

    toDelete?.let { c ->
        DeleteDialog(c, onDismiss = { toDelete = null }) {
            toDelete = null
            if (!shared) {
                LocalDb.delete(LocalDb.PERSONAL, c.id)
            } else scope.launch {
                runCatching { SharedBook.delete(c.id) }
                    .onSuccess { toast(ctx, "נמחק") }
                    .onFailure { toast(ctx, it.message ?: "המחיקה נכשלה") }
            }
        }
    }
}

@Composable
private fun ContactRow(c: Contact, onCall: (String) -> Unit, onClick: () -> Unit) {
    AppCard(Modifier.clickable(onClick = onClick)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(c.name)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(c.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val sub = listOf(c.city, c.shtibel, if (c.chem.isNotBlank()) "חם: ${c.chem}" else "").filter { it.isNotBlank() }.joinToString(" · ")
                Text(
                    sub.ifBlank { ltr(c.phone) }, style = MaterialTheme.typography.bodySmall, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { onCall(c.phone) }) { Icon(Icons.Filled.Call, "התקשר", tint = MaterialTheme.colorScheme.primary) }
        }
    }
}

@Composable
private fun ContactCardDialog(
    c: Contact, shared: Boolean, canEdit: Boolean,
    onDismiss: () -> Unit, onCall: (String) -> Unit, onSms: (String) -> Unit,
    onEdit: () -> Unit, onDelete: () -> Unit,
) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("סגור") } },
        dismissButton = {
            if (canEdit) Row {
                TextButton(onClick = onDelete) { Text("מחק", color = CallRed) }
                TextButton(onClick = onEdit) { Text("ערוך") }
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(c.name, 48.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(c.name, fontWeight = FontWeight.Bold)
                    Text(
                        if (shared) "ספר כללי" else "ספר אישי",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    CardAction(Icons.Filled.Call, "התקשר", CallGreen) { onCall(c.phone) }
                    CardAction(Icons.Filled.Chat, "וואטסאפ", Color(0xFF25D366)) { Actions.whatsapp(ctx, c.phone) }
                    CardAction(Icons.Filled.Sms, "SMS", Brand) { onSms(c.phone) }
                }
                Spacer(Modifier.height(12.dp))
                Field("טלפון", ltr(c.phone)) { onCall(c.phone) }
                if (c.phone2.isNotBlank()) Field("טלפון 2", ltr(c.phone2)) { onCall(c.phone2) }
                Field("עיר", c.city)
                Field("כתובת", c.address)
                Field("שם האב", c.father)
                Field("חם", c.chem)
                Field("שטיבל", c.shtibel)
                if (!shared) Field("אימייל", c.email)
                if (shared && !canEdit) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "רק מי שהוסיף את הרשומה יכול לערוך או למחוק אותה",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        shape = RoundedCornerShape(28.dp),
    )
}

@Composable
private fun CardAction(icon: ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(shape = RoundedCornerShape(18.dp), color = color.copy(alpha = 0.14f)) {
            Icon(icon, null, tint = color, modifier = Modifier.padding(12.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun Field(label: String, value: String, onClick: (() -> Unit)? = null) {
    if (value.isBlank()) return
    Column(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(vertical = 6.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge, color = if (onClick != null) Brand else MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun DeleteDialog(c: Contact, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    val needPw = Prefs.hasDeletePassword
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("למחוק את ${c.name}?") },
        text = {
            if (needPw) OutlinedTextField(
                pw, { pw = it; wrong = false },
                label = { Text("סיסמת מחיקה") },
                isError = wrong,
                supportingText = { if (wrong) Text("סיסמה שגויה") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            ) else Text("לא ניתן לבטל את הפעולה.")
        },
        confirmButton = {
            TextButton(onClick = { if (Prefs.checkDeletePassword(pw)) onConfirm() else wrong = true }) {
                Text("מחק", color = CallRed)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ביטול") } },
    )
}

// ---------------- הוספה / עריכה ----------------

@Composable
fun ContactEditor(initial: Contact?, initialShared: Boolean, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val isNew = initial == null
    var shared by rememberSaveable { mutableStateOf(initialShared) }
    var name by rememberSaveable { mutableStateOf(initial?.name ?: "") }
    var phone by rememberSaveable { mutableStateOf(initial?.phone ?: "") }
    var phone2 by rememberSaveable { mutableStateOf(initial?.phone2 ?: "") }
    var city by rememberSaveable { mutableStateOf(initial?.city ?: "") }
    var address by rememberSaveable { mutableStateOf(initial?.address ?: "") }
    var father by rememberSaveable { mutableStateOf(initial?.father ?: "") }
    var chem by rememberSaveable { mutableStateOf(initial?.chem ?: "") }
    var shtibel by rememberSaveable { mutableStateOf(initial?.shtibel ?: "") }
    var email by rememberSaveable { mutableStateOf(initial?.email ?: "") }
    var saving by remember { mutableStateOf(false) }

    fun save() {
        if (name.isBlank() || phone.isBlank()) {
            toast(ctx, "חובה למלא שם וטלפון"); return
        }
        val c = Contact(
            id = initial?.id ?: UUID.randomUUID().toString(), name = name, phone = phone, phone2 = phone2,
            city = city, address = address, father = father, chem = chem, shtibel = shtibel, email = email,
            owner = initial?.owner ?: "",
        )
        if (!shared) {
            LocalDb.upsert(LocalDb.PERSONAL, c)
            onClose()
            return
        }
        if (!Server.loggedIn()) {
            toast(ctx, "כדי להוסיף לספר הכללי צריך להתחבר בהגדרות"); return
        }
        scope.launch {
            saving = true
            runCatching { if (isNew) SharedBook.add(c) else SharedBook.update(c) }
                .onSuccess { onClose() }
                .onFailure { toast(ctx, it.message ?: "השמירה נכשלה") }
            saving = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar(if (isNew) "איש קשר חדש" else "עריכת איש קשר", onClose) {
            if (saving) CircularProgressIndicator(Modifier.size(22.dp).padding(end = 4.dp), strokeWidth = 2.dp)
            TextButton(onClick = { save() }, enabled = !saving) { Text("שמור", fontWeight = FontWeight.Bold) }
        }
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (isNew) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !shared, onClick = { shared = false }, label = { Text("ספר אישי") })
                    FilterChip(selected = shared, onClick = { shared = true }, label = { Text("ספר כללי") })
                }
                Text(
                    if (shared) "יופיע בחיפוש של כל המשתמשים. האימייל לא מתפרסם."
                    else "נשמר רק בטלפון שלך, ולא יופיע אצל אף אחד אחר.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            EditField("שם *", name) { name = it }
            EditField("טלפון *", phone, KeyboardType.Phone) { phone = it }
            EditField("טלפון 2", phone2, KeyboardType.Phone) { phone2 = it }
            EditField("עיר", city) { city = it }
            EditField("כתובת", address) { address = it }
            EditField("שם האב", father) { father = it }
            EditField("חם", chem) { chem = it }
            EditField("שטיבל", shtibel) { shtibel = it }
            EditField(if (shared) "אימייל (לא מתפרסם)" else "אימייל", email, KeyboardType.Email) { email = it }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun EditField(label: String, value: String, type: KeyboardType = KeyboardType.Text, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = type),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    )
}
