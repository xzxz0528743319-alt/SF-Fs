package com.phonebook.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import java.security.MessageDigest

object Prefs {
    const val PRIVACY_URL = "https://github.com/xzxz0528743319-alt/SF-Fs/blob/main/PRIVACY.md"

    private lateinit var sp: SharedPreferences

    /** 0 = לפי המערכת, 1 = בהיר, 2 = כהה */
    val theme = MutableStateFlow(0)

    /** כתובת המייל של המשתמש המחובר, או null */
    val session = MutableStateFlow<String?>(null)

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        theme.value = sp.getInt("theme", 0)
        session.value = if (refreshToken.isNotBlank()) email else null
    }

    private fun s(k: String, def: String = "") = sp.getString(k, def) ?: def
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    var setupDone: Boolean
        get() = sp.getBoolean("setup_done", false)
        set(v) = sp.edit().putBoolean("setup_done", v).apply()

    fun setTheme(v: Int) {
        sp.edit().putInt("theme", v).apply()
        theme.value = v
    }

    // ---- שרת ----
    var serverUrl: String
        get() = s("sb_url")
        set(v) = put("sb_url", v.trim().trimEnd('/'))
    var serverKey: String
        get() = s("sb_key")
        set(v) = put("sb_key", v.trim())

    var accessToken: String
        get() = s("access")
        set(v) = put("access", v)
    var refreshToken: String
        get() = s("refresh")
        set(v) = put("refresh", v)
    var tokenExpiry: Long
        get() = sp.getLong("expiry", 0)
        set(v) = sp.edit().putLong("expiry", v).apply()
    var userId: String
        get() = s("uid")
        set(v) = put("uid", v)
    var email: String
        get() = s("email")
        set(v) = put("email", v)
    var lastSync: String
        get() = s("last_sync")
        set(v) = put("last_sync", v)

    fun clearSession() {
        sp.edit().remove("access").remove("refresh").remove("expiry").remove("uid")
            .remove("email").remove("last_sync").apply()
        session.value = null
    }

    // ---- סיסמת מחיקה ----
    val hasDeletePassword: Boolean get() = s("del_pw").isNotBlank()
    fun setDeletePassword(pw: String?) = put("del_pw", if (pw.isNullOrBlank()) "" else hash(pw))
    fun checkDeletePassword(pw: String) = !hasDeletePassword || hash(pw) == s("del_pw")
    private fun hash(pw: String) = MessageDigest.getInstance("SHA-256")
        .digest(pw.toByteArray()).joinToString("") { "%02x".format(it) }

    // ---- עוזרת ----
    var aiKey: String
        get() = s("ai_key")
        set(v) = put("ai_key", v.trim())
    var aiModel: String
        get() = s("ai_model", "claude-haiku-5-5")
        set(v) = put("ai_model", v.trim())
}
