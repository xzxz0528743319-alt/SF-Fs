@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import android.provider.Telephony
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.CallerId
import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Phone
import com.phonebook.app.sms.SmsMsg
import com.phonebook.app.sms.SmsRepo
import com.phonebook.app.sms.SmsSender
import com.phonebook.app.sms.SmsThread
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------------- רשימת שיחות SMS ----------------

@Composable
fun ThreadsScreen(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val ver = rememberProviderVersion(Telephony.Sms.CONTENT_URI)
    val dbv by LocalDb.changes.collectAsState()
    val threads by produceState<List<Pair<SmsThread, String?>>?>(null, ver, dbv) {
        value = withContext(Dispatchers.IO) {
            val names = HashMap<String, String?>()
            SmsRepo.threads(ctx).map { t -> t to names.getOrPut(t.address) { CallerId.lookup(ctx, t.address)?.name } }
        }
    }
    val list = threads
    when {
        list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        list.isEmpty() -> EmptyState("אין הודעות")
        else -> LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(list, key = { it.first.threadId }) { (t, name) ->
                AppCard(Modifier.clickable { onOpen(t.address) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(name ?: t.address)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                name ?: ltr(t.address), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                fontWeight = if (t.unread) FontWeight.Bold else FontWeight.SemiBold
                            )
                            Text(
                                t.snippet.replace('\n', ' '), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (t.unread) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(shortDate(t.date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (t.unread) Box(Modifier.padding(top = 4.dp).size(10.dp).clip(CircleShape).background(Brand))
                        }
                    }
                }
            }
        }
    }
}

// ---------------- שיחה ----------------

@Composable
fun ConversationScreen(address: String, draft: String, onClose: () -> Unit, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var text by rememberSaveable(address) { mutableStateOf(draft) }
    val ver = rememberProviderVersion(Telephony.Sms.CONTENT_URI)
    val threadId by produceState<Long?>(null, address) { value = withContext(Dispatchers.IO) { SmsRepo.threadIdFor(ctx, address) } }
    val msgs by produceState(emptyList<SmsMsg>(), threadId, ver) {
        val id = threadId ?: return@produceState
        value = withContext(Dispatchers.IO) {
            SmsRepo.messages(ctx, id).also { list ->
                if (list.any { !it.read && !it.sent }) SmsRepo.markRead(ctx, id)
            }
        }
    }
    val name by produceState<String?>(null, address) { value = withContext(Dispatchers.IO) { CallerId.lookup(ctx, address)?.name } }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex) }

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar(name ?: ltr(address), onClose) {
            IconButton(onClick = { onCall(address) }) { Icon(Icons.Filled.Call, "התקשר", tint = MaterialTheme.colorScheme.primary) }
        }
        if (!SmsRepo.isDefault(ctx)) {
            InfoCard("כדי לקבל הודעות כאן, הגדר את האפליקציה כאפליקציית SMS ברירת מחדל (בהגדרות).", Modifier.padding(horizontal = 16.dp))
        }
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(msgs, key = { it.id }) { m -> Bubble(m) }
        }
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("הודעה") },
                maxLines = 5,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(
                onClick = {
                    val body = text.trim()
                    if (body.isEmpty()) return@FilledIconButton
                    text = ""
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { SmsSender.send(ctx, address, body) } }
                            .onFailure { toast(ctx, "השליחה נכשלה: ${it.message}") }
                    }
                },
                modifier = Modifier.size(52.dp)
            ) { Icon(Icons.Filled.Send, "שלח") }
        }
    }
}

@Composable
private fun Bubble(m: SmsMsg) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.sent) Arrangement.End else Arrangement.Start) {
        Column(horizontalAlignment = if (m.sent) Alignment.End else Alignment.Start) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (m.sent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLowest,
                shadowElevation = if (m.sent) 0.dp else 1.dp,
                modifier = Modifier.widthIn(max = 300.dp)
            ) {
                Text(
                    m.body, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                    color = if (m.sent) Color.White else MaterialTheme.colorScheme.onSurface
                )
            }
            val status = when (m.type) {
                Telephony.Sms.MESSAGE_TYPE_FAILED -> " · לא נשלחה"
                Telephony.Sms.MESSAGE_TYPE_OUTBOX, Telephony.Sms.MESSAGE_TYPE_QUEUED -> " · שולח…"
                else -> ""
            }
            Text(
                "${dayLabel(m.date)} ${timeLabel(m.date)}$status",
                style = MaterialTheme.typography.labelSmall,
                color = if (m.type == Telephony.Sms.MESSAGE_TYPE_FAILED) CallRed else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

// ---------------- הודעה חדשה ----------------

@Composable
fun NewMessageScreen(onClose: () -> Unit, onStart: (String) -> Unit) {
    var to by rememberSaveable { mutableStateOf("") }
    val dbv by LocalDb.changes.collectAsState()
    val matches by produceState(emptyList<Contact>(), to, dbv) {
        value = if (to.isBlank()) emptyList() else withContext(Dispatchers.IO) {
            (LocalDb.search(LocalDb.PERSONAL, to, 0, null, 10) + LocalDb.search(LocalDb.SHARED, to, 0, null, 20)).distinctBy { it.phone }
        }
    }
    val digits = Phone.digits(to)

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar("הודעה חדשה", onClose)
        OutlinedTextField(
            value = to,
            onValueChange = { to = it },
            label = { Text("אל: שם או מספר") },
            singleLine = true,
            shape = RoundedCornerShape(20.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        if (digits.length >= 3) {
            TextButton(onClick = { onStart(to.trim()) }, modifier = Modifier.padding(horizontal = 8.dp)) {
                Text("שלח אל ${ltr(to.trim())}")
            }
        }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(matches, key = { it.id }) { c ->
                AppCard(Modifier.clickable { onStart(c.phone) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.name, 38.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(c.name, fontWeight = FontWeight.SemiBold)
                            Text(ltr(c.phone), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
