@file:OptIn(ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import android.provider.CallLog
import android.provider.Telephony
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.phonebook.app.data.CallerId
import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.LogItem
import com.phonebook.app.data.LogKind
import com.phonebook.app.data.LogRepo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------------- יומן שיחות ----------------

@Composable
fun CallsScreen(onCall: (String) -> Unit, onSms: (String) -> Unit) {
    val ctx = LocalContext.current
    val version = rememberProviderVersion(CallLog.Calls.CONTENT_URI)
    val dbv by LocalDb.changes.collectAsState()
    val items by produceState<List<LogItem>?>(null, version, dbv) {
        value = withContext(Dispatchers.IO) { LogRepo.load(ctx, 0) }
    }
    var chosen by remember { mutableStateOf<LogItem?>(null) }

    val list = items
    when {
        list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        list.isEmpty() -> EmptyState("אין שיחות")
        else -> LazyColumn(contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp)) {
            list.groupBy { dayLabel(it.date) }.forEach { (day, group) ->
                item(key = "h_$day") { SectionHeader(day) }
                item(key = "g_$day") {
                    AppCard {
                        group.forEachIndexed { idx, it ->
                            LogRow(it, onCall, onSms) { chosen = it }
                            if (idx < group.lastIndex) HorizontalDivider(
                                Modifier.padding(start = 68.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                        }
                    }
                }
            }
        }
    }

    chosen?.let { item ->
        NumberActions(
            item,
            onDismiss = { chosen = null },
            onCall = { chosen = null; onCall(item.number) },
            onSms = { chosen = null; onSms(item.number) },
            onWhatsapp = { chosen = null; Actions.whatsapp(ctx, item.number) },
        )
    }
}

/** חלון קטן שנפתח בלחיצה על מספר ביומן: חיוג, הודעות עם המספר, וואטסאפ */
@Composable
private fun NumberActions(item: LogItem, onDismiss: () -> Unit, onCall: () -> Unit, onSms: () -> Unit, onWhatsapp: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("סגור") } },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(item.name ?: item.number, 48.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(item.name ?: ltr(item.number), fontWeight = FontWeight.Bold)
                    if (item.name != null) Text(
                        ltr(item.number), style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionLine(Icons.Filled.Call, "התקשר", CallGreen, onCall)
                ActionLine(Icons.Filled.Sms, "הודעות עם המספר הזה", Brand, onSms)
                ActionLine(Icons.Filled.Chat, "וואטסאפ", Color(0xFF25D366), onWhatsapp)
            }
        },
        shape = MaterialTheme.shapes.large,
    )
}

@Composable
private fun ActionLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, color: Color, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(color.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = color) }
        Spacer(Modifier.width(14.dp))
        Text(label, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun LogRow(it: LogItem, onCall: (String) -> Unit, onSms: (String) -> Unit, onOpen: () -> Unit) {
    val isSms = it.kind == LogKind.SMS_IN || it.kind == LogKind.SMS_OUT
    val title = it.name ?: if (it.number.isBlank()) "מספר חסוי" else ltr(it.number)
    val missed = it.kind == LogKind.MISSED
    val (icon, tint, what) = when (it.kind) {
        LogKind.IN -> Triple(Icons.Filled.CallReceived, CallGreen, "נכנסת")
        LogKind.OUT -> Triple(Icons.Filled.CallMade, Brand, "יוצאת")
        LogKind.MISSED -> Triple(Icons.Filled.CallMissed, CallRed, "שיחה שלא נענתה")
        LogKind.REJECTED -> Triple(Icons.Filled.Block, CallRed, "נדחתה")
        LogKind.SMS_IN -> Triple(Icons.Filled.Sms, Brand, "")
        LogKind.SMS_OUT -> Triple(Icons.Filled.Sms, MaterialTheme.colorScheme.onSurfaceVariant, "נשלחה: ")
    }
    val subtitle = when {
        isSms -> what + (it.snippet ?: "").replace('\n', ' ')
        it.duration > 0 -> "$what · ${formatDuration(it.duration)}"
        else -> what
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(enabled = it.number.isNotBlank(), onClick = onOpen)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(it.name ?: it.number)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = if (missed) CallRed else MaterialTheme.colorScheme.onSurface
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = tint, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    subtitle, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Text(timeLabel(it.date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(end = 2.dp))
        if (it.number.isNotBlank()) {
            IconButton(onClick = { onSms(it.number) }) {
                Icon(Icons.Filled.Sms, "הודעות", tint = Lavender)
            }
            IconButton(onClick = { onCall(it.number) }) {
                Icon(Icons.Filled.Call, "התקשר", tint = CallGreen)
            }
        }
    }
}

// ---------------- חייגן ----------------

@Composable
fun DialerScreen(initial: String, onClose: () -> Unit, onCall: (String) -> Unit) {
    val ctx = LocalContext.current
    var number by rememberSaveable { mutableStateOf(initial) }
    val dbv by LocalDb.changes.collectAsState()
    val matches by produceState(emptyList<Contact>(), number, dbv) {
        value = if (number.length < 2) emptyList() else withContext(Dispatchers.IO) {
            (LocalDb.search(LocalDb.PERSONAL, number, 0, null, 5) + LocalDb.search(LocalDb.SHARED, number, 0, null, 10))
                .distinctBy { it.phone }.take(8)
        }
    }
    val known by produceState<String?>(null, number, dbv) {
        value = if (number.length < 7) null else withContext(Dispatchers.IO) { CallerId.lookup(ctx, number)?.name }
    }

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar("חייגן", onClose)
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp)) {
            items(matches, key = { it.id }) { c ->
                Row(
                    Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).clickable { number = c.phone }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(c.name, 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(ltr(c.phone), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { onCall(c.phone) }) { Icon(Icons.Filled.Call, "התקשר", tint = CallGreen) }
                }
            }
        }
        Text(
            ltr(number), fontSize = 34.sp, textAlign = TextAlign.Center, maxLines = 1,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        )
        Text(
            known ?: " ", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        )
        Keypad(onKey = { number += it }, onPlus = { number += "+" })
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 20.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.size(56.dp))
            Box(
                Modifier.size(72.dp).clip(CircleShape).background(CallGreen).clickable(enabled = number.isNotBlank()) { onCall(number) },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Call, "חייג", tint = Color.White, modifier = Modifier.size(32.dp)) }
            Box(
                Modifier.size(56.dp).clip(CircleShape).pointerInput(Unit) {
                    detectTapGestures(
                        onTap = { number = number.dropLast(1) },
                        onLongPress = { number = "" },
                    )
                },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Backspace, "מחק", tint = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
    }
}

@Composable
private fun Keypad(onKey: (String) -> Unit, onPlus: () -> Unit) {
    val keys = listOf(
        "1" to "", "2" to "ABC", "3" to "DEF",
        "4" to "GHI", "5" to "JKL", "6" to "MNO",
        "7" to "PQRS", "8" to "TUV", "9" to "WXYZ",
        "*" to "", "0" to "+", "#" to "",
    )
    val key by rememberUpdatedState(onKey)
    val plus by rememberUpdatedState(onPlus)
    // מקלדת מספרים תמיד משמאל לימין
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            keys.chunked(3).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    row.forEach { (d, sub) ->
                        Box(
                            Modifier
                                .size(74.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                                .pointerInput(d) {
                                    detectTapGestures(
                                        onTap = { key(d) },
                                        onLongPress = { if (d == "0") plus() else key(d) },
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(d, fontSize = 28.sp)
                                if (sub.isNotEmpty()) Text(sub, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}
