package com.phonebook.app.call

import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService

/** המערכת מתחברת לשירות הזה כשהאפליקציה היא אפליקציית הטלפון ברירת המחדל */
@Suppress("DEPRECATION")
class PhoneInCallService : InCallService() {

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        CallManager.service = this
        CallManager.onChange = { CallNotifications.update(this) }
        CallManager.added(call)
        if (call.state != Call.STATE_RINGING) {
            // שיחה יוצאת – פותחים מסך שיחה מיד. שיחה נכנסת – דרך התראה במסך מלא.
            try {
                startActivity(InCallActivity.intent(this))
            } catch (_: Exception) {
            }
        }
        CallNotifications.update(this)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        CallManager.removed(call)
        CallNotifications.update(this)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        CallManager.audioChanged(audioState)
    }

    override fun onDestroy() {
        CallManager.service = null
        CallManager.onChange = null
        CallNotifications.cancel(this)
        super.onDestroy()
    }
}
