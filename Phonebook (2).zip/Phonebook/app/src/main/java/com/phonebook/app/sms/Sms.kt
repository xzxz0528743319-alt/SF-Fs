package com.phonebook.app.sms

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.phonebook.app.App
import com.phonebook.app.MainActivity
import com.phonebook.app.R
import com.phonebook.app.data.CallerId

data class SmsThread(val threadId: Long, val address: String, val snippet: String, val date: Long, val unread: Boolean)
data class SmsHit(val id: Long, val threadId: Long, val address: String, val body: String, val date: Long, val sent: Boolean)
data class SmsMsg(val id: Long, val body: String, val date: Long, val type: Int, val read: Boolean) {
    val sent get() = type != Telephony.Sms.MESSAGE_TYPE_INBOX
}

object SmsRepo {
    fun isDefault(ctx: Context) = Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName

    fun threads(ctx: Context): List<SmsThread> = try {
        val map = LinkedHashMap<Long, SmsThread>()
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.READ, Telephony.Sms.TYPE),
            null, null, "${Telephony.Sms.DATE} DESC"
        )?.use { c ->
            var n = 0
            while (c.moveToNext() && n++ < 5000) {
                val tid = c.getLong(0)
                val unread = c.getInt(5) == Telephony.Sms.MESSAGE_TYPE_INBOX && c.getInt(4) == 0
                val existing = map[tid]
                if (existing == null) {
                    map[tid] = SmsThread(tid, c.getString(1) ?: "", c.getString(2) ?: "", c.getLong(3), unread)
                } else if (unread && !existing.unread) {
                    map[tid] = existing.copy(unread = true)
                }
            }
        }
        map.values.toList()
    } catch (_: Exception) {
        emptyList()
    }

    fun threadIdFor(ctx: Context, address: String): Long? = try {
        Telephony.Threads.getOrCreateThreadId(ctx, address)
    } catch (_: Exception) {
        null
    }

    fun messages(ctx: Context, threadId: Long): List<SmsMsg> = try {
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms._ID, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE, Telephony.Sms.READ),
            "${Telephony.Sms.THREAD_ID}=?", arrayOf(threadId.toString()), "${Telephony.Sms.DATE} ASC"
        )?.use { c ->
            buildList { while (c.moveToNext()) add(SmsMsg(c.getLong(0), c.getString(1) ?: "", c.getLong(2), c.getInt(3), c.getInt(4) == 1)) }
        } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }

    fun deleteMessage(ctx: Context, id: Long): Boolean = try {
        ctx.contentResolver.delete(ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, id), null, null) > 0
    } catch (_: Exception) {
        false
    }

    fun deleteThread(ctx: Context, threadId: Long): Boolean = try {
        ctx.contentResolver.delete(Telephony.Sms.CONTENT_URI, "${Telephony.Sms.THREAD_ID}=?", arrayOf(threadId.toString())) > 0
    } catch (_: Exception) {
        false
    }

    /** מסמן את ההודעה הנכנסת האחרונה בשיחה כלא נקראה */
    fun markUnread(ctx: Context, threadId: Long) {
        try {
            val id = ctx.contentResolver.query(
                Telephony.Sms.CONTENT_URI, arrayOf(Telephony.Sms._ID),
                "${Telephony.Sms.THREAD_ID}=? AND ${Telephony.Sms.TYPE}=${Telephony.Sms.MESSAGE_TYPE_INBOX}",
                arrayOf(threadId.toString()), "${Telephony.Sms.DATE} DESC"
            )?.use { c -> if (c.moveToFirst()) c.getLong(0) else null } ?: return
            ctx.contentResolver.update(
                ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, id),
                ContentValues().apply { put(Telephony.Sms.READ, 0) }, null, null
            )
        } catch (_: Exception) {
        }
    }

    private fun hits(ctx: Context, where: String?, args: Array<String>?, limit: Int): List<SmsHit> = try {
        ctx.contentResolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms._ID, Telephony.Sms.THREAD_ID, Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE, Telephony.Sms.TYPE),
            where, args, "${Telephony.Sms.DATE} DESC"
        )?.use { c ->
            buildList {
                while (c.moveToNext() && size < limit) add(
                    SmsHit(
                        c.getLong(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getLong(4),
                        c.getInt(5) != Telephony.Sms.MESSAGE_TYPE_INBOX
                    )
                )
            }
        } ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }

    /** חיפוש בתוכן ההודעות ובמספרים */
    fun search(ctx: Context, q: String): List<SmsHit> =
        hits(ctx, "${Telephony.Sms.BODY} LIKE ? OR ${Telephony.Sms.ADDRESS} LIKE ?", arrayOf("%$q%", "%$q%"), 200)

    fun byIds(ctx: Context, ids: Set<Long>): List<SmsHit> =
        if (ids.isEmpty()) emptyList()
        else hits(ctx, "${Telephony.Sms._ID} IN (${ids.joinToString(",")})", null, 500)

    fun markRead(ctx: Context, threadId: Long) {
        try {
            ctx.contentResolver.update(
                Telephony.Sms.CONTENT_URI,
                ContentValues().apply { put(Telephony.Sms.READ, 1); put(Telephony.Sms.SEEN, 1) },
                "${Telephony.Sms.THREAD_ID}=? AND ${Telephony.Sms.READ}=0", arrayOf(threadId.toString())
            )
        } catch (_: Exception) {
        }
    }
}

object SmsSender {
    fun send(ctx: Context, address: String, text: String) {
        val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()

        // כשהאפליקציה היא ברירת המחדל ל-SMS – היא אחראית לשמור את ההודעה ששלחה
        var row: Uri? = null
        if (SmsRepo.isDefault(ctx)) {
            row = try {
                ctx.contentResolver.insert(Telephony.Sms.Outbox.CONTENT_URI, ContentValues().apply {
                    put(Telephony.Sms.ADDRESS, address); put(Telephony.Sms.BODY, text)
                    put(Telephony.Sms.DATE, System.currentTimeMillis()); put(Telephony.Sms.READ, 1)
                    put(Telephony.Sms.SEEN, 1); put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_OUTBOX)
                })
            } catch (_: Exception) {
                null
            }
        }
        val sentIntent = PendingIntent.getBroadcast(
            ctx, (System.currentTimeMillis() and 0xFFFFFFF).toInt(),
            Intent(ctx, SmsStatusReceiver::class.java).setData(row),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        try {
            val parts = sm.divideMessage(text)
            sm.sendMultipartTextMessage(address, null, parts, ArrayList(parts.map { sentIntent }), null)
        } catch (e: Exception) {
            row?.let { setType(ctx, it, Telephony.Sms.MESSAGE_TYPE_FAILED) }
            throw e
        }
    }

    fun setType(ctx: Context, uri: Uri, type: Int) {
        try {
            ctx.contentResolver.update(uri, ContentValues().apply { put(Telephony.Sms.TYPE, type) }, null, null)
        } catch (_: Exception) {
        }
    }
}

/** מעדכן הודעה יוצאת ל"נשלחה" או "נכשלה" */
class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val uri = intent.data ?: return
        SmsSender.setType(
            context, uri,
            if (resultCode == Activity.RESULT_OK) Telephony.Sms.MESSAGE_TYPE_SENT else Telephony.Sms.MESSAGE_TYPE_FAILED
        )
    }
}

/** קבלת SMS (רק כשהאפליקציה היא ברירת המחדל) */
class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: return
        if (msgs.isEmpty()) return
        val address = msgs[0].displayOriginatingAddress ?: msgs[0].originatingAddress ?: ""
        val body = msgs.joinToString("") { it.displayMessageBody ?: it.messageBody ?: "" }
        try {
            context.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
                put(Telephony.Sms.ADDRESS, address); put(Telephony.Sms.BODY, body)
                put(Telephony.Sms.DATE, System.currentTimeMillis()); put(Telephony.Sms.DATE_SENT, msgs[0].timestampMillis)
                put(Telephony.Sms.READ, 0); put(Telephony.Sms.SEEN, 0); put(Telephony.Sms.TYPE, Telephony.Sms.MESSAGE_TYPE_INBOX)
            })
        } catch (_: Exception) {
        }
        SmsNotifier.show(context, address, body)
    }
}

object SmsNotifier {
    @SuppressLint("MissingPermission")
    fun show(ctx: Context, address: String, body: String) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val name = CallerId.lookup(ctx, address)?.name ?: address
        val open = PendingIntent.getActivity(
            ctx, address.hashCode(),
            Intent(ctx, MainActivity::class.java).putExtra(MainActivity.EXTRA_OPEN_SMS, address)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, App.CH_SMS)
            .setSmallIcon(R.drawable.ic_stat_phone)
            .setContentTitle(name)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(address.hashCode(), n)
        } catch (_: Exception) {
        }
    }
}

/** MMS לא נתמך בגרסה הזו – המקלט נדרש כדי שהמערכת תאפשר להיות אפליקציית SMS ברירת מחדל */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {}
}

/** "השב בהודעה" ממסך שיחה נכנסת */
class HeadlessSmsSendService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == TelephonyManager.ACTION_RESPOND_VIA_MESSAGE) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT)
            val recipients = intent.data?.schemeSpecificPart?.substringBefore('?')?.split(',', ';')
            if (!text.isNullOrBlank()) {
                recipients?.filter { it.isNotBlank() }?.forEach {
                    try {
                        SmsSender.send(this, Uri.decode(it), text)
                    } catch (_: Exception) {
                    }
                }
            }
        }
        stopSelf(startId)
        return START_NOT_STICKY
    }
}
