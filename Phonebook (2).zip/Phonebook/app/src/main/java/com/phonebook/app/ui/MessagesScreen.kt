@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@file:Suppress("DEPRECATION")

package com.phonebook.app.ui

import android.provider.Telephony
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.phonebook.app.data.Blocking
import com.phonebook.app.data.CallerId
import com.phonebook.app.data.Contact
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Phone
import com.phonebook.app.data.Prefs
import com.phonebook.app.sms.SmsHit
import com.phonebook.app.sms.SmsMsg
import com.phonebook.app.sms.SmsRepo
import com.phonebook.app.sms.SmsSender
import com.phonebook.app.sms.SmsThread
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val NOT_DEFAULT = "כדי לשנות הודעות צריך להגדיר את האפליקציה כאפליקציית SMS ברירת מחדל (בהגדרות)"

// ---------------- רשימת שיחות SMS ----------------

@Composable
fun ThreadsScreen(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ver = rememberProviderVersion(Telephony.Sms.CONTENT_URI)
    val dbv by LocalDb.changes.collectAsState()
    val flags by Prefs.flags.collectAsState()
    var view by rememberSaveable { mutableIntStateOf(0) } // 0 הכל, 1 לא נקראו, 2 ארכיון, 3 שמורות
    var query by rememberSaveable { mutableStateOf("") }
    var actionFor by remember { mutableStateOf<Pair<SmsThread, String?>?>(null) }
    var confirmDelete by remember { mutableStateOf<SmsThread?>(null) }
    var blockedTick by remember { mutableIntStateOf(0) }

    val threads by produceState<List<Pair<SmsThread, String?>>?>(null, ver, dbv) {
        value = withContext(Dispatchers.IO) {
            val names = HashMap<String, String?>()
            SmsRepo.threads(ctx).map { t -> t to names.getOrPut(t.address) { CallerId.lookup(ctx, t.address)?.name } }
        }
    }
    val searching = query.trim().length >= 2
    val hits by produceState<List<Pair<SmsHit, String?>>?>(null, query, view, ver, flags) {
        value = if (!searching && view != 3) null else withContext(Dispatchers.IO) {
            val raw = if (searching) SmsRepo.search(ctx, query.trim()) else SmsRepo.byIds(ctx, Prefs.starredIds())
            val names = HashMap<String, String?>()
            raw.map { h -> h to names.getOrPut(h.address) { CallerId.lookup(ctx, h.address)?.name } }
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("חיפוש בהודעות") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "נקה") } },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerLowest,
                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
            ),
            modifier = Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 10.dp)
        )
        val all = threads.orEmpty()
        val archivedCount = remember(all, flags) { all.count { Prefs.isArchived(it.first.threadId) } }
        val unreadCount = remember(all, flags) { all.count { it.first.unread && !Prefs.isArchived(it.first.threadId) } }
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "הכל", if (unreadCount > 0) "לא נקראו ($unreadCount)" else "לא נקראו",
                "ארכיון ($archivedCount)", "⭐ שמורות"
            ).forEachIndexed { i, label -> FilterChip(selected = view == i, onClick = { view = i }, label = { Text(label) }) }
        }

        when {
            searching || view == 3 -> {
                val list = hits
                when {
                    list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    list.isEmpty() -> EmptyState(if (searching) "לא נמצאו הודעות" else "אין הודעות שמורות. לחיצה ארוכה על הודעה ← שמור")
                    else -> LazyColumn(
                        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 96.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(list, key = { it.first.id }) { (h, name) -> HitRow(h, name) { onOpen(h.address) } }
                    }
                }
            }
            threads == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else -> {
                val shown = remember(all, view, flags) {
                    all.filter { (t, _) ->
                        val arch = Prefs.isArchived(t.threadId)
                        when (view) {
                            1 -> t.unread && !arch
                            2 -> arch
                            else -> !arch
                        }
                    }.sortedWith(compareByDescending<Pair<SmsThread, String?>> { Prefs.isPinned(it.first.threadId) }.thenByDescending { it.first.date })
                }
                if (shown.isEmpty()) EmptyState(
                    when (view) {
                        1 -> "אין הודעות שלא נקראו"
                        2 -> "הארכיון ריק"
                        else -> "אין הודעות"
                    }
                ) else LazyColumn(
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item { Text("לחיצה ארוכה על שיחה – אפשרויות נוספות", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 6.dp)) }
                    items(shown, key = { it.first.threadId }) { pair ->
                        ThreadRow(pair.first, pair.second, Prefs.isPinned(pair.first.threadId),
                            onClick = { onOpen(pair.first.address) }, onLongClick = { actionFor = pair })
                    }
                }
            }
        }
    }

    actionFor?.let { (t, name) ->
        val pinned = Prefs.isPinned(t.threadId)
        val archived = Prefs.isArchived(t.threadId)
        val blocked = remember(t.address, blockedTick) { Blocking.isBlocked(ctx, t.address) }
        ActionSheet(title = name ?: ltr(t.address), onDismiss = { actionFor = null }) {
            ActionItem(if (pinned) "📌 בטל נעיצה" else "📌 נעץ למעלה") { Prefs.setPinned(t.threadId, !pinned); actionFor = null }
            ActionItem(if (t.unread) "✔️ סמן כנקרא" else "🔵 סמן כלא נקרא") {
                actionFor = null
                scope.launch(Dispatchers.IO) { if (t.unread) SmsRepo.markRead(ctx, t.threadId) else SmsRepo.markUnread(ctx, t.threadId) }
            }
            ActionItem(if (archived) "📤 החזר מהארכיון" else "🗄️ העבר לארכיון") { Prefs.setArchived(t.threadId, !archived); actionFor = null }
            ActionItem(if (blocked) "✅ בטל חסימה" else "🚫 חסום מספר") {
                val ok = if (blocked) Blocking.unblock(ctx, t.address) else Blocking.block(ctx, t.address)
                toast(ctx, if (!ok) "לא ניתן לחסום – צריך להגדיר את האפליקציה כברירת מחדל" else if (blocked) "החסימה בוטלה" else "המספר נחסם – לא יגיעו ממנו שיחות והודעות")
                blockedTick++; actionFor = null
            }
            ActionItem("🗑️ מחק שיחה", CallRed) { confirmDelete = t; actionFor = null }
        }
    }

    confirmDelete?.let { t ->
        ConfirmDialog("למחוק את כל השיחה?", "כל ההודעות עם המספר הזה יימחקו מהטלפון.", "מחק", onDismiss = { confirmDelete = null }) {
            confirmDelete = null
            scope.launch {
                val ok = withContext(Dispatchers.IO) { SmsRepo.deleteThread(ctx, t.threadId) }
                toast(ctx, if (ok) "השיחה נמחקה" else NOT_DEFAULT)
            }
        }
    }
}

@Composable
private fun ThreadRow(t: SmsThread, name: String?, pinned: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    AppCard(Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Avatar(name ?: t.address)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    (if (pinned) "📌 " else "") + (name ?: ltr(t.address)), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    fontWeight = if (t.unread) FontWeight.Bold else FontWeight.SemiBold
                )
                Text(
                    t.snippet.replace('\n', ' '), maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (t.unread) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(shortDate(t.date), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (t.unread) Box(Modifier.padding(top = 4.dp).size(10.dp).clip(CircleShape).background(Brand))
            }
        }
    }
}

@Composable
private fun HitRow(h: SmsHit, name: String?, onClick: () -> Unit) {
    AppCard(Modifier.clickable(onClick = onClick)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name ?: ltr(h.address), fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1)
                Text("${dayLabel(h.date)} ${timeLabel(h.date)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text((if (h.sent) "את/ה: " else "") + h.body, maxLines = 3, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

// ---------------- חלונות פעולה משותפים ----------------

@Composable
fun ActionSheet(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = MaterialTheme.colorScheme.surfaceContainerLowest) {
        Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 24.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp))
            content()
        }
    }
}

@Composable
fun ActionItem(label: String, color: Color = Color.Unspecified, onClick: () -> Unit) {
    Text(
        label,
        fontSize = 17.sp,
        color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp)
    )
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = CallRed) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("ביטול") } },
    )
}

// ---------------- שיחה ----------------

@Composable
fun ConversationScreen(address: String, draft: String, onClose: () -> Unit, onCall: (String) -> Unit, onForward: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var text by rememberSaveable(address) { mutableStateOf(draft) }
    val ver = rememberProviderVersion(Telephony.Sms.CONTENT_URI)
    val flags by Prefs.flags.collectAsState()
    val threadId by produceState<Long?>(null, address) { value = withContext(Dispatchers.IO) { SmsRepo.threadIdFor(ctx, address) } }
    val msgs by produceState(emptyList<SmsMsg>(), threadId, ver) {
        val id = threadId ?: return@produceState
        value = withContext(Dispatchers.IO) {
            SmsRepo.messages(ctx, id).also { list ->
                if (list.any { !it.read && !it.sent }) SmsRepo.markRead(ctx, id)
            }
        }
    }
    val name by produceState<String?>(null, address) { value = withContext(Dispatchers.IO) { CallerId.lookup(ctx, address)?.name } }
    val listState = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex) }
    var menu by remember { mutableStateOf(false) }
    var msgAction by remember { mutableStateOf<SmsMsg?>(null) }
    var confirmThread by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar(name ?: ltr(address), onClose) {
            IconButton(onClick = { onCall(address) }) { Icon(Icons.Filled.Call, "התקשר") }
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, "עוד") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    val id = threadId
                    if (id != null) {
                        val archived = Prefs.isArchived(id)
                        DropdownMenuItem(text = { Text(if (archived) "החזר מהארכיון" else "העבר לארכיון") }, onClick = {
                            menu = false; Prefs.setArchived(id, !archived)
                            toast(ctx, if (archived) "הוחזר מהארכיון" else "הועבר לארכיון")
                        })
                    }
                    DropdownMenuItem(text = { Text("חסום מספר") }, onClick = {
                        menu = false
                        toast(ctx, if (Blocking.block(ctx, address)) "המספר נחסם" else "לא ניתן לחסום – צריך להגדיר את האפליקציה כברירת מחדל")
                    })
                    DropdownMenuItem(text = { Text("מחק שיחה", color = CallRed) }, onClick = { menu = false; confirmThread = true })
                }
            }
        }
        if (!SmsRepo.isDefault(ctx)) {
            InfoCard("כדי לקבל ולנהל הודעות כאן, הגדר את האפליקציה כאפליקציית SMS ברירת מחדל (בהגדרות).", Modifier.padding(16.dp))
        }
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(msgs, key = { it.id }) { m -> Bubble(m, starred = flags >= 0 && Prefs.isStarred(m.id)) { msgAction = m } }
        }
        Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                placeholder = { Text("הודעה") },
                maxLines = 5,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            FilledIconButton(
                onClick = {
                    val body = text.trim()
                    if (body.isEmpty()) return@FilledIconButton
                    text = ""
                    scope.launch {
                        runCatching { withContext(Dispatchers.IO) { SmsSender.send(ctx, address, body) } }
                            .onFailure { toast(ctx, "השליחה נכשלה: ${it.message}") }
                    }
                },
                modifier = Modifier.size(52.dp)
            ) { Icon(Icons.Filled.Send, "שלח") }
        }
    }

    msgAction?.let { m ->
        val starred = Prefs.isStarred(m.id)
        ActionSheet(title = "הודעה", onDismiss = { msgAction = null }) {
            Text(m.body, maxLines = 4, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp))
            ActionItem("📋 העתק") { clipboard.setText(AnnotatedString(m.body)); toast(ctx, "הועתק"); msgAction = null }
            ActionItem("↪️ העבר למישהו אחר") { msgAction = null; onForward(m.body) }
            ActionItem(if (starred) "⭐ הסר מהשמורות" else "⭐ שמור הודעה") {
                Prefs.setStarred(m.id, !starred); toast(ctx, if (starred) "הוסר מהשמורות" else "נשמר – תמצא אותה ב\"⭐ שמורות\""); msgAction = null
            }
            ActionItem("🗑️ מחק הודעה", CallRed) {
                msgAction = null
                scope.launch {
                    val ok = withContext(Dispatchers.IO) { SmsRepo.deleteMessage(ctx, m.id) }
                    if (ok) Prefs.setStarred(m.id, false)
                    toast(ctx, if (ok) "ההודעה נמחקה" else NOT_DEFAULT)
                }
            }
        }
    }

    if (confirmThread) {
        ConfirmDialog("למחוק את כל השיחה?", "כל ההודעות עם המספר הזה יימחקו מהטלפון.", "מחק", onDismiss = { confirmThread = false }) {
            confirmThread = false
            val id = threadId ?: return@ConfirmDialog
            scope.launch {
                val ok = withContext(Dispatchers.IO) { SmsRepo.deleteThread(ctx, id) }
                toast(ctx, if (ok) "השיחה נמחקה" else NOT_DEFAULT)
                if (ok) onClose()
            }
        }
    }
}

@Composable
private fun Bubble(m: SmsMsg, starred: Boolean, onLongClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.sent) Arrangement.End else Arrangement.Start) {
        Column(horizontalAlignment = if (m.sent) Alignment.End else Alignment.Start) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (m.sent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerLowest,
                shadowElevation = if (m.sent) 0.dp else 1.dp,
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .combinedClickable(onClick = {}, onLongClick = onLongClick)
            ) {
                Text(
                    m.body, modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                    color = if (m.sent) Color.White else MaterialTheme.colorScheme.onSurface
                )
            }
            val status = when (m.type) {
                Telephony.Sms.MESSAGE_TYPE_FAILED -> " · לא נשלחה"
                Telephony.Sms.MESSAGE_TYPE_OUTBOX, Telephony.Sms.MESSAGE_TYPE_QUEUED -> " · שולח…"
                else -> ""
            }
            Text(
                (if (starred) "⭐ " else "") + "${dayLabel(m.date)} ${timeLabel(m.date)}$status",
                style = MaterialTheme.typography.labelSmall,
                color = if (m.type == Telephony.Sms.MESSAGE_TYPE_FAILED) CallRed else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

// ---------------- הודעה חדשה ----------------

@Composable
fun NewMessageScreen(onClose: () -> Unit, onStart: (String) -> Unit) {
    var to by rememberSaveable { mutableStateOf("") }
    val dbv by LocalDb.changes.collectAsState()
    val matches by produceState(emptyList<Contact>(), to, dbv) {
        value = if (to.isBlank()) emptyList() else withContext(Dispatchers.IO) {
            (LocalDb.search(LocalDb.PERSONAL, to, 0, null, 10) + LocalDb.search(LocalDb.SHARED, to, 0, null, 20)).distinctBy { it.phone }
        }
    }
    val digits = Phone.digits(to)

    Column(Modifier.fillMaxSize()) {
        OverlayTopBar("הודעה חדשה", onClose)
        OutlinedTextField(
            value = to,
            onValueChange = { to = it },
            label = { Text("אל: שם או מספר") },
            singleLine = true,
            shape = RoundedCornerShape(20.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )
        if (digits.length >= 3) {
            TextButton(onClick = { onStart(to.trim()) }, modifier = Modifier.padding(horizontal = 8.dp)) {
                Text("שלח אל ${ltr(to.trim())}")
            }
        }
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(matches, key = { it.id }) { c ->
                AppCard(Modifier.clickable { onStart(c.phone) }) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(c.name, 38.dp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(c.name, fontWeight = FontWeight.SemiBold)
                            Text(ltr(c.phone), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
