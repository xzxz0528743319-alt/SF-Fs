package com.phonebook.app.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import java.security.MessageDigest

object Prefs {
    const val PRIVACY_URL = "https://github.com/xzxz0528743319-alt/SF-Fs/blob/main/PRIVACY.md"

    private lateinit var sp: SharedPreferences

    /** 0 = לפי המערכת, 1 = בהיר, 2 = כהה */
    val theme = MutableStateFlow(0)

    /** כתובת המייל של המשתמש המחובר, או null */
    val session = MutableStateFlow<String?>(null)

    /** עולה בכל שינוי של נעיצה / ארכיון / שמורות – המסכים מתרעננים */
    val flags = MutableStateFlow(0)

    private fun strSet(k: String): Set<String> = sp.getStringSet(k, emptySet()) ?: emptySet()
    private fun toggle(k: String, v: String, on: Boolean) {
        val s = strSet(k).toMutableSet()
        if (on) s += v else s -= v
        sp.edit().putStringSet(k, s).apply()
        flags.value = flags.value + 1
    }

    fun isArchived(threadId: Long) = threadId.toString() in strSet("archived")
    fun setArchived(threadId: Long, on: Boolean) = toggle("archived", threadId.toString(), on)
    fun isPinned(threadId: Long) = threadId.toString() in strSet("pinned")
    fun setPinned(threadId: Long, on: Boolean) = toggle("pinned", threadId.toString(), on)
    fun isStarred(msgId: Long) = msgId.toString() in strSet("starred")
    fun setStarred(msgId: Long, on: Boolean) = toggle("starred", msgId.toString(), on)
    fun starredIds(): Set<Long> = strSet("starred").mapNotNull { it.toLongOrNull() }.toSet()

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("prefs", Context.MODE_PRIVATE)
        theme.value = sp.getInt("theme", 0)
        session.value = if (refreshToken.isNotBlank()) email else null
    }

    private fun s(k: String, def: String = "") = sp.getString(k, def) ?: def
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    var lastBatch: String
        get() = s("last_batch")
        set(v) = put("last_batch", v)
    var lastBatchCount: Int
        get() = sp.getInt("last_batch_n", 0)
        set(v) = sp.edit().putInt("last_batch_n", v).apply()
    var cleanupDone: Boolean
        get() = sp.getBoolean("cleanup_v1", false)
        set(v) = sp.edit().putBoolean("cleanup_v1", v).apply()

    var setupDone: Boolean
        get() = sp.getBoolean("setup_done", false)
        set(v) = sp.edit().putBoolean("setup_done", v).apply()

    fun setTheme(v: Int) {
        sp.edit().putInt("theme", v).apply()
        theme.value = v
    }

    // ---- שרת ----
    var serverUrl: String
        get() = s("sb_url")
        set(v) = put("sb_url", v.trim().trimEnd('/'))
    var serverKey: String
        get() = s("sb_key")
        set(v) = put("sb_key", v.trim())

    var accessToken: String
        get() = s("access")
        set(v) = put("access", v)
    var refreshToken: String
        get() = s("refresh")
        set(v) = put("refresh", v)
    var tokenExpiry: Long
        get() = sp.getLong("expiry", 0)
        set(v) = sp.edit().putLong("expiry", v).apply()
    var userId: String
        get() = s("uid")
        set(v) = put("uid", v)
    var email: String
        get() = s("email")
        set(v) = put("email", v)
    var lastSync: String
        get() = s("last_sync")
        set(v) = put("last_sync", v)

    fun clearSession() {
        sp.edit().remove("access").remove("refresh").remove("expiry").remove("uid")
            .remove("email").remove("last_sync").apply()
        session.value = null
    }

    // ---- סיסמת מחיקה ----
    val hasDeletePassword: Boolean get() = s("del_pw").isNotBlank()
    fun setDeletePassword(pw: String?) = put("del_pw", if (pw.isNullOrBlank()) "" else hash(pw))
    fun checkDeletePassword(pw: String) = !hasDeletePassword || hash(pw) == s("del_pw")
    private fun hash(pw: String) = MessageDigest.getInstance("SHA-256")
        .digest(pw.toByteArray()).joinToString("") { "%02x".format(it) }

    // ---- עוזרת ----
    var aiKey: String
        get() = s("ai_key")
        set(v) = put("ai_key", v.trim())
    var aiModel: String
        get() = s("ai_model", "claude-haiku-5-5")
        set(v) = put("ai_model", v.trim())
}
