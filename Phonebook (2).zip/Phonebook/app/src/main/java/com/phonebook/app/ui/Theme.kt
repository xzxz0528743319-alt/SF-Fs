package com.phonebook.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.phonebook.app.data.Prefs

val Navy = Color(0xFF21395B)
val Brand = Color(0xFF2F62F1)
val Lavender = Color(0xFF2F62F1)
val CallGreen = Color(0xFF22A650)
val WhatsGreen = Color(0xFF3DDC6F)
val CallRed = Color(0xFFD32F2F)

/** סגנון "אלפון": כותרת כחול כהה, רקע אפור-בהיר, כרטיסים לבנים */
private val Light = lightColorScheme(
    primary = Color(0xFF2F62F1),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE3EAFB),
    onPrimaryContainer = Color(0xFF21395B),
    secondary = Color(0xFF21395B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF21395B),   // צבע הכותרת
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFF22A650),
    background = Color(0xFFF2F4F7),
    onBackground = Color(0xFF1A1D23),
    surface = Color(0xFFF2F4F7),
    onSurface = Color(0xFF1A1D23),
    onSurfaceVariant = Color(0xFF5F6670),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color.White,
    surfaceContainer = Color.White,
    surfaceContainerHigh = Color(0xFFE9EEF5),   // רקע כפתורי המספרים
    surfaceContainerHighest = Color(0xFFDDE4EE),
    outlineVariant = Color(0xFFE3E6EB),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF6E93FF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF233A6E),
    onPrimaryContainer = Color(0xFFDCE6FF),
    secondary = Color(0xFF9DB3D6),
    onSecondary = Color(0xFF0E1A2B),
    secondaryContainer = Color(0xFF16263D),
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFF3CCB78),
    background = Color(0xFF0E1218),
    onBackground = Color(0xFFE7EAEE),
    surface = Color(0xFF0E1218),
    onSurface = Color(0xFFE7EAEE),
    onSurfaceVariant = Color(0xFF9AA3AF),
    surfaceContainerLowest = Color(0xFF181D25),
    surfaceContainerLow = Color(0xFF181D25),
    surfaceContainer = Color(0xFF181D25),
    surfaceContainerHigh = Color(0xFF232A35),
    surfaceContainerHighest = Color(0xFF2C3440),
    outlineVariant = Color(0xFF2A313C),
)

/** רקע המסכים (אחיד) */
@Composable
fun skyBrush(): Brush = SolidColor(MaterialTheme.colorScheme.background)

/** צבע הכפתורים העגולים */
val BrandGradient: Brush = SolidColor(Color(0xFF2F62F1))

@Composable
fun PhonebookTheme(content: @Composable () -> Unit) {
    val mode by Prefs.theme.collectAsState()
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        shapes = Shapes(
            small = RoundedCornerShape(12.dp),
            medium = RoundedCornerShape(16.dp),
            large = RoundedCornerShape(24.dp),
        ),
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, content = content)
    }
}
