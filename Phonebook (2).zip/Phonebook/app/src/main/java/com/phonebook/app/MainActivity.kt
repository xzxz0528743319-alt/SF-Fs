package com.phonebook.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.mutableStateOf
import com.phonebook.app.ui.AppRoot
import com.phonebook.app.ui.PhonebookTheme

class MainActivity : ComponentActivity() {
    private val launch = mutableStateOf<Intent?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // אייקונים לבנים בשורת המצב, על הכותרת הכחולה
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        if (savedInstanceState == null) launch.value = intent
        setContent {
            PhonebookTheme {
                AppRoot(launch.value, onConsumed = { launch.value = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        launch.value = intent
    }

    companion object {
        const val EXTRA_OPEN_SMS = "open_sms"
    }
}
