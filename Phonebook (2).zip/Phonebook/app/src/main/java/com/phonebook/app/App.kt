package com.phonebook.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        LocalDb.init(this)
        // ניקוי חד-פעמי של רשומות פגומות שנוצרו מטעינת קובץ שלא נקרא נכון
        if (!Prefs.cleanupDone) Thread {
            try {
                LocalDb.cleanupBroken()
                Prefs.cleanupDone = true
            } catch (_: Exception) {
            }
        }.start()

        val nm = getSystemService(NotificationManager::class.java)
        // הצלצול עצמו מושמע ע"י המערכת, לכן ערוץ השיחות שקט
        nm.createNotificationChannel(
            NotificationChannel(CH_INCOMING, "שיחות נכנסות", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) }
        )
        nm.createNotificationChannel(NotificationChannel(CH_ONGOING, "שיחה פעילה", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_SMS, "הודעות", NotificationManager.IMPORTANCE_HIGH))
    }

    companion object {
        const val CH_INCOMING = "incoming_calls"
        const val CH_ONGOING = "ongoing_call"
        const val CH_SMS = "sms"
    }
}
