package com.phonebook.app.drive

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat
import com.phonebook.app.call.CallManager
import com.phonebook.app.data.CallerId
import com.phonebook.app.data.Prefs
import com.phonebook.app.data.Spam
import com.phonebook.app.net.SpamCloud
import com.phonebook.app.pc.DrivingBubbleService
import com.phonebook.app.sms.SmsSender
import com.phonebook.app.ui.AssistantBus
import com.phonebook.app.ui.VoiceInput
import com.phonebook.app.ui.isCancel
import com.phonebook.app.ui.tr

/**
 * עוזר נהיגה – בלי לגעת בטלפון:
 *  • שיחה נכנסת: מקריא מי מתקשר (ואזהרת ספאם), ומקשיב ל"ענה" / "דחה".
 *  • SMS נכנס: מקריא את ההודעה, מאפשר להכתיב תשובה, ומאשר לפני שליחה.
 *  • מי שהתקשר ולא נענה בזמן נהיגה – מקבל SMS "אני נוהג" (פעם בחצי שעה לכל מספר).
 * "נהיגה" = הכפתור הצף פעיל, או שהעוזרת פתוחה במצב נהיגה.
 */
object DriveAssist {
    private val main = Handler(Looper.getMainLooper())
    private var voice: VoiceInput? = null
    /** מזהה הפעולה הנוכחית – פעולה ישנה שהתבטלה לא ממשיכה */
    private var session = 0
    private var mode = 0          // 0 = כלום, 1 = שיחה נכנסת, 2 = הודעה
    private val replied = HashMap<String, Long>()

    fun driving() = DrivingBubbleService.running() || AssistantBus.driving.value

    private fun v(ctx: Context) = voice ?: VoiceInput(ctx.applicationContext).also { voice = it }

    private fun micOk(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun ringing() = CallManager.call.value?.state == Call.STATE_RINGING

    private fun words(t: String) = t.lowercase().replace(Regex("[\\p{P}\\p{S}]"), " ").replace(Regex("\\s+"), " ").trim()

    private fun has(t: String, list: List<String>): Boolean {
        val s = words(t)
        return list.any { s == it || s.startsWith("$it ") || s.endsWith(" $it") || s.contains(" $it ") }
    }

    private val YES = listOf("כן", "ענה", "תענה", "לענות", "עני", "תעני", "שלח", "תשלח", "לשלוח", "בטח", "yes", "answer", "accept", "send", "ok", "אוקיי")
    private val NO = listOf("לא", "דחה", "תדחה", "לדחות", "דחי", "תדחי", "no", "reject", "decline")

    // לא נתלים במילה אחת מדויקת: מספיק שורש המילה (ענה / תענה / לענות / עונה / תעני…, דחה / תדחה / לדחות…)
    private val YES_ROOTS = listOf("ענ", "עונ", "כן", "בטח", "יאללה", "אוקיי", "תרים", "להרים", "שלח", "תשלח", "לשלוח", "אנה", "הנה", "אנא")
    private val NO_ROOTS = listOf("דח", "נתק", "סגור", "תסגור", "ביטול", "בטל", "עסוק", "אחר כך", "לא עכשיו")
    private val NO_WORDS = listOf("לא", "no", "reject", "decline", "cancel", "stop")
    private val YES_WORDS = listOf("yes", "answer", "accept", "send", "ok", "okay", "sure", "pick up")

    private fun isNo(t: String): Boolean {
        val s = words(t)
        return has(s, NO) || has(s, NO_WORDS) || NO_ROOTS.any { s.contains(it) } || isCancel(t)
    }

    private fun isYes(t: String): Boolean {
        if (isNo(t)) return false
        val s = words(t)
        return has(s, YES) || has(s, YES_WORDS) || YES_ROOTS.any { s.contains(it) }
    }

    /** 1 = כן/ענה, -1 = לא/דחה, 0 = לא ברור. קודם לפי מה שנשמע הכי טוב, ורק אם לא ברור – לפי שאר האפשרויות */
    private fun decide(heard: String?): Int {
        if (heard.isNullOrBlank()) return 0
        val parts = heard.split(" | ").filter { it.isNotBlank() }
        val top = parts.firstOrNull() ?: return 0
        if (isNo(top)) return -1
        if (isYes(top)) return 1
        val yes = parts.drop(1).count { isYes(it) }
        val no = parts.drop(1).count { isNo(it) }
        return when {
            yes > no -> 1
            no > yes -> -1
            else -> 0
        }
    }

    /** מה שנשמע + כל האפשרויות שהזיהוי הציע */
    private fun heardAll(ctx: Context, said: String?): String? {
        val alts = v(ctx).alternatives.toList()
        if (said.isNullOrBlank() && alts.isEmpty()) return null
        return (listOfNotNull(said) + alts).joinToString(" | ")
    }

    /** סוגר כל הקשבה / הקראה פתוחה */
    private fun end(ctx: Context) {
        mode = 0
        session++
        voice?.stop(send = false)
        voice?.releaseFocus()
    }

    /** מקשיב למילה אחת-שתיים (כן / לא / ענה / דחה). null = לא נאמר כלום */
    private fun command(ctx: Context, seconds: Int, cb: (String?) -> Unit) {
        val vi = v(ctx)
        var done = false
        vi.bias = listOf("ענה", "תענה", "לענות", "דחה", "תדחה", "לדחות", "כן", "לא", "שלח", "ביטול")
        val timeout = Runnable {
            if (!done) {
                done = true
                val partial = heardAll(ctx, null)   // אולי נשמע משהו אבל בלי סוף משפט
                vi.stop(send = false); cb(partial)
            }
        }
        main.postDelayed(timeout, seconds * 1000L + 1500)
        // מחכים רגע אחרי ההקראה – שהמיקרופון לא ישמע את סוף המשפט של העוזרת עצמה
        main.postDelayed({
            if (!done) vi.start(1) { said -> if (!done) { done = true; main.removeCallbacks(timeout); cb(heardAll(ctx, said)) } }
        }, 350)
    }

    // ---------------------------------------------------------------- שיחה נכנסת

    fun onIncoming(ctx: Context, number: String) {
        val drv = driving()
        val announce = Prefs.announceCaller == 2 || (Prefs.announceCaller == 1 && drv)
        val byVoice = drv && Prefs.voiceAnswer && micOk(ctx)
        if (!announce && !byVoice) return
        val my = ++session
        mode = 1
        val app = ctx.applicationContext
        Thread {
            val known = runCatching { CallerId.lookup(app, number) }.getOrNull()
            val spam = if (known == null && number.isNotBlank()) SpamCloud.countBlocking(number) else 0
            main.post {
                if (my != session || !ringing()) return@post
                val who = when {
                    number.isBlank() -> tr("מספר חסוי")
                    known != null -> known.name
                    else -> tr("מספר לא שמור")
                }
                var text = tr("שיחה מ{0}", who)
                if (spam >= SpamCloud.WARN_AT) text += ". " + tr("זהירות – {0} משתמשים דיווחו על המספר הזה כספאם", spam)
                if (byVoice) {
                    // משתיקים את הצלצול כדי לשמוע את התשובה שלך
                    runCatching { app.getSystemService(TelecomManager::class.java).silenceRinger() }
                    v(app).holdFocus()
                    Speaker.speak(app, text + ". " + tr("לענות או לדחות?")) {
                        if (my == session && ringing()) listenAnswer(app, my, 1) else v(app).releaseFocus()
                    }
                } else Speaker.speak(app, text)
            }
        }.start()
    }

    private fun listenAnswer(ctx: Context, my: Int, triesLeft: Int) {
        command(ctx, 7) { said ->
            if (my != session || !ringing()) return@command
            when {
                decide(said) == 1 -> {
                    end(ctx)
                    CallManager.answer()
                    // בלי דיבורית בלוטות' – עוברים לרמקול, כדי לא להרים את הטלפון לאוזן
                    main.postDelayed({
                        val a = CallManager.audio.value
                        if (a.route == CallAudioState.ROUTE_EARPIECE && (a.supported and CallAudioState.ROUTE_BLUETOOTH) == 0) CallManager.setSpeaker(true)
                    }, 1200)
                }
                decide(said) == -1 -> { end(ctx); CallManager.hangup(); Speaker.speak(ctx, tr("השיחה נדחתה")) }
                triesLeft > 0 -> Speaker.speak(
                    ctx,
                    if (said.isNullOrBlank()) tr("לא שמעתי. אמור ענה, או דחה.")
                    else tr("שמעתי: {0}. אמור ענה, או דחה.", said.substringBefore(" | "))
                ) {
                    if (my == session && ringing()) listenAnswer(ctx, my, triesLeft - 1)
                }
                else -> { mode = 0; v(ctx).releaseFocus() }
            }
        }
    }

    /** נקרא כשמצב השיחה משתנה – אם כבר ענו/דחו ביד, מפסיקים להקשיב */
    fun callChanged(ctx: Context) {
        if (mode == 1 && !ringing()) { end(ctx); Speaker.stop() }
    }

    /** שיחה הסתיימה */
    fun onCallEnded(ctx: Context, number: String, incoming: Boolean, answered: Boolean, seconds: Long) {
        val app = ctx.applicationContext
        if (mode == 1) end(app)
        if (incoming && !answered && driving() && Prefs.driveAutoReply) autoReply(app, number)
        if (answered && seconds >= 20 && Prefs.noteAfterCall && !driving() && number.isNotBlank()) Reminders.askNote(app, number)
    }

    private fun autoReply(ctx: Context, number: String) {
        val digits = number.filter { it.isDigit() }
        if (digits.length < 9) return
        val now = System.currentTimeMillis()
        synchronized(replied) {
            if (now - (replied[digits] ?: 0L) < 30 * 60_000L) return
            replied[digits] = now
        }
        Thread {
            if (SpamCloud.countBlocking(number) >= SpamCloud.WARN_AT) return@Thread
            val text = Prefs.driveReplyText.ifBlank { tr("אני נוהג כרגע ולא יכול לענות. אחזור אליך בהקדם 🚗") }
            runCatching { SmsSender.send(ctx, number, text) }
        }.start()
    }

    // ---------------------------------------------------------------- SMS נכנס

    fun onSms(ctx: Context, address: String, body: String) {
        if (!driving() || !Prefs.driveReadSms) return
        if (CallManager.call.value != null || mode != 0) return
        val app = ctx.applicationContext
        Thread {
            val known = runCatching { CallerId.lookup(app, address) }.getOrNull()
            if (Spam.check(address, body, known != null) != Spam.Kind.NONE) return@Thread
            main.post {
                if (mode != 0 || CallManager.call.value != null) return@post
                val my = ++session
                mode = 2
                val who = known?.name ?: address.filter { it.isDigit() }.chunked(3).joinToString(" ").ifBlank { address }
                val canReply = micOk(app) && address.count { it.isDigit() } >= 9
                v(app).holdFocus()
                val text = tr("הודעה מ{0}: {1}", who, body.take(400)) +
                    if (canReply) ". " + tr("לענות? אמור את התשובה, או ביטול.") else ""
                Speaker.speak(app, text) {
                    if (my != session) return@speak
                    if (canReply) dictate(app, my, address, who) else end(app)
                }
            }
        }.start()
    }

    private fun dictate(ctx: Context, my: Int, address: String, who: String) {
        val vi = v(ctx)
        var done = false
        val timeout = Runnable { if (!done && my == session) { done = true; end(ctx) } }
        main.postDelayed(timeout, 16_000)
        vi.bias = emptyList()   // הכתבה חופשית – בלי מילים צפויות
        vi.start(3) { said ->
            if (done || my != session) return@start
            done = true; main.removeCallbacks(timeout)
            val t = said.trim()
            if (t.isEmpty() || isCancel(t) || words(t) == "לא") { Speaker.speak(ctx, tr("בסדר")) { end(ctx) }; return@start }
            vi.holdFocus()
            Speaker.speak(ctx, tr("לשלוח ל{0}: {1}? אמור כן או לא.", who, t)) {
                if (my != session) return@speak
                command(ctx, 6) { ans ->
                    if (my != session) return@command
                    if (decide(ans) == 1) {
                        runCatching { SmsSender.send(ctx, address, t) }
                        Speaker.speak(ctx, tr("נשלח")) { end(ctx) }
                    } else Speaker.speak(ctx, tr("לא נשלח")) { end(ctx) }
                }
            }
        }
    }
}
