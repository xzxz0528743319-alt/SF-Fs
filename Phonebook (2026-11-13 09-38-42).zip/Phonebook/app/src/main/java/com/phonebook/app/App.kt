package com.phonebook.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import com.phonebook.app.data.LocalDb
import com.phonebook.app.data.Prefs

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        LocalDb.init(this)
        com.phonebook.app.ui.I18n.init(this)
        // ניקוי חד-פעמי של רשומות פגומות שנוצרו מטעינת קובץ שלא נקרא נכון
        Thread {
            try {
                if (!Prefs.cleanupNumbersDone) {
                    LocalDb.cleanupNumberNames()
                    Prefs.cleanupNumbersDone = true
                }
                if (!Prefs.cleanupDone) {
                    LocalDb.cleanupBroken()
                    Prefs.cleanupDone = true
                }
                LocalDb.purgeTrash()                 // סל מחזור: מחיקה אחרי 30 יום
                com.phonebook.app.data.Backup.autoIfDue(this)  // גיבוי שבועי
            } catch (_: Exception) {
            }
        }.start()

        val nm = getSystemService(NotificationManager::class.java)
        // הצלצול עצמו מושמע ע"י המערכת, לכן ערוץ השיחות שקט
        nm.createNotificationChannel(
            NotificationChannel(CH_INCOMING, "שיחות נכנסות", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) }
        )
        nm.createNotificationChannel(NotificationChannel(CH_ONGOING, "שיחה פעילה", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_SMS, "הודעות", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_SPAM, "הודעות ספאם", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel(CH_MISSED, "שיחות שלא נענו", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_RECORDING, "הקלטת שיחה", NotificationManager.IMPORTANCE_LOW))
    }

    companion object {
        const val CH_INCOMING = "incoming_calls"
        const val CH_ONGOING = "ongoing_call"
        const val CH_SMS = "sms"
        const val CH_SPAM = "spam"
        const val CH_MISSED = "missed_calls"
        const val CH_RECORDING = "recording"
    }
}
