package com.phonebook.app.ui

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * הקשבה לעוזרת בתוך האפליקציה (בלי חלון של גוגל):
 * - מוזיקה / ניווט מושתקים בזמן ההקשבה – כדי שהעוזרת תשמע רק אותך.
 * - ממשיכה להקשיב גם כשעושים הפסקות קצרות, ושולחת רק אחרי X שניות של שקט (בנהיגה – 5 שניות).
 */
class VoiceInput(private val ctx: Context) {
    val listening = MutableStateFlow(false)
    val text = MutableStateFlow("")

    private var heard = ""
    private var partial = ""
    private var lastHeard = 0L
    private var startedAt = 0L
    private var silenceMs = 2500L
    private var onDone: (String) -> Unit = {}
    /** מצב "האזנה לביטול": רק מחפשים מילה כמו "ביטול" */
    private var cancelMode = false
    private var onCancel: () -> Unit = {}
    private var rec: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())
    private val am = ctx.getSystemService(AudioManager::class.java)
    private var focus: AudioFocusRequest? = null

    fun available() = SpeechRecognizer.isRecognitionAvailable(ctx)

    /** משתיק מוזיקה וניווט עד שמשחררים */
    fun holdFocus() {
        if (focus != null) return
        val f = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setOnAudioFocusChangeListener { }
            .build()
        runCatching { am.requestAudioFocus(f) }
        focus = f
    }

    fun releaseFocus() {
        focus?.let { runCatching { am.abandonAudioFocusRequest(it) } }
        focus = null
    }

    private fun intent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (I18n.code.value == "he") "he-IL" else I18n.locale().toLanguageTag())
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, silenceMs)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, silenceMs)
    }

    private fun current() = (heard + " " + partial).trim()

    fun start(silenceSeconds: Int, done: (String) -> Unit) {
        stop(send = false)
        cancelMode = false
        silenceMs = silenceSeconds * 1000L
        onDone = done
        heard = ""; partial = ""; text.value = ""
        startedAt = System.currentTimeMillis(); lastHeard = startedAt
        holdFocus()
        listening.value = true
        listenOnce()
        main.post(ticker)
    }

    private fun listenOnce() {
        rec?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() { lastHeard = System.currentTimeMillis() }
            override fun onRmsChanged(rmsdB: Float) { if (rmsdB > 6f) lastHeard = System.currentTimeMillis() }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(b: Bundle?) {
                val p = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (cancelMode) { if (isCancel(p)) fireCancel(); return }
                if (p.isNotBlank()) { partial = p; lastHeard = System.currentTimeMillis(); text.value = current() }
            }
            override fun onResults(b: Bundle?) {
                val p = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (cancelMode) {
                    if (isCancel(p)) fireCancel() else if (listening.value) main.post { if (listening.value) listenOnce() }
                    return
                }
                if (p.isNotBlank()) { heard = (heard + " " + p).trim(); lastHeard = System.currentTimeMillis() }
                partial = ""; text.value = current()
                if (listening.value) main.post { if (listening.value) listenOnce() }   // ממשיכים להקשיב אחרי הפסקה
            }
            override fun onError(error: Int) {
                if (!listening.value) return
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { stop(send = false); return }
                // שקט או "לא הבנתי" – ממשיכים להקשיב (הטיימר יחליט מתי לשלוח / לסגור)
                main.postDelayed({ if (listening.value) listenOnce() }, 250)
            }
        })
        runCatching { r.startListening(intent()) }
    }

    /** בודק כל רבע שנייה: אם עבר זמן השקט – שולח */
    private val ticker = object : Runnable {
        override fun run() {
            if (!listening.value) return
            if (cancelMode) { if (System.currentTimeMillis() - startedAt > silenceMs) { stopCancelWatch() ; return }; main.postDelayed(this, 250); return }
            val now = System.currentTimeMillis()
            val t = current()
            when {
                t.isNotBlank() && now - lastHeard > silenceMs -> { stop(send = true); return }
                t.isBlank() && now - startedAt > 12_000 -> { stop(send = false); return }   // לא אמרו כלום
            }
            main.postDelayed(this, 250)
        }
    }

    /** מאזין כמה שניות רק למילה "ביטול" (למשל בזמן הספירה לפני חיוג) */
    fun startCancelWatch(seconds: Int, cancel: () -> Unit) {
        stop(send = false)
        cancelMode = true
        onCancel = cancel
        silenceMs = seconds * 1000L
        heard = ""; partial = ""; text.value = ""
        startedAt = System.currentTimeMillis()
        listening.value = true
        listenOnce()
        main.post(ticker)
    }

    fun stopCancelWatch() {
        if (!cancelMode) return
        listening.value = false
        cancelMode = false
        main.removeCallbacks(ticker)
        runCatching { rec?.stopListening() }
        runCatching { rec?.destroy() }
        rec = null
    }

    private fun fireCancel() {
        stopCancelWatch()
        onCancel()
    }

    /** send=true – שולח את מה שנשמע עד עכשיו */
    fun stop(send: Boolean) {
        val wasListening = listening.value
        listening.value = false
        main.removeCallbacks(ticker)
        runCatching { rec?.stopListening() }
        runCatching { rec?.destroy() }
        rec = null
        val t = current()
        if (cancelMode) { cancelMode = false; return }
        if (wasListening && send && t.isNotBlank()) onDone(t) else releaseFocus()
    }
}

/** מילים שאומרות "בטל" – בעברית ובשפות נפוצות */
fun isCancel(t: String): Boolean {
    val s = t.trim().lowercase()
    if (s.isEmpty()) return false
    val words = listOf("ביטול", "בטל", "תבטל", "עצור", "לא לחייג", "אל תחייג", "cancel", "stop", "отмена", "إلغاء", "annuler", "cancelar")
    return words.any { s == it || s.startsWith("$it ") || s.endsWith(" $it") || s.contains(" $it ") } || s.length <= 6 && words.any { s.contains(it) }
}
